// =====================================
// NEXUS CHAT - VOICE MESSAGING MODULE
// Complete Voice Recording, Playback, and Waveform Visualization
// =====================================

// Voice Recording State
// mediaRecorder declared in chat.js - don't redeclare here
let audioChunks = [];
let recordingTimer = null;
let recordingSeconds = 0;
let recordingMinutes = 0;
let recordingStream = null;
let isRecording = false;
let recordedBlob = null;
let recordedUrl = null;

// Voice Playback State
let activeWaveSurfer = null;
let waveSurferInstances = new Map();
let currentlyPlaying = null;

// DOM Elements
const voiceRecordBtn = document.getElementById('voice-record-btn');
const voiceRecording = document.getElementById('voice-recording');
const voiceTimer = document.getElementById('voice-timer');
const cancelVoice = document.getElementById('cancel-voice');
const sendVoice = document.getElementById('send-voice');
const voiceWave = document.getElementById('voice-wave');

// ===== INITIALIZATION =====
function initVoiceModule() {
    setupVoiceRecording();
    setupVoicePlayback();
    checkMicrophonePermission();
}

// Check microphone permission
async function checkMicrophonePermission() {
    try {
        const permission = await navigator.permissions.query({ name: 'microphone' });
        
        if (permission.state === 'granted') {
            console.log('Microphone access granted');
        } else if (permission.state === 'prompt') {
            console.log('Microphone permission will be requested');
        } else {
            console.log('Microphone access denied');
            if (voiceRecordBtn) {
                voiceRecordBtn.title = 'Microphone access blocked';
                voiceRecordBtn.style.opacity = '0.5';
            }
        }

        permission.onchange = () => {
            if (permission.state === 'granted') {
                if (voiceRecordBtn) {
                    voiceRecordBtn.title = 'Record voice message';
                    voiceRecordBtn.style.opacity = '1';
                }
            }
        };
    } catch (error) {
        console.log('Permission API not supported', error);
    }
}

// ===== VOICE RECORDING =====

// Setup voice recording
function setupVoiceRecording() {
    if (!voiceRecordBtn) return;

    voiceRecordBtn.addEventListener('click', startVoiceRecording);
    cancelVoice.addEventListener('click', cancelVoiceRecording);
    sendVoice.addEventListener('click', sendVoiceMessage);

    // Add visual feedback on hover
    voiceRecordBtn.addEventListener('mouseenter', () => {
        if (!isRecording) {
            voiceRecordBtn.style.transform = 'scale(1.1)';
        }
    });

    voiceRecordBtn.addEventListener('mouseleave', () => {
        if (!isRecording) {
            voiceRecordBtn.style.transform = 'scale(1)';
        }
    });
}

// Start voice recording
async function startVoiceRecording() {
    try {
        // Check if already recording
        if (isRecording) {
            stopVoiceRecording();
            return;
        }

        // Request microphone access
        recordingStream = await navigator.mediaDevices.getUserMedia({ 
            audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true
            } 
        });

        // Create media recorder with optimal settings
        const options = {
            mimeType: 'audio/webm;codecs=opus',
            audioBitsPerSecond: 128000
        };

        // Fallback for browsers that don't support the specified MIME type
        try {
            mediaRecorder = new MediaRecorder(recordingStream, options);
        } catch (e) {
            console.warn('Specified MIME type not supported, using default', e);
            mediaRecorder = new MediaRecorder(recordingStream);
        }

        audioChunks = [];

        // Handle data available event
        mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) {
                audioChunks.push(event.data);
            }
        };

        // Handle recording stop
        mediaRecorder.onstop = () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
            recordedBlob = audioBlob;
            recordedUrl = URL.createObjectURL(audioBlob);
            
            // Show recording interface
            voiceRecording.style.display = 'flex';
            voiceRecordBtn.style.display = 'none';
            
            // Initialize waveform for preview
            initRecordingWaveform(recordedUrl);
            
            // Clean up stream
            recordingStream.getTracks().forEach(track => track.stop());
        };

        // Handle recording error
        mediaRecorder.onerror = (error) => {
            console.error('Recording error:', error);
            showToast('Recording failed', 'error');
            resetRecordingUI();
        };

        // Start recording
        mediaRecorder.start(100); // Collect data every 100ms for smoother recording
        isRecording = true;

        // Start timer
        recordingSeconds = 0;
        recordingMinutes = 0;
        updateVoiceTimer();
        recordingTimer = setInterval(updateVoiceTimer, 1000);

        // Visual feedback
        voiceRecordBtn.classList.add('recording');
        voiceRecordBtn.innerHTML = '<i class="fas fa-stop"></i>';
        voiceRecordBtn.title = 'Stop recording';

        showToast('Recording started... Speak now', 'info');
    } catch (error) {
        console.error('Error starting recording:', error);
        
        if (error.name === 'NotAllowedError') {
            showToast('Microphone access denied. Please allow microphone access.', 'error');
        } else if (error.name === 'NotFoundError') {
            showToast('No microphone found. Please connect a microphone.', 'error');
        } else {
            showToast('Could not access microphone', 'error');
        }
    }
}

// Stop voice recording
function stopVoiceRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        clearInterval(recordingTimer);
        isRecording = false;
        
        voiceRecordBtn.classList.remove('recording');
        voiceRecordBtn.innerHTML = '<i class="fas fa-microphone"></i>';
        voiceRecordBtn.title = 'Record voice message';
    }
}

// Update voice timer
function updateVoiceTimer() {
    recordingSeconds++;
    
    if (recordingSeconds === 60) {
        recordingMinutes++;
        recordingSeconds = 0;
    }
    
    // Max recording time: 5 minutes
    if (recordingMinutes === 5) {
        stopVoiceRecording();
        showToast('Maximum recording time reached', 'info');
        return;
    }
    
    const seconds = recordingSeconds.toString().padStart(2, '0');
    const minutes = recordingMinutes.toString().padStart(2, '0');
    voiceTimer.textContent = `${minutes}:${seconds}`;
    
    // Visual warning for last 30 seconds
    if (recordingMinutes === 4 && recordingSeconds >= 30) {
        voiceTimer.style.color = 'var(--nexus-busy)';
    }
}

// Cancel voice recording
function cancelVoiceRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        recordingStream.getTracks().forEach(track => track.stop());
    }
    
    resetRecordingUI();
    
    if (recordedUrl) {
        URL.revokeObjectURL(recordedUrl);
        recordedUrl = null;
    }
    
    recordedBlob = null;
    showToast('Recording cancelled', 'info');
}

// Reset recording UI
function resetRecordingUI() {
    voiceRecording.style.display = 'none';
    voiceRecordBtn.style.display = 'block';
    voiceRecordBtn.classList.remove('recording');
    voiceRecordBtn.innerHTML = '<i class="fas fa-microphone"></i>';
    
    clearInterval(recordingTimer);
    isRecording = false;
    recordingSeconds = 0;
    recordingMinutes = 0;
    voiceTimer.textContent = '0:00';
    voiceTimer.style.color = '';
    
    // Clear waveform
    if (voiceWave) {
        voiceWave.innerHTML = '';
    }
}

// Initialize recording waveform preview
function initRecordingWaveform(audioUrl) {
    if (!voiceWave) return;
    
    voiceWave.innerHTML = '';
    
    const wavesurfer = WaveSurfer.create({
        container: voiceWave,
        waveColor: 'rgba(124, 58, 237, 0.3)',
        progressColor: 'var(--nexus-gradient-start)',
        cursorColor: 'transparent',
        barWidth: 3,
        barRadius: 3,
        barGap: 2,
        height: 40,
        responsive: true,
        normalize: true,
        partialRender: true
    });
    
    wavesurfer.load(audioUrl);
    
    // Store instance
    waveSurferInstances.set('preview', wavesurfer);
}

// Send voice message
async function sendVoiceMessage() {
    if (!recordedBlob) {
        showToast('No recording to send', 'error');
        return;
    }

    if (!currentChat || !currentUser) {
        showToast('No chat selected', 'error');
        return;
    }

    const formData = new FormData();
    
    // Convert blob to file with proper name
    const fileName = `voice-${Date.now()}.webm`;
    const voiceFile = new File([recordedBlob], fileName, { type: 'audio/webm' });
    
    formData.append('audio', voiceFile);
    formData.append('duration', voiceTimer.textContent);
    formData.append('from', currentUser.email);
    formData.append('to', currentChat.email);
    formData.append('type', currentChatType);

    try {
        showToast('Uploading voice message...', 'info');
        
        const response = await fetch('/upload-voice', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();
        
        if (data.status === 'ok') {
            // Send as voice message
            await sendVoiceAsMessage(data.fileUrl, data.duration);
        } else {
            showToast('Failed to upload voice message', 'error');
        }
    } catch (error) {
        console.error('Error uploading voice:', error);
        showToast('Failed to send voice message', 'error');
    } finally {
        // Clean up
        resetRecordingUI();
        if (recordedUrl) {
            URL.revokeObjectURL(recordedUrl);
            recordedUrl = null;
        }
        recordedBlob = null;
    }
}

// Send voice as message
async function sendVoiceAsMessage(fileUrl, duration) {
    const endpoint = currentChatType === 'group' ? '/send-group-message' :
                    currentChatType === 'broadcast' ? '/send-broadcast' : '/send-message';
    
    const body = currentChatType === 'group' ? {
        groupId: currentChat.email,
        from: currentUser.email,
        message: fileUrl,
        type: 'voice',
        duration: duration
    } : currentChatType === 'broadcast' ? {
        broadcastId: currentChat.email,
        from: currentUser.email,
        message: fileUrl,
        type: 'voice',
        duration: duration
    } : {
        from: currentUser.email,
        to: currentChat.email,
        message: fileUrl,
        type: 'voice',
        duration: duration
    };

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(body)
        });

        const data = await response.json();
        
        if (data.status === 'ok') {
            showToast('Voice message sent', 'success');
            
            // Add to UI
            if (window.addMessageToUI) {
                window.addMessageToUI(data.message, true);
            }
            
            // Play sent sound
            if (window.playMessageSound) {
                window.playMessageSound('sent');
            }
        }
    } catch (error) {
        console.error('Error sending voice message:', error);
        showToast('Failed to send voice message', 'error');
    }
}

// ===== VOICE PLAYBACK =====

// Setup voice playback
function setupVoicePlayback() {
    // Listen for new voice messages
    document.addEventListener('click', (e) => {
        const playBtn = e.target.closest('.play-btn');
        if (playBtn) {
            const voicePlayer = playBtn.closest('.voice-player');
            if (voicePlayer) {
                const audioSrc = voicePlayer.dataset.src;
                const waveformId = voicePlayer.querySelector('.voice-waveform')?.id;
                toggleVoicePlayback(playBtn, audioSrc, waveformId);
            }
        }
    });
}

// Toggle voice playback
function toggleVoicePlayback(playBtn, audioSrc, waveformId) {
    if (!audioSrc) return;

    // If there's an active playback and it's not this one, stop it
    if (currentlyPlaying && currentlyPlaying !== waveformId) {
        stopCurrentPlayback();
    }

    // Get or create wavesurfer instance
    let wavesurfer = waveSurferInstances.get(waveformId);
    
    if (!wavesurfer) {
        // Create new wavesurfer instance
        wavesurfer = WaveSurfer.create({
            container: `#${waveformId}`,
            waveColor: 'rgba(255, 255, 255, 0.3)',
            progressColor: 'var(--nexus-gradient-start)',
            cursorColor: 'transparent',
            barWidth: 2,
            barRadius: 2,
            barGap: 1,
            height: 30,
            responsive: true,
            normalize: true,
            partialRender: true
        });

        wavesurfer.load(audioSrc);
        
        wavesurfer.on('ready', () => {
            wavesurfer.play();
            updatePlayButton(playBtn, true);
        });

        wavesurfer.on('finish', () => {
            updatePlayButton(playBtn, false);
            currentlyPlaying = null;
        });

        wavesurfer.on('pause', () => {
            updatePlayButton(playBtn, false);
        });

        wavesurfer.on('play', () => {
            updatePlayButton(playBtn, true);
        });

        waveSurferInstances.set(waveformId, wavesurfer);
        currentlyPlaying = waveformId;
        activeWaveSurfer = wavesurfer;
    } else {
        // Toggle existing instance
        if (wavesurfer.isPlaying()) {
            wavesurfer.pause();
            updatePlayButton(playBtn, false);
            currentlyPlaying = null;
        } else {
            // Stop any other playing
            if (activeWaveSurfer && activeWaveSurfer !== wavesurfer) {
                activeWaveSurfer.pause();
            }
            wavesurfer.play();
            updatePlayButton(playBtn, true);
            currentlyPlaying = waveformId;
            activeWaveSurfer = wavesurfer;
        }
    }
}

// Update play button state
function updatePlayButton(playBtn, isPlaying) {
    if (isPlaying) {
        playBtn.classList.remove('fa-play-circle');
        playBtn.classList.add('fa-pause-circle');
    } else {
        playBtn.classList.remove('fa-pause-circle');
        playBtn.classList.add('fa-play-circle');
    }
}

// Stop current playback
function stopCurrentPlayback() {
    if (activeWaveSurfer) {
        activeWaveSurfer.pause();
        activeWaveSurfer.stop();
        
        // Update all play buttons
        document.querySelectorAll('.play-btn').forEach(btn => {
            btn.classList.remove('fa-pause-circle');
            btn.classList.add('fa-play-circle');
        });
        
        currentlyPlaying = null;
        activeWaveSurfer = null;
    }
}

// ===== VOICE VISUALIZATION =====

// Create voice waveform for message
function createVoiceWaveform(containerId, audioUrl, duration) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const wavesurfer = WaveSurfer.create({
        container: `#${containerId}`,
        waveColor: 'rgba(124, 58, 237, 0.3)',
        progressColor: 'var(--nexus-gradient-start)',
        cursorColor: 'transparent',
        barWidth: 2,
        barRadius: 2,
        barGap: 1,
        height: 30,
        responsive: true,
        normalize: true,
        partialRender: true
    });

    wavesurfer.load(audioUrl);
    
    return wavesurfer;
}

// ===== UTILITY FUNCTIONS =====

// Format duration
function formatDuration(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

// Get audio duration from blob
function getAudioDuration(blob) {
    return new Promise((resolve, reject) => {
        const audio = new Audio();
        const url = URL.createObjectURL(blob);
        
        audio.addEventListener('loadedmetadata', () => {
            URL.revokeObjectURL(url);
            resolve(audio.duration);
        });
        
        audio.addEventListener('error', reject);
        audio.src = url;
    });
}

// Use global showToast from main.js - don't redefine here

// ===== CLEANUP =====

// Clean up resources on page unload
window.addEventListener('beforeunload', () => {
    if (recordingStream) {
        recordingStream.getTracks().forEach(track => track.stop());
    }
    
    if (recordingTimer) {
        clearInterval(recordingTimer);
    }
    
    // Destroy all wavesurfer instances
    waveSurferInstances.forEach((wavesurfer, id) => {
        wavesurfer.destroy();
    });
    waveSurferInstances.clear();
});

// ===== EXPORT FUNCTIONS =====
window.initVoiceModule = initVoiceModule;
window.createVoiceWaveform = createVoiceWaveform;
window.stopCurrentPlayback = stopCurrentPlayback;
window.formatDuration = formatDuration;

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', initVoiceModule);