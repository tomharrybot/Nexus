// =====================================
// NEXUS CHAT - SIMPLE EMOJI PICKER
// Most Famous & Frequently Used Emojis
// =====================================

// Famous emojis list (most used)
const FAMOUS_EMOJIS = [
    // Smileys & People
    '😊', '😂', '🥰', '😍', '😘', '😎', '😭', '😤', '😡', '🤔',
    '👍', '👎', '👌', '✌️', '🤞', '🤝', '🙏', '💪', '👏', '🎉',
    
    // Hearts & Emotions
    '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '💔', '💖',
    '✨', '⭐', '🌟', '💫', '🔥', '💯', '✅', '❌', '💀', '👻',
    
    // Common Objects
    '🎂', '🎈', '🎁', '📱', '💻', '⌚', '📷', '🔔', '💰', '🔑',
    '☀️', '🌙', '⭐', '🌈', '☁️', '⚡', '❄️', '🔥', '💧', '🌊',
    
    // Food & Drink
    '🍎', '🍕', '🍔', '🍟', '🌭', '🍿', '🥗', '🍣', '🍦', '🍩',
    '☕', '🥤', '🍺', '🍻', '🥂', '🍷', '🍸', '🍹', '🧃', '🥛',
    
    // Animals
    '🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐸',
    '🐧', '🐦', '🐤', '🐣', '🐥', '🦆', '🦅', '🦉', '🐺', '🐗',
    
    // Activities & Sports
    '⚽', '🏀', '🏈', '⚾', '🎾', '🏐', '🏉', '🎱', '🏓', '🏸',
    '🏊', '🚴', '🏋️', '🤸', '🤼', '🤽', '🤾', '🧘', '🎮', '🎯',
    
    // Flags
    '🇵🇰', '🇮🇳', '🇺🇸', '🇬🇧', '🇨🇦', '🇦🇺', '🇯🇵', '🇰🇷', '🇨🇳', '🇸🇦',
    '🇩🇪', '🇫🇷', '🇮🇹', '🇪🇸', '🇵🇹', '🇧🇷', '🇲🇽', '🇿🇦', '🇳🇬', '🇪🇬'
];

// DOM Elements - emojiPickerBtn and emojiPickerContainer defined in chat.js
// Reference them from global scope
const getEmojiPickerBtn = () => document.getElementById('emoji-picker-btn');
const getEmojiPickerContainer = () => document.getElementById('emoji-picker');

// Initialize emoji picker
function initEmojiPicker() {
    const emojiPickerBtn = getEmojiPickerBtn();
    const emojiPickerContainer = getEmojiPickerContainer();
    if (!emojiPickerBtn || !emojiPickerContainer) return;
    
    // Create simple emoji grid
    createEmojiGrid();
    
    // Toggle emoji picker on button click
    emojiPickerBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleEmojiPicker();
    });
    
    // Close when clicking outside
    document.addEventListener('click', (e) => {
        if (!emojiPickerContainer.contains(e.target) && 
            !emojiPickerBtn.contains(e.target)) {
            emojiPickerContainer.style.display = 'none';
        }
    });
}

// Create simple emoji grid
function createEmojiGrid() {
    emojiPickerContainer.innerHTML = '';
    emojiPickerContainer.className = 'simple-emoji-picker';
    
    // Create categories
    const categories = [
        { name: '😊 Smileys', emojis: FAMOUS_EMOJIS.slice(0, 20) },
        { name: '❤️ Hearts', emojis: FAMOUS_EMOJIS.slice(20, 30) },
        { name: '🎁 Objects', emojis: FAMOUS_EMOJIS.slice(30, 40) },
        { name: '🍔 Food', emojis: FAMOUS_EMOJIS.slice(40, 50) },
        { name: '🐶 Animals', emojis: FAMOUS_EMOJIS.slice(50, 60) },
        { name: '⚽ Sports', emojis: FAMOUS_EMOJIS.slice(60, 70) },
        { name: '🇵🇰 Flags', emojis: FAMOUS_EMOJIS.slice(70, 90) }
    ];
    
    categories.forEach(category => {
        const categoryDiv = document.createElement('div');
        categoryDiv.className = 'emoji-category';
        
        const title = document.createElement('div');
        title.className = 'emoji-category-title';
        title.textContent = category.name;
        categoryDiv.appendChild(title);
        
        const grid = document.createElement('div');
        grid.className = 'emoji-grid';
        
        category.emojis.forEach(emoji => {
            const emojiBtn = document.createElement('button');
            emojiBtn.className = 'emoji-btn';
            emojiBtn.textContent = emoji;
            emojiBtn.title = getEmojiName(emoji);
            
            emojiBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                insertEmoji(emoji);
            });
            
            grid.appendChild(emojiBtn);
        });
        
        categoryDiv.appendChild(grid);
        emojiPickerContainer.appendChild(categoryDiv);
    });
    
    // Add CSS for emoji picker
    addEmojiStyles();
}

// Insert emoji at cursor position
function insertEmoji(emoji) {
    const messageInput = document.getElementById('message-input');
    if (!messageInput) return;
    
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    
    const text = messageInput.value;
    const newText = text.substring(0, start) + emoji + text.substring(end);
    
    messageInput.value = newText;
    messageInput.focus();
    messageInput.selectionStart = messageInput.selectionEnd = start + emoji.length;
    
    // Trigger input event
    messageInput.dispatchEvent(new Event('input', { bubbles: true }));
    
    // Auto hide picker after selection
    setTimeout(() => {
        emojiPickerContainer.style.display = 'none';
    }, 200);
}

// Toggle emoji picker
function toggleEmojiPicker() {
    if (emojiPickerContainer.style.display === 'none' || 
        emojiPickerContainer.style.display === '') {
        emojiPickerContainer.style.display = 'block';
    } else {
        emojiPickerContainer.style.display = 'none';
    }
}

// Get emoji name (simple version)
function getEmojiName(emoji) {
    const names = {
        '😊': 'Smile', '😂': 'Joy', '🥰': 'Love', '😍': 'Heart Eyes',
        '😘': 'Kiss', '😎': 'Cool', '😭': 'Cry', '😤': 'Angry',
        '😡': 'Very Angry', '🤔': 'Thinking', '👍': 'Thumbs Up',
        '👎': 'Thumbs Down', '👌': 'OK', '✌️': 'Victory', '🤞': 'Fingers Crossed',
        '🤝': 'Handshake', '🙏': 'Pray', '💪': 'Strong', '👏': 'Clap',
        '🎉': 'Party', '❤️': 'Heart', '🧡': 'Orange Heart',
        '💛': 'Yellow Heart', '💚': 'Green Heart', '💙': 'Blue Heart',
        '💜': 'Purple Heart', '🖤': 'Black Heart', '🤍': 'White Heart',
        '💔': 'Broken Heart', '💖': 'Sparkling Heart', '✨': 'Sparkles',
        '⭐': 'Star', '🌟': 'Glowing Star', '💫': 'Dizzy', '🔥': 'Fire',
        '💯': '100', '✅': 'Check', '❌': 'Cross', '💀': 'Skull',
        '👻': 'Ghost', '🎂': 'Birthday', '🎈': 'Balloon', '🎁': 'Gift',
        '📱': 'Phone', '💻': 'Laptop', '⌚': 'Watch', '📷': 'Camera',
        '🔔': 'Bell', '💰': 'Money', '🔑': 'Key', '☀️': 'Sun',
        '🌙': 'Moon', '🌈': 'Rainbow', '☁️': 'Cloud', '⚡': 'Lightning',
        '❄️': 'Snow', '🌊': 'Wave', '🍎': 'Apple', '🍕': 'Pizza',
        '🍔': 'Burger', '🍟': 'Fries', '🌭': 'Hot Dog', '🍿': 'Popcorn',
        '🥗': 'Salad', '🍣': 'Sushi', '🍦': 'Ice Cream', '🍩': 'Donut',
        '☕': 'Coffee', '🥤': 'Drink', '🍺': 'Beer', '🍻': 'Cheers',
        '🥂': 'Champagne', '🍷': 'Wine', '🍸': 'Cocktail', '🍹': 'Tropical Drink',
        '🧃': 'Juice', '🥛': 'Milk', '🐶': 'Dog', '🐱': 'Cat',
        '🐭': 'Mouse', '🐹': 'Hamster', '🐰': 'Rabbit', '🦊': 'Fox',
        '🐻': 'Bear', '🐼': 'Panda', '🐨': 'Koala', '🐸': 'Frog',
        '🐧': 'Penguin', '🐦': 'Bird', '🐤': 'Chick', '🐣': 'Hatching',
        '🐥': 'Baby Chick', '🦆': 'Duck', '🦅': 'Eagle', '🦉': 'Owl',
        '🐺': 'Wolf', '🐗': 'Boar', '⚽': 'Soccer', '🏀': 'Basketball',
        '🏈': 'Football', '⚾': 'Baseball', '🎾': 'Tennis', '🏐': 'Volleyball',
        '🏉': 'Rugby', '🎱': 'Pool', '🏓': 'Table Tennis', '🏸': 'Badminton',
        '🏊': 'Swim', '🚴': 'Bike', '🏋️': 'Lift', '🤸': 'Gymnastics',
        '🤼': 'Wrestle', '🤽': 'Water Polo', '🤾': 'Handball', '🧘': 'Meditate',
        '🎮': 'Game', '🎯': 'Target', '🇵🇰': 'Pakistan', '🇮🇳': 'India',
        '🇺🇸': 'USA', '🇬🇧': 'UK', '🇨🇦': 'Canada', '🇦🇺': 'Australia',
        '🇯🇵': 'Japan', '🇰🇷': 'Korea', '🇨🇳': 'China', '🇸🇦': 'Saudi',
        '🇩🇪': 'Germany', '🇫🇷': 'France', '🇮🇹': 'Italy', '🇪🇸': 'Spain',
        '🇵🇹': 'Portugal', '🇧🇷': 'Brazil', '🇲🇽': 'Mexico', '🇿🇦': 'South Africa',
        '🇳🇬': 'Nigeria', '🇪🇬': 'Egypt'
    };
    
    return names[emoji] || 'Emoji';
}

// Add simple CSS styles
function addEmojiStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .simple-emoji-picker {
            position: absolute;
            bottom: 80px;
            left: 50%;
            transform: translateX(-50%);
            width: 350px;
            max-height: 400px;
            background: var(--nexus-surface, #1A1F2F);
            border: 1px solid var(--nexus-border, rgba(255,255,255,0.1));
            border-radius: 16px;
            padding: 12px;
            overflow-y: auto;
            z-index: 2000;
            box-shadow: 0 8px 32px rgba(0,0,0,0.4);
            display: none;
        }
        
        .emoji-category {
            margin-bottom: 16px;
        }
        
        .emoji-category-title {
            color: var(--nexus-text-secondary, #A0A8C0);
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 8px;
            padding-left: 4px;
        }
        
        .emoji-grid {
            display: grid;
            grid-template-columns: repeat(8, 1fr);
            gap: 4px;
        }
        
        .emoji-btn {
            background: transparent;
            border: none;
            font-size: 22px;
            padding: 6px;
            cursor: pointer;
            border-radius: 8px;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .emoji-btn:hover {
            background: rgba(124, 58, 237, 0.2);
            transform: scale(1.2);
        }
        
        @media (max-width: 480px) {
            .simple-emoji-picker {
                width: 300px;
                left: 10px;
                right: 10px;
                transform: none;
            }
            
            .emoji-grid {
                grid-template-columns: repeat(6, 1fr);
            }
        }
    `;
    document.head.appendChild(style);
}

// Initialize on load
document.addEventListener('DOMContentLoaded', initEmojiPicker);

// Export functions
window.initEmojiPicker = initEmojiPicker;
window.insertEmoji = insertEmoji;