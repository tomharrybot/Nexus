// =====================================
// NEXUS CHAT - AUTHENTICATION MODULE
// Complete auth system with OTP, splash screen, and real-time updates
// =====================================

// DOM Elements
const authScreen = document.getElementById('auth-screen');
const mainScreen = document.getElementById('main-screen');
const splashScreen = document.getElementById('splash-screen');
const emailInput = document.getElementById('email-input');
const usernameInput = document.getElementById('username-input');
const otpInputs = document.querySelectorAll('.otp-digit');
const otpContainer = document.getElementById('otp-container');
const sendOtpBtn = document.getElementById('send-otp-btn');
const verifyOtpBtn = document.getElementById('verify-otp-btn');
const authMessage = document.getElementById('auth-message');
const sendOtpText = document.getElementById('send-otp-text');
const sendOtpSpinner = document.getElementById('send-otp-spinner');
const verifyOtpText = document.getElementById('verify-otp-text');
const verifyOtpSpinner = document.getElementById('verify-otp-spinner');
const agreeContinueBtn = document.getElementById('agree-continue-btn');
const agreeContinueText = document.getElementById('agree-continue-text');
const agreeContinueSpinner = document.getElementById('agree-continue-spinner');
const termsContainer = document.getElementById('terms-container');
const termsCheckbox = document.getElementById('terms-checkbox');
const loadingSteps = document.getElementById('loading-steps');
const resendLink = document.createElement('a');
const otpTimer = document.createElement('div');

// Input focus effects
const inputGroups = document.querySelectorAll('.input-group');

inputGroups.forEach(group => {
    const input = group.querySelector('input');

    if (!input) return;

    input.addEventListener('focus', () => {
        group.classList.add('focused');
    });

    input.addEventListener('blur', () => {
        if (!input.value) {
            group.classList.remove('focused');
        }
    });
});

// Current user and state
let currentUser = null;
let otpCode = '';
let otpCountdown = 60;
let countdownInterval = null;

// Initialize OTP timer
otpTimer.className = 'otp-timer';
otpTimer.innerHTML = '<span>Resend code in </span><span id="countdown">60</span><span> seconds</span>';
resendLink.className = 'resend-link';
resendLink.textContent = 'Resend OTP';
resendLink.style.display = 'none';
resendLink.href = '#';

// Event Listeners
sendOtpBtn.addEventListener('click', sendOTP);
verifyOtpBtn.addEventListener('click', verifyOTP);
agreeContinueBtn.addEventListener('click', handleAgreeContinue);
resendLink.addEventListener('click', handleResendOTP);
termsCheckbox.addEventListener('change', handleTermsCheckbox);

// OTP input handling
otpInputs.forEach((input, index) => {
    input.addEventListener('input', (e) => {
        const value = e.target.value;

        if (value.length === 1) {
            // Add to OTP code
            otpCode += value;

            // Move to next input if available
            if (index < otpInputs.length - 1) {
                otpInputs[index + 1].focus();
            }
        }
    });

    input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !e.target.value && index > 0) {
            // Move to previous input on backspace
            otpInputs[index - 1].focus();

            // Remove last digit from OTP code
            otpCode = otpCode.slice(0, -1);
        }
    });

    // Auto focus first input
    if (index === 0) {
        input.addEventListener('paste', (e) => {
            e.preventDefault();
            const pasted = e.clipboardData.getData('text');
            if (pasted && pasted.length === 6 && /^\d+$/.test(pasted)) {
                pasted.split('').forEach((digit, i) => {
                    if (otpInputs[i]) {
                        otpInputs[i].value = digit;
                        otpCode += digit;
                    }
                });
                otpInputs[5].focus();
            }
        });
    }
});

// Initialize the app
function init() {
    // Show splash screen for 2.5 seconds
    setTimeout(() => {
        if (splashScreen) {
            splashScreen.classList.add('fade-out');
            setTimeout(() => {
                splashScreen.style.display = 'none';
            }, 800);
        }
    }, 2500);

    // Check if user is already logged in (from localStorage)
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        try {
            currentUser = JSON.parse(savedUser);
            showMainScreen();
            loadUserData();
        } catch (e) {
            localStorage.removeItem('currentUser');
            showAuthMessage('Session expired. Please login again.', 'error');
        }
    }

    // Apply saved theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
    }

    // Check for system preference
    if (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.body.classList.add('dark-theme');
        localStorage.setItem('theme', 'dark');
    }

    // Initialize particles effect
    initParticles();
}

// Initialize particles background
function initParticles() {
    const particles = [];
    const particleCount = 50;

    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * 100,
            y: Math.random() * 100,
            size: Math.random() * 3 + 1,
            speedX: (Math.random() - 0.5) * 0.5,
            speedY: (Math.random() - 0.5) * 0.5
        });
    }

    function animateParticles() {
        // Animation logic would go here
        // For now, just a placeholder
        requestAnimationFrame(animateParticles);
    }

    animateParticles();
}

// Handle terms checkbox change
function handleTermsCheckbox() {
    agreeContinueBtn.disabled = !termsCheckbox.checked;
}

// Handle Agree & Continue
function handleAgreeContinue() {
    const email = emailInput.value.trim();
    if (!email) {
        showAuthMessage('Please enter your email address', 'error');
        shakeElement(emailInput);
        return;
    }

    if (!termsCheckbox.checked) {
        showAuthMessage('Please agree to the Terms of Service and Privacy Policy', 'error');
        shakeElement(termsContainer);
        return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showAuthMessage('Please enter a valid email address', 'error');
        shakeElement(emailInput);
        return;
    }

    // Hide agree button and show OTP sending UI
    agreeContinueBtn.style.display = 'none';
    termsContainer.style.display = 'none';
    sendOtpBtn.style.display = 'block';

    // Auto-trigger OTP sending
    sendOTP();
}

// Shake element animation
function shakeElement(element) {
    element.classList.add('shake');
    setTimeout(() => {
        element.classList.remove('shake');
    }, 500);
}

// Start OTP countdown timer
function startOTPTimer() {
    otpCountdown = 60;
    const countdownElement = document.getElementById('countdown');

    if (countdownInterval) {
        clearInterval(countdownInterval);
    }

    countdownInterval = setInterval(() => {
        otpCountdown--;
        if (countdownElement) {
            countdownElement.textContent = otpCountdown;
        }

        if (otpCountdown <= 0) {
            clearInterval(countdownInterval);
            otpTimer.style.display = 'none';
            resendLink.style.display = 'block';
        }
    }, 1000);
}

// Handle OTP resend
function handleResendOTP(e) {
    e.preventDefault();
    sendOTP();
}

// Send OTP
async function sendOTP() {
    const email = emailInput.value.trim();
    if (!email) {
        showAuthMessage('Please enter your email address', 'error');
        return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showAuthMessage('Please enter a valid email address', 'error');
        return;
    }

    try {
        // Show loading state
        if (sendOtpBtn.style.display !== 'none') {
            sendOtpText.style.display = 'none';
            sendOtpSpinner.style.display = 'block';
            sendOtpBtn.disabled = true;
        }

        const response = await fetch('/send-otp', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email })
        });

        const data = await response.json();

        // Reset button state
        sendOtpText.style.display = 'block';
        sendOtpSpinner.style.display = 'none';
        sendOtpBtn.disabled = false;

        if (data.status === 'ok') {
            showAuthMessage('OTP sent to your email', 'success');
            otpContainer.style.display = 'block';
            verifyOtpBtn.style.display = 'block';
            sendOtpBtn.style.display = 'none';

            // Add timer and resend link
            if (!otpContainer.contains(otpTimer)) {
                otpContainer.appendChild(otpTimer);
            }
            if (!otpContainer.contains(resendLink)) {
                otpContainer.appendChild(resendLink);
            }

            // Start countdown timer
            startOTPTimer();
            otpTimer.style.display = 'block';
            resendLink.style.display = 'none';

            // Focus on first OTP input
            setTimeout(() => {
                otpInputs[0].focus();
            }, 100);

            showToast('OTP sent successfully', 'success');
        } else {
            showAuthMessage(data.msg, 'error');
            showToast(data.msg, 'error');
        }
    } catch (error) {
        // Reset button state
        sendOtpText.style.display = 'block';
        sendOtpSpinner.style.display = 'none';
        sendOtpBtn.disabled = false;

        showAuthMessage('Error sending OTP. Please check your connection.', 'error');
        showToast('Error sending OTP', 'error');
        console.error('Error:', error);
    }
}

// Verify OTP
async function verifyOTP() {
    const email = emailInput.value.trim();
    const code = otpCode;
    const username = usernameInput.value.trim() || undefined;

    if (!email || code.length !== 6) {
        showAuthMessage('Please enter both email and complete OTP', 'error');
        return;
    }

    // Validate OTP format
    const otpRegex = /^\d{6}$/;
    if (!otpRegex.test(code)) {
        showAuthMessage('Please enter a valid 6-digit OTP', 'error');
        return;
    }

    try {
        // Show loading state
        verifyOtpText.style.display = 'none';
        verifyOtpSpinner.style.display = 'block';
        verifyOtpBtn.disabled = true;

        // Show loading steps
        loadingSteps.style.display = 'block';
        updateLoadingSteps(0);

        const response = await fetch('/verify-otp', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, code, username })
        });

        const data = await response.json();

        if (data.status === 'ok') {
            updateLoadingSteps(1);

            // Simulate initialization steps
            setTimeout(() => {
                updateLoadingSteps(2);

                setTimeout(() => {
                    currentUser = data.user;
                    localStorage.setItem('currentUser', JSON.stringify(currentUser));
                    showMainScreen();
                    loadUserData();

                    showToast('Login successful!', 'success');

                    // Clear OTP inputs
                    otpInputs.forEach(input => input.value = '');
                    otpCode = '';

                    // Reset auth form for next time
                    resetAuthForm();
                }, 1000);
            }, 1000);
        } else {
            // Reset button state
            verifyOtpText.style.display = 'block';
            verifyOtpSpinner.style.display = 'none';
            verifyOtpBtn.disabled = false;
            loadingSteps.style.display = 'none';

            showAuthMessage(data.msg, 'error');
            showToast(data.msg, 'error');

            // Clear OTP inputs on error
            otpInputs.forEach(input => input.value = '');
            otpCode = '';
            otpInputs[0].focus();
        }
    } catch (error) {
        // Reset button state
        verifyOtpText.style.display = 'block';
        verifyOtpSpinner.style.display = 'none';
        verifyOtpBtn.disabled = false;
        loadingSteps.style.display = 'none';

        showAuthMessage('Error verifying OTP. Please try again.', 'error');
        showToast('Error verifying OTP', 'error');
        console.error('Error:', error);
    }
}


// Update loading steps
function updateLoadingSteps(stepIndex) {
    const steps = loadingSteps.querySelectorAll('.loading-step');
    steps.forEach((step, index) => {
        const icon = step.querySelector('i');
        if (index < stepIndex) {
            icon.className = 'fas fa-check-circle step-completed';
        } else if (index === stepIndex) {
            icon.className = 'fas fa-spinner fa-spin step-loading';
        } else {
            icon.className = 'fas fa-circle step-pending';
        }
    });
}

// Reset auth form
function resetAuthForm() {
    emailInput.value = '';
    usernameInput.value = '';
    otpInputs.forEach(input => input.value = '');
    otpCode = '';
    otpContainer.style.display = 'none';
    verifyOtpBtn.style.display = 'none';
    sendOtpBtn.style.display = 'block';
    termsContainer.style.display = 'block';
    agreeContinueBtn.style.display = 'block';
    loadingSteps.style.display = 'none';
    termsCheckbox.checked = false;
    agreeContinueBtn.disabled = true;

    if (countdownInterval) {
        clearInterval(countdownInterval);
    }

    if (otpContainer.contains(otpTimer)) {
        otpContainer.removeChild(otpTimer);
    }
    if (otpContainer.contains(resendLink)) {
        otpContainer.removeChild(resendLink);
    }

    // Remove focused classes
    inputGroups.forEach(group => {
        group.classList.remove('focused');
    });
}

// Show authentication message
function showAuthMessage(msg, type) {
    authMessage.textContent = msg;
    authMessage.className = `auth-message ${type}`;
    authMessage.style.display = 'block';

    // Auto-hide success messages
    if (type === 'success') {
        setTimeout(() => {
            authMessage.style.display = 'none';
        }, 3000);
    }
}

// Show toast notification
function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    let icon = 'fa-info-circle';
    if (type === 'success') icon = 'fa-check-circle';
    if (type === 'error') icon = 'fa-exclamation-circle';

    toast.innerHTML = `<i class="fas ${icon}"></i> ${message}`;
    toastContainer.appendChild(toast);

    // Remove toast after animation completes
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Show main screen
function showMainScreen() {
    // Hide splash screen
    if (splashScreen) {
        splashScreen.style.display = 'none';
    }

    authScreen.classList.remove('active');
    mainScreen.classList.add('active');

    // Make currentUser globally accessible
    window.currentUser = currentUser;

    // Trigger main screen initialization
    if (window.initChat) {
        window.initChat();
    }
    if (window.initMain) {
        window.initMain();
    }
}

// Load user data (contacts and chats)
async function loadUserData() {
    if (!currentUser) return;

    try {
        // Load contacts
        const contactsResponse = await fetch(`/contacts/${currentUser.email}`);
        if (contactsResponse.ok) {
            const contacts = await contactsResponse.json();
            if (window.renderContacts) {
                window.renderContacts(contacts);
            }
        }

        // Load user profile if not already set
        if (!currentUser.profile) {
            currentUser.profile = {
                name: currentUser.username,
                about: "Hey there! I'm using Nexus Chat",
                avatar: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23667eea'%3E%3Cpath d='M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-6.627 0-12 5.373-12 12h24c0-6.627-5.373-12-12-12z'/%3E%3C/svg%3E",
                lastSeen: new Date().toISOString()
            };
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
        }

        // Update user status to online
        await fetch('/online-status', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: currentUser.email, online: true })
        });

        // Connect to socket.io
        connectSocket();
    } catch (error) {
        console.error('Error loading user data:', error);
        showToast('Error loading contacts', 'error');
    }
}

// Connect to socket.io
function connectSocket() {
    window.socket = io();

    socket.on('connect', () => {
        console.log('Connected to server');
        socket.emit('user-login', currentUser.email);
    });

    socket.on('new-message', (message) => {
        if (window.handleNewMessage) {
            window.handleNewMessage(message);
        }
    });

    socket.on('message-status-updated', (data) => {
        if (window.updateMessageStatus) {
            window.updateMessageStatus(data.messageId, data.status);
        }
    });

    socket.on('user-online', (email) => {
        if (window.updateUserOnlineStatus) {
            window.updateUserOnlineStatus(email, true);
        }
    });

    socket.on('user-offline', (email) => {
        if (window.updateUserOnlineStatus) {
            window.updateUserOnlineStatus(email, false);
        }
    });

    socket.on('typing', (data) => {
        if (window.handleTypingIndicator) {
            window.handleTypingIndicator(data);
        }
    });

    socket.on('messages-seen', (data) => {
        if (window.handleMessagesSeen) {
            window.handleMessagesSeen(data);
        }
    });

    socket.on('profile-updated', (data) => {
        if (data.email === currentUser.email) {
            currentUser = data.user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            if (window.updateProfileUI) {
                window.updateProfileUI();
            }
        }
    });

    socket.on('user-status-updated', (data) => {
        if (window.updateUserOnlineStatus) {
            window.updateUserOnlineStatus(data.email, data.online);
        }
    });

    socket.on('contact-added', (contact) => {
        if (window.handleNewContact) {
            window.handleNewContact(contact);
        }
    });

    socket.on('disconnect', () => {
        console.log('Disconnected from server');
    });
}

// Handle email input for terms display
emailInput.addEventListener('blur', () => {
    const email = emailInput.value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (email && emailRegex.test(email)) {
        termsContainer.style.display = 'block';
        agreeContinueBtn.style.display = 'block';
        sendOtpBtn.style.display = 'none';
    }
});

// Handle Enter key
emailInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        if (agreeContinueBtn.style.display === 'block') {
            handleAgreeContinue();
        } else if (sendOtpBtn.style.display === 'block') {
            sendOTP();
        }
    }
});

usernameInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        if (agreeContinueBtn.style.display === 'block') {
            handleAgreeContinue();
        } else if (sendOtpBtn.style.display === 'block') {
            sendOTP();
        }
    }
});

// Initialize the app when the page loads
document.addEventListener('DOMContentLoaded', init);

// Export functions for other scripts
window.authFunctions = {
    showAuthMessage,
    showToast,
    resetAuthForm,
    currentUser: () => currentUser
};
// Expose auth functions globally  
window.showMainScreen = showMainScreen;
window.loadUserData = loadUserData;
