// =====================================
// NEXUS CHAT - MAIN APPLICATION MODULE
// Profile, Settings, Modals, and Global Functions
// =====================================

// DOM Elements
const userProfileBtn = document.getElementById('user-profile-btn');
const newChatBtn = document.getElementById('new-chat-btn');
const menuBtn = document.getElementById('menu-btn');
const profileModal = document.getElementById('profile-modal');
const addContactModal = document.getElementById('add-contact-modal');
const menuModal = document.getElementById('menu-modal');
const closeModalButtons = document.querySelectorAll('.close');
const changeAvatarBtn = document.getElementById('change-avatar-btn');
const avatarUpload = document.getElementById('avatar-upload');
const profileAvatarPreview = document.getElementById('profile-avatar-preview');
const profileName = document.getElementById('profile-name');
const profileAbout = document.getElementById('profile-about');
const saveProfileBtn = document.getElementById('save-profile-btn');
const contactEmailInput = document.getElementById('contact-email-input');
const contactSearchResults = document.getElementById('contact-search-results');
const addContactBtn = document.getElementById('add-contact-btn');
const userAvatar = document.getElementById('user-avatar');
const logoutBtn = document.getElementById('logout-btn');
const menuProfile = document.getElementById('menu-profile');
const userStatus = document.getElementById('user-status');
const menuCreateGroup = document.getElementById('menu-create-group');
const menuCreateBroadcast = document.getElementById('menu-create-broadcast');
const menuNotifications = document.getElementById('menu-notifications');
const menuThemes = document.getElementById('menu-themes');
const menuSettings = document.getElementById('menu-settings');
const themeModal = document.getElementById('theme-modal');
const notificationsModal = document.getElementById('notifications-modal');
const settingsModal = document.getElementById('settings-modal');
const createGroupModal = document.getElementById('create-group-modal');
const createBroadcastModal = document.getElementById('create-broadcast-modal');
const groupAvatarUpload = document.getElementById('group-avatar-upload');
const changeGroupAvatarBtn = document.getElementById('change-group-avatar-btn');
const groupNameInput = document.getElementById('group-name');
const groupMembersSearch = document.getElementById('group-members-search');
const membersList = document.getElementById('members-list');
const selectedMembers = document.getElementById('selected-members');
const createGroupBtn = document.getElementById('create-group-btn');
const broadcastNameInput = document.getElementById('broadcast-name');
const broadcastMembersSearch = document.getElementById('broadcast-members-search');
const broadcastMembersList = document.getElementById('broadcast-members-list');
const broadcastSelectedMembers = document.getElementById('broadcast-selected-members');
const createBroadcastBtn = document.getElementById('create-broadcast-btn');
const notificationsToggle = document.getElementById('notifications-toggle');
const soundToggle = document.getElementById('sound-toggle');
const vibrationToggle = document.getElementById('vibration-toggle');
const previewToggle = document.getElementById('preview-toggle');
const themeOptions = document.querySelectorAll('.theme-option');
const lastSeenSetting = document.getElementById('last-seen-setting');
const profilePhotoSetting = document.getElementById('profile-photo-setting');
const autoDownloadSetting = document.getElementById('auto-download-setting');
const backupToggle = document.getElementById('backup-toggle');
const backupNowBtn = document.getElementById('backup-now-btn');
const qrBtn = document.getElementById('qr-btn');
const qrModal = document.getElementById('qr-modal');
const qrCode = document.getElementById('qr-code');
const downloadQrBtn = document.getElementById('download-qr-btn');
const menuHelp = document.getElementById('menu-help');

// Default avatar
const DEFAULT_AVATAR = 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'%237C3AED\'%3E%3Cpath d=\'M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-6.627 0-12 5.373-12 12h24c0-6.627-5.373-12-12-12z\'/%3E%3C/svg%3E';
const DEFAULT_GROUP_AVATAR = 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'%237C3AED\'%3E%3Cpath d=\'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z\'/%3E%3C/svg%3E';

// User settings
let userSettings = {
    theme: 'dark',
    notifications: true,
    sound: true,
    vibration: true,
    preview: true,
    lastSeen: 'everyone',
    profilePhoto: 'everyone',
    autoDownload: 'wifi',
    backup: false
};

// Selected members for group/broadcast
let selectedGroupMembers = new Set();
let selectedBroadcastMembers = new Set();

// ===== INITIALIZATION =====
function initMain() {
    loadUserSettings();
    setupEventListeners();
    updateProfileUI();
    generateQRCode();
}

// ===== EVENT LISTENERS =====
function setupEventListeners() {
    // Profile button
    if (userProfileBtn) {
        userProfileBtn.addEventListener('click', () => openModal(profileModal));
    }

    // New chat button
    if (newChatBtn) {
        newChatBtn.addEventListener('click', () => openModal(addContactModal));
    }

    // Menu button
    if (menuBtn) {
        menuBtn.addEventListener('click', () => openModal(menuModal));
    }

    // QR button
    if (qrBtn) {
        qrBtn.addEventListener('click', () => openModal(qrModal));
    }

    // Close buttons
    closeModalButtons.forEach(btn => {
        btn.addEventListener('click', closeModals);
    });

    // Avatar upload
    if (changeAvatarBtn) {
        changeAvatarBtn.addEventListener('click', () => avatarUpload.click());
    }
    if (avatarUpload) {
        avatarUpload.addEventListener('change', handleAvatarUpload);
    }

    // Save profile
    if (saveProfileBtn) {
        saveProfileBtn.addEventListener('click', saveProfile);
    }

    // Add contact
    if (addContactBtn) {
        addContactBtn.addEventListener('click', addContact);
    }
    if (contactEmailInput) {
        contactEmailInput.addEventListener('input', searchUsers);
    }

    // Logout
    if (logoutBtn) {
        logoutBtn.addEventListener('click', logout);
    }

    // Menu items
    if (menuProfile) {
        menuProfile.addEventListener('click', () => {
            closeModals();
            openModal(profileModal);
        });
    }

    if (menuCreateGroup) {
        menuCreateGroup.addEventListener('click', () => {
            closeModals();
            openModal(createGroupModal);
            loadContactsForGroup();
        });
    }

    if (menuCreateBroadcast) {
        menuCreateBroadcast.addEventListener('click', () => {
            closeModals();
            openModal(createBroadcastModal);
            loadContactsForBroadcast();
        });
    }

    if (menuNotifications) {
        menuNotifications.addEventListener('click', () => {
            closeModals();
            openModal(notificationsModal);
        });
    }

    if (menuThemes) {
        menuThemes.addEventListener('click', () => {
            closeModals();
            openModal(themeModal);
        });
    }

    if (menuSettings) {
        menuSettings.addEventListener('click', () => {
            closeModals();
            openModal(settingsModal);
        });
    }

    if (menuHelp) {
        menuHelp.addEventListener('click', () => {
            showToast('Help & Support', 'info');
            window.open('https://nexus.chat/support', '_blank');
        });
    }

    // Theme selection
    themeOptions.forEach(option => {
        option.addEventListener('click', () => {
            const theme = option.dataset.theme;
            changeTheme(theme);
        });
    });

    // Group creation
    if (changeGroupAvatarBtn) {
        changeGroupAvatarBtn.addEventListener('click', () => groupAvatarUpload.click());
    }
    if (groupAvatarUpload) {
        groupAvatarUpload.addEventListener('change', handleGroupAvatarUpload);
    }
    if (groupNameInput) {
        groupNameInput.addEventListener('input', updateCreateGroupButton);
    }
    if (groupMembersSearch) {
        groupMembersSearch.addEventListener('input', searchGroupMembers);
    }
    if (createGroupBtn) {
        createGroupBtn.addEventListener('click', createGroup);
    }

    // Broadcast creation
    if (broadcastNameInput) {
        broadcastNameInput.addEventListener('input', updateCreateBroadcastButton);
    }
    if (broadcastMembersSearch) {
        broadcastMembersSearch.addEventListener('input', searchBroadcastMembers);
    }
    if (createBroadcastBtn) {
        createBroadcastBtn.addEventListener('click', createBroadcast);
    }

    // Notification toggles
    if (notificationsToggle) {
        notificationsToggle.addEventListener('change', updateNotificationSettings);
    }
    if (soundToggle) {
        soundToggle.addEventListener('change', updateNotificationSettings);
    }
    if (vibrationToggle) {
        vibrationToggle.addEventListener('change', updateNotificationSettings);
    }
    if (previewToggle) {
        previewToggle.addEventListener('change', updateNotificationSettings);
    }

    // Settings
    if (lastSeenSetting) {
        lastSeenSetting.addEventListener('change', updateSettings);
    }
    if (profilePhotoSetting) {
        profilePhotoSetting.addEventListener('change', updateSettings);
    }
    if (autoDownloadSetting) {
        autoDownloadSetting.addEventListener('change', updateSettings);
    }
    if (backupToggle) {
        backupToggle.addEventListener('change', updateSettings);
    }
    if (backupNowBtn) {
        backupNowBtn.addEventListener('click', backupNow);
    }

    // QR code
    if (downloadQrBtn) {
        downloadQrBtn.addEventListener('click', downloadQRCode);
    }

    // Click outside modals
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            closeModals();
        }
    });

    // Handle visibility change (online/offline)
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Before unload
    window.addEventListener('beforeunload', handleBeforeUnload);
}

// ===== MODAL FUNCTIONS =====

// Open modal
function openModal(modal) {
    if (!modal) return;
    
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';

    // Load data based on modal type
    if (modal === profileModal) {
        loadProfileData();
    }
    if (modal === qrModal) {
        generateQRCode();
    }
}

// Close all modals
function closeModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.classList.remove('active');
    });
    document.body.style.overflow = '';

    // Clear search inputs
    if (contactEmailInput) contactEmailInput.value = '';
    if (contactSearchResults) contactSearchResults.innerHTML = '';
    if (groupMembersSearch) groupMembersSearch.value = '';
    if (broadcastMembersSearch) broadcastMembersSearch.value = '';
}

// ===== PROFILE FUNCTIONS =====

// Load profile data
function loadProfileData() {
    if (!currentUser) return;

    profileAvatarPreview.src = currentUser.profile?.avatar || DEFAULT_AVATAR;
    profileName.value = currentUser.profile?.name || currentUser.username || '';
    profileAbout.value = currentUser.profile?.about || 'Hey there! I\'m using Nexus Chat';
}

// Handle avatar upload
async function handleAvatarUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
        showToast('Please select an image file', 'error');
        return;
    }

    // Show preview
    const reader = new FileReader();
    reader.onload = (event) => {
        profileAvatarPreview.src = event.target.result;
    };
    reader.readAsDataURL(file);

    // Upload to server
    const formData = new FormData();
    formData.append('avatar', file);

    try {
        const response = await fetch('/upload-avatar', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();
        if (data.status === 'ok') {
            currentUser.profile.avatar = data.avatarUrl;
            showToast('Avatar uploaded', 'success');
        }
    } catch (error) {
        console.error('Error uploading avatar:', error);
        showToast('Failed to upload avatar', 'error');
    }
}

// Save profile
async function saveProfile() {
    if (!currentUser) return;

    try {
        const response = await fetch('/update-profile', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: currentUser.email,
                name: profileName.value,
                about: profileAbout.value,
                avatar: profileAvatarPreview.src
            })
        });

        const data = await response.json();
        if (data.status === 'ok') {
            currentUser = data.user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));

            updateProfileUI();
            closeModals();
            showToast('Profile saved successfully', 'success');
        } else {
            showToast(data.msg, 'error');
        }
    } catch (error) {
        console.error('Error updating profile:', error);
        showToast('Error saving profile', 'error');
    }
}

// Update profile UI
function updateProfileUI() {
    // Get currentUser from window scope (set by auth.js)
    const user = window.currentUser || (typeof currentUser !== 'undefined' ? currentUser : null);
    if (!user) return;

    if (userAvatar && user.profile?.avatar) {
        userAvatar.src = user.profile.avatar || DEFAULT_AVATAR;
    }
    if (userStatus) {
        userStatus.className = 'status-indicator online';
    }
}

// ===== CONTACT FUNCTIONS =====

// Search users
async function searchUsers() {
    const user = window.currentUser || (typeof currentUser !== 'undefined' ? currentUser : null);
    const query = contactEmailInput.value.trim();
    if (!query) {
        contactSearchResults.innerHTML = '';
        return;
    }

    try {
        const response = await fetch('/users');
        const users = await response.json();

        const filteredUsers = users.filter(u =>
            u.email !== (user?.email) &&
            (u.email.includes(query) ||
             (u.profile?.name && u.profile.name.toLowerCase().includes(query.toLowerCase())))
        );

        renderSearchResults(filteredUsers);
    } catch (error) {
        console.error('Error searching users:', error);
    }
}

// Render search results
function renderSearchResults(users) {
    contactSearchResults.innerHTML = '';

    if (users.length === 0) {
        contactSearchResults.innerHTML = '<div class="no-results">No users found</div>';
        return;
    }

    users.forEach(user => {
        const resultEl = document.createElement('div');
        resultEl.className = 'contact-result';
        resultEl.innerHTML = `
            <img src="${user.profile?.avatar || DEFAULT_AVATAR}" class="contact-result-avatar">
            <div class="contact-result-info">
                <div class="contact-result-name">${user.profile?.name || user.email}</div>
                <div class="contact-result-email">${user.email}</div>
            </div>
            <span class="status-indicator ${user.online ? 'online' : 'offline'}"></span>
        `;

        resultEl.addEventListener('click', () => {
            contactEmailInput.value = user.email;
            contactSearchResults.innerHTML = '';
        });

        contactSearchResults.appendChild(resultEl);
    });
}

// Add contact
async function addContact() {
    const contactEmail = contactEmailInput.value.trim();
    if (!contactEmail || !currentUser) return;

    try {
        const response = await fetch('/add-contact', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userEmail: currentUser.email,
                contactEmail
            })
        });

        const data = await response.json();
        if (data.status === 'ok') {
            // Reload contacts
            if (window.loadContacts) {
                window.loadContacts();
            }

            closeModals();
            contactEmailInput.value = '';
            showToast('Contact added successfully', 'success');

            // Open chat with new contact
            if (window.openChat) {
                setTimeout(() => window.openChat(data.contact), 500);
            }
        } else {
            showToast(data.msg, 'error');
        }
    } catch (error) {
        console.error('Error adding contact:', error);
        showToast('Error adding contact', 'error');
    }
}

// ===== GROUP FUNCTIONS =====

// Load contacts for group
async function loadContactsForGroup() {
    if (!currentUser || !membersList) return;

    try {
        const response = await fetch(`/contacts/${currentUser.email}`);
        if (response.ok) {
            const contacts = await response.json();
            renderMembersList(contacts, 'group');
        }
    } catch (error) {
        console.error('Error loading contacts:', error);
    }
}

// Render members list
function renderMembersList(contacts, type) {
    const container = type === 'group' ? membersList : broadcastMembersList;
    if (!container) return;

    container.innerHTML = '';

    if (!contacts || contacts.length === 0) {
        container.innerHTML = '<div class="no-results">No contacts found</div>';
        return;
    }

    contacts.forEach(contact => {
        const memberItem = document.createElement('div');
        memberItem.className = 'member-item';
        memberItem.dataset.email = contact.email;
        
        memberItem.innerHTML = `
            <img src="${contact.avatar || DEFAULT_AVATAR}" class="member-avatar">
            <span class="member-name">${contact.name}</span>
            <input type="checkbox" class="member-checkbox">
        `;

        const checkbox = memberItem.querySelector('.member-checkbox');
        checkbox.addEventListener('change', () => {
            if (checkbox.checked) {
                addSelectedMember(contact, type);
            } else {
                removeSelectedMember(contact.email, type);
            }
        });

        container.appendChild(memberItem);
    });
}

// Add selected member
function addSelectedMember(contact, type) {
    const container = type === 'group' ? selectedMembers : broadcastSelectedMembers;
    const set = type === 'group' ? selectedGroupMembers : selectedBroadcastMembers;

    if (set.has(contact.email)) return;

    set.add(contact.email);

    const selectedMember = document.createElement('div');
    selectedMember.className = 'selected-member';
    selectedMember.dataset.email = contact.email;
    
    selectedMember.innerHTML = `
        <img src="${contact.avatar || DEFAULT_AVATAR}" class="selected-member-avatar">
        <span>${contact.name}</span>
        <button class="remove-member" onclick="removeSelectedMember('${contact.email}', '${type}')">
            <i class="fas fa-times"></i>
        </button>
    `;

    container.appendChild(selectedMember);

    if (type === 'group') {
        updateCreateGroupButton();
    } else {
        updateCreateBroadcastButton();
    }
}

// Remove selected member (global function)
window.removeSelectedMember = function(email, type) {
    const container = type === 'group' ? selectedMembers : broadcastSelectedMembers;
    const set = type === 'group' ? selectedGroupMembers : selectedBroadcastMembers;

    set.delete(email);

    const memberToRemove = container.querySelector(`[data-email="${email}"]`);
    if (memberToRemove) {
        memberToRemove.remove();
    }

    // Uncheck checkbox
    const listContainer = type === 'group' ? membersList : broadcastMembersList;
    if (listContainer) {
        const checkbox = listContainer.querySelector(`[data-email="${email}"] .member-checkbox`);
        if (checkbox) {
            checkbox.checked = false;
        }
    }

    if (type === 'group') {
        updateCreateGroupButton();
    } else {
        updateCreateBroadcastButton();
    }
};

// Search group members
function searchGroupMembers() {
    const query = groupMembersSearch.value.toLowerCase();
    const items = membersList.querySelectorAll('.member-item');

    items.forEach(item => {
        const name = item.querySelector('.member-name').textContent.toLowerCase();
        const email = item.dataset.email.toLowerCase();

        if (name.includes(query) || email.includes(query)) {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
}

// Update create group button
function updateCreateGroupButton() {
    if (!createGroupBtn) return;

    const selectedCount = selectedGroupMembers.size;
    const groupName = groupNameInput.value.trim();
    createGroupBtn.disabled = selectedCount === 0 || !groupName;
}

// Create group
async function createGroup() {
    const groupName = groupNameInput.value.trim();
    const members = Array.from(selectedGroupMembers);

    if (!groupName || members.length === 0 || !currentUser) return;

    try {
        const response = await fetch('/create-group', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                creatorEmail: currentUser.email,
                groupName,
                members
            })
        });

        const data = await response.json();
        if (data.status === 'ok') {
            closeModals();
            showToast('Group created successfully', 'success');
            
            // Clear selections
            selectedGroupMembers.clear();
            selectedMembers.innerHTML = '';
            groupNameInput.value = '';

            // Refresh groups
            if (window.loadGroups) {
                window.loadGroups();
            }

            // Switch to groups tab
            document.querySelector('[data-tab="groups"]').click();
        } else {
            showToast(data.msg, 'error');
        }
    } catch (error) {
        console.error('Error creating group:', error);
        showToast('Error creating group', 'error');
    }
}

// ===== BROADCAST FUNCTIONS =====

// Load contacts for broadcast
async function loadContactsForBroadcast() {
    if (!currentUser || !broadcastMembersList) return;

    try {
        const response = await fetch(`/contacts/${currentUser.email}`);
        if (response.ok) {
            const contacts = await response.json();
            renderMembersList(contacts, 'broadcast');
        }
    } catch (error) {
        console.error('Error loading contacts:', error);
    }
}

// Search broadcast members
function searchBroadcastMembers() {
    const query = broadcastMembersSearch.value.toLowerCase();
    const items = broadcastMembersList.querySelectorAll('.member-item');

    items.forEach(item => {
        const name = item.querySelector('.member-name').textContent.toLowerCase();
        const email = item.dataset.email.toLowerCase();

        if (name.includes(query) || email.includes(query)) {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
}

// Update create broadcast button
function updateCreateBroadcastButton() {
    if (!createBroadcastBtn) return;

    const selectedCount = selectedBroadcastMembers.size;
    const broadcastName = broadcastNameInput.value.trim();
    createBroadcastBtn.disabled = selectedCount === 0 || !broadcastName;
}

// Create broadcast
async function createBroadcast() {
    const broadcastName = broadcastNameInput.value.trim();
    const members = Array.from(selectedBroadcastMembers);

    if (!broadcastName || members.length === 0 || !currentUser) return;

    try {
        const response = await fetch('/create-broadcast', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                creatorEmail: currentUser.email,
                name: broadcastName,
                members
            })
        });

        const data = await response.json();
        if (data.status === 'ok') {
            closeModals();
            showToast('Broadcast list created', 'success');
            
            // Clear selections
            selectedBroadcastMembers.clear();
            broadcastSelectedMembers.innerHTML = '';
            broadcastNameInput.value = '';

            // Refresh broadcasts
            if (window.loadBroadcasts) {
                window.loadBroadcasts();
            }

            // Switch to broadcasts tab
            document.querySelector('[data-tab="broadcasts"]').click();
        } else {
            showToast(data.msg, 'error');
        }
    } catch (error) {
        console.error('Error creating broadcast:', error);
        showToast('Error creating broadcast', 'error');
    }
}

// ===== GROUP AVATAR UPLOAD =====
function handleGroupAvatarUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
        showToast('Please select an image file', 'error');
        return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
        const groupAvatarPreview = document.getElementById('group-avatar-preview');
        if (groupAvatarPreview) {
            groupAvatarPreview.src = event.target.result;
        }
    };
    reader.readAsDataURL(file);
}

// ===== THEME FUNCTIONS =====

// Change theme
function changeTheme(theme) {
    const currentTheme = document.body.classList.contains('dark-theme') ? 'dark' : 'light';
    
    if (theme === 'system') {
        const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.body.classList.remove('light-theme', 'dark-theme');
        document.body.classList.add(systemDark ? 'dark-theme' : 'light-theme');
        userSettings.theme = 'system';
    } else {
        document.body.classList.remove('light-theme', 'dark-theme');
        document.body.classList.add(theme + '-theme');
        userSettings.theme = theme;
    }

    localStorage.setItem('theme', userSettings.theme);
    localStorage.setItem('userSettings', JSON.stringify(userSettings));

    // Update server
    if (currentUser) {
        fetch('/update-settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: currentUser.email,
                theme: userSettings.theme
            })
        }).catch(console.error);
    }

    highlightCurrentTheme();
    
    if (currentTheme !== theme) {
        showToast(`Theme changed to ${theme}`, 'success');
    }
}

// Highlight current theme
function highlightCurrentTheme() {
    themeOptions.forEach(option => {
        option.classList.remove('active');
        if (option.dataset.theme === userSettings.theme) {
            option.classList.add('active');
        }
    });
}

// ===== NOTIFICATION FUNCTIONS =====

// Load notification settings
function loadNotificationSettings() {
    const saved = localStorage.getItem('notificationSettings');
    if (saved) {
        const settings = JSON.parse(saved);
        if (notificationsToggle) notificationsToggle.checked = settings.notifications;
        if (soundToggle) soundToggle.checked = settings.sound;
        if (vibrationToggle) vibrationToggle.checked = settings.vibration;
        if (previewToggle) previewToggle.checked = settings.preview;
    }
}

// Update notification settings
function updateNotificationSettings() {
    const settings = {
        notifications: notificationsToggle?.checked || true,
        sound: soundToggle?.checked || true,
        vibration: vibrationToggle?.checked || true,
        preview: previewToggle?.checked || true
    };

    localStorage.setItem('notificationSettings', JSON.stringify(settings));
    
    // Update global
    window.messageSoundEnabled = settings.sound;

    showToast('Notification settings updated', 'success');
}

// ===== SETTINGS FUNCTIONS =====

// Load user settings
function loadUserSettings() {
    const saved = localStorage.getItem('userSettings');
    if (saved) {
        userSettings = JSON.parse(saved);
    }

    // Apply theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.body.classList.add(savedTheme + '-theme');
        userSettings.theme = savedTheme;
    } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.body.classList.add('dark-theme');
        userSettings.theme = 'dark';
        localStorage.setItem('theme', 'dark');
    }

    // Load notification settings
    loadNotificationSettings();

    // Set settings in UI
    if (lastSeenSetting) lastSeenSetting.value = userSettings.lastSeen;
    if (profilePhotoSetting) profilePhotoSetting.value = userSettings.profilePhoto;
    if (autoDownloadSetting) autoDownloadSetting.value = userSettings.autoDownload;
    if (backupToggle) backupToggle.checked = userSettings.backup;
}

// Update settings
function updateSettings() {
    userSettings.lastSeen = lastSeenSetting?.value || 'everyone';
    userSettings.profilePhoto = profilePhotoSetting?.value || 'everyone';
    userSettings.autoDownload = autoDownloadSetting?.value || 'wifi';
    userSettings.backup = backupToggle?.checked || false;

    localStorage.setItem('userSettings', JSON.stringify(userSettings));

    // Update server
    if (currentUser) {
        fetch('/update-settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: currentUser.email,
                ...userSettings
            })
        }).catch(console.error);
    }

    showToast('Settings updated', 'success');
}

// Backup now
function backupNow() {
    showToast('Backup started...', 'info');
    
    // Simulate backup
    setTimeout(() => {
        showToast('Backup completed', 'success');
    }, 2000);
}

// ===== QR CODE FUNCTIONS =====

// Generate QR code
function generateQRCode() {
    if (!qrCode || !currentUser) return;

    qrCode.innerHTML = '';

    const qrData = JSON.stringify({
        email: currentUser.email,
        name: currentUser.profile?.name || currentUser.username,
        avatar: currentUser.profile?.avatar
    });

    if (window.QRCode) {
        new QRCode(qrCode, {
            text: qrData,
            width: 200,
            height: 200,
            colorDark: "#7C3AED",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.H
        });
    } else {
        qrCode.innerHTML = '<p>QR code not available</p>';
    }
}

// Download QR code
function downloadQRCode() {
    const canvas = qrCode.querySelector('canvas');
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = `nexus-${currentUser.email}-qr.png`;
    link.href = canvas.toDataURL();
    link.click();

    showToast('QR code downloaded', 'success');
}

// ===== LOGOUT =====

// Logout
async function logout() {
    if (!currentUser) return;

    try {
        await fetch('/logout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: currentUser.email })
        });

        if (window.socket) {
            window.socket.disconnect();
        }

        localStorage.removeItem('currentUser');
        
        // Clear chats
        for (const key in localStorage) {
            if (key.startsWith('chat_')) localStorage.removeItem(key);
        }

        currentUser = null;
        
        // Show auth screen
        document.getElementById('auth-screen').classList.add('active');
        document.getElementById('main-screen').classList.remove('active');

        showToast('Logged out successfully', 'success');
    } catch (error) {
        console.error('Error logging out:', error);
        showToast('Error logging out', 'error');
    }
}

// ===== VISIBILITY HANDLERS =====

// Handle visibility change
function handleVisibilityChange() {
    if (!currentUser) return;

    if (document.hidden) {
        // Page hidden - offline
        fetch('/online-status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: currentUser.email, online: false })
        });
    } else {
        // Page visible - online
        fetch('/online-status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: currentUser.email, online: true })
        });
    }
}

// Handle before unload
function handleBeforeUnload() {
    if (!currentUser) return;

    navigator.sendBeacon('/online-status', JSON.stringify({
        email: currentUser.email,
        online: false
    }));
}

// ===== TOAST NOTIFICATION =====

// Show toast
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let icon = 'fa-info-circle';
    if (type === 'success') icon = 'fa-check-circle';
    if (type === 'error') icon = 'fa-exclamation-circle';
    
    toast.innerHTML = `<i class="fas ${icon}"></i> ${message}`;
    container.appendChild(toast);
    
    setTimeout(() => {
        if (toast.parentNode) {
            toast.remove();
        }
    }, 3000);
}

// ===== RESIZE HANDLER =====
window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
        const sidebar = document.getElementById('sidebar');
        if (sidebar) sidebar.classList.remove('hidden');
        
        if (!window.currentChat) {
            const emptyChat = document.getElementById('empty-chat');
            if (emptyChat) emptyChat.style.display = 'flex';
        }
    }
});

// ===== INITIALIZE =====
document.addEventListener('DOMContentLoaded', initMain);

// ===== EXPORT FUNCTIONS =====
window.openModal = openModal;
window.closeModals = closeModals;
window.showToast = showToast;
window.changeTheme = changeTheme;
window.updateProfileUI = updateProfileUI;
// Expose functions globally
window.initMain = initMain;
