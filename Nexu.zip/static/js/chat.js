// =====================================
// NEXUS CHAT - CHAT MODULE
// Complete Chat Functionality with Voice, Media, Reactions & Real-time Updates
// =====================================

// DOM Elements
const chatList = document.getElementById('chat-list');
const groupsList = document.getElementById('groups-list');
const broadcastsList = document.getElementById('broadcasts-list');
const messagesContainer = document.getElementById('messages-container');
const messageInput = document.getElementById('message-input');
const sendMessageBtn = document.getElementById('send-message-btn');
const currentChatAvatar = document.getElementById('current-chat-avatar');
const currentChatName = document.getElementById('current-chat-name');
const currentChatStatus = document.getElementById('current-chat-status');
const chatStatusIndicator = document.getElementById('chat-status-indicator');
const searchContacts = document.getElementById('search-contacts');
const sidebar = document.getElementById('sidebar');
const chatArea = document.getElementById('chat-area');
const backButton = document.getElementById('back-button');
const emptyChat = document.getElementById('empty-chat');
const fileUpload = document.getElementById('file-upload');
const typingIndicator = document.getElementById('typing-indicator');
const typingText = document.getElementById('typing-text');
const selectionHeader = document.getElementById('selection-header');
const selectionCount = document.getElementById('selection-count');
const selectionBack = document.getElementById('selection-back');
const selectionDelete = document.getElementById('selection-delete');
const selectionMute = document.getElementById('selection-mute');
const selectionBlock = document.getElementById('selection-block');
const selectionRead = document.getElementById('selection-read');
const selectionArchive = document.getElementById('selection-archive');
const chatTabs = document.querySelectorAll('.chat-tab');
const attachMenuBtn = document.getElementById('attach-menu-btn');
const attachmentMenu = document.getElementById('attachment-menu');
const emojiPickerBtn = document.getElementById('emoji-picker-btn');
const emojiPicker = document.getElementById('emoji-picker');
const voiceRecordBtn = document.getElementById('voice-record-btn');
const voiceRecording = document.getElementById('voice-recording');
const voiceTimer = document.getElementById('voice-timer');
const cancelVoice = document.getElementById('cancel-voice');
const sendVoice = document.getElementById('send-voice');
const voiceCallBtn = document.getElementById('voice-call-btn');
const videoCallBtn = document.getElementById('video-call-btn');
const searchChatBtn = document.getElementById('search-chat-btn');
const chatMenuBtn = document.getElementById('chat-menu-btn');
const startNewChat = document.getElementById('start-new-chat');

// Chat state
let currentChat = null;
let contacts = [];
let groups = [];
let broadcasts = [];
let chats = {};
let groupChats = {};
let broadcastChats = {};
let selectedChats = new Set();
let messageSoundEnabled = true;
let typingTimeout = null;
let longPressTimer = null;
let isSelectionMode = false;
let currentChatType = 'contact'; // 'contact', 'group', 'broadcast'
let messageReactions = {};
let replyToMessage = null;
let editingMessage = null;

// Voice recording state
let mediaRecorder = null;
let audioChunks = [];
let recordingTimer = null;
let recordingSeconds = 0;
let recordingStream = null;

// Socket connection
const socket = io();

// ===== INITIALIZATION =====
function initChat() {
    setupLongPress();
    loadGroups();
    loadBroadcasts();
    setupChatMenu();
    setupBackButtonHandler();
    loadContacts();
    setupAttachmentMenu();
    setupEmojiPicker();
    setupVoiceRecording();
    setupMessageEvents();
    setupInfiniteScroll();
    
    // Listen for status updates
    socket.on('user-status-update', handleUserStatusUpdate);
    socket.on('user-status-updated', handleUserStatusUpdate);
    socket.on('new-group-message', handleNewGroupMessage);
    socket.on('new-broadcast-message', handleNewBroadcastMessage);
    socket.on('message-reaction', handleMessageReaction);
    socket.on('message-deleted', handleMessageDeleted);
    socket.on('message-edited', handleMessageEdited);
    socket.on('contact-added', handleNewContact);

    // Start new chat button
    if (startNewChat) {
        startNewChat.addEventListener('click', () => {
            window.openModal(document.getElementById('add-contact-modal'));
        });
    }
}

// ===== CONTACT MANAGEMENT =====

// Load contacts from server
async function loadContacts() {
    if (!currentUser) return;

    try {
        const response = await fetch(`/contacts/${currentUser.email}`);
        if (response.ok) {
            const serverContacts = await response.json();
            
            // Merge server contacts with local state
            serverContacts.forEach(serverContact => {
                const localContact = contacts.find(c => c.email === serverContact.email);
                if (localContact) {
                    serverContact.unreadCount = localContact.unreadCount || serverContact.unreadCount || 0;
                    serverContact.lastMessage = localContact.lastMessage || serverContact.lastMessage || 'No messages yet';
                }
            });
            
            contacts = serverContacts;
            renderContacts();
        }
    } catch (error) {
        console.error('Error loading contacts:', error);
        showToast('Error loading contacts', 'error');
    }
}

// Render contacts list
function renderContacts() {
    if (!chatList) return;
    
    chatList.innerHTML = '';

    if (!contacts || contacts.length === 0) {
        chatList.innerHTML = `
            <div class="no-contacts">
                <i class="fas fa-user-plus" style="font-size: 48px; margin-bottom: 16px; opacity: 0.5;"></i>
                <p>No contacts yet. Add some to start chatting!</p>
                <button class="nexus-btn secondary" onclick="window.openModal(document.getElementById('add-contact-modal'))" style="margin-top: 16px;">
                    <i class="fas fa-plus"></i> Add Contact
                </button>
            </div>
        `;
        return;
    }

    // Sort contacts by last message time (newest first)
    const sortedContacts = [...contacts].sort((a, b) => {
        const timeA = a.lastTime ? new Date(a.lastTime).getTime() : 0;
        const timeB = b.lastTime ? new Date(b.lastTime).getTime() : 0;
        return timeB - timeA;
    });

    sortedContacts.forEach((contact, index) => {
        const chatItem = createChatItem(contact, index);
        chatList.appendChild(chatItem);
    });
}

// Create chat item element
function createChatItem(contact, index) {
    const chatItem = document.createElement('div');
    chatItem.className = 'chat-item';
    chatItem.dataset.email = contact.email;
    chatItem.dataset.type = 'contact';
    chatItem.style.animationDelay = `${index * 0.1}s`;

    // Get last message
    let lastMessage = contact.lastMessage || 'No messages yet';
    let lastTime = contact.lastTime ? formatTime(contact.lastTime) : '';
    let unreadCount = contact.unreadCount > 0 ? `<div class="chat-unread">${contact.unreadCount}</div>` : '';
    
    // Get message status icon
    let statusIcon = '';
    if (chats[contact.email] && chats[contact.email].messages) {
        const lastMsg = chats[contact.email].messages[chats[contact.email].messages.length - 1];
        if (lastMsg && lastMsg.from === currentUser.email) {
            if (lastMsg.status === 'seen') {
                statusIcon = '<i class="fas fa-check-double" style="color: var(--nexus-online);"></i>';
            } else if (lastMsg.status === 'delivered') {
                statusIcon = '<i class="fas fa-check-double"></i>';
            } else {
                statusIcon = '<i class="fas fa-check"></i>';
            }
        }
    }

    chatItem.innerHTML = `
        <div class="chat-avatar-container">
            <img src="${contact.avatar || 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'%237C3AED\'%3E%3Cpath d=\'M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-6.627 0-12 5.373-12 12h24c0-6.627-5.373-12-12-12z\'/%3E%3C/svg%3E'}" class="chat-avatar" alt="${contact.name}">
            <span class="status-indicator ${contact.online ? 'online' : 'offline'}"></span>
        </div>
        <div class="chat-info">
            <div class="chat-name">
                <span>${contact.name}</span>
                ${unreadCount}
            </div>
            <div class="chat-last-msg">
                ${statusIcon ? statusIcon + ' ' : ''}${lastMessage}
            </div>
        </div>
        <div class="chat-meta">
            <div class="chat-time">${lastTime}</div>
            ${contact.typing ? '<div class="chat-typing">typing...</div>' : ''}
        </div>
    `;

    chatItem.addEventListener('click', (e) => {
        if (isSelectionMode) {
            toggleChatSelection(chatItem);
        } else {
            openChat(contact);
        }
    });

    return chatItem;
}

// ===== GROUP MANAGEMENT =====

// Load groups from server
async function loadGroups() {
    if (!currentUser) return;

    try {
        const response = await fetch(`/user-groups/${currentUser.email}`);
        if (response.ok) {
            groups = await response.json();
            renderGroups();
        }
    } catch (error) {
        console.error('Error loading groups:', error);
    }
}

// Render groups list
function renderGroups() {
    if (!groupsList) return;
    
    if (!groups || groups.length === 0) {
        groupsList.innerHTML = `
            <div class="no-contacts">
                <i class="fas fa-users" style="font-size: 48px; margin-bottom: 16px; opacity: 0.5;"></i>
                <p>No groups yet. Create your first group!</p>
                <button class="nexus-btn secondary" onclick="window.openModal(document.getElementById('create-group-modal'))" style="margin-top: 16px;">
                    <i class="fas fa-plus"></i> Create Group
                </button>
            </div>
        `;
        return;
    }

    groupsList.innerHTML = '';
    groups.sort((a, b) => {
        const timeA = a.lastMessageTime ? new Date(a.lastMessageTime).getTime() : 0;
        const timeB = b.lastMessageTime ? new Date(b.lastMessageTime).getTime() : 0;
        return timeB - timeA;
    });

    groups.forEach((group, index) => {
        const groupItem = document.createElement('div');
        groupItem.className = 'chat-item';
        groupItem.dataset.groupId = group.id;
        groupItem.dataset.type = 'group';
        groupItem.style.animationDelay = `${index * 0.1}s`;

        const lastMessage = group.lastMessage || 'No messages yet';
        const lastTime = group.lastMessageTime ? formatTime(group.lastMessageTime) : '';

        groupItem.innerHTML = `
            <div class="chat-avatar-container">
                <img src="${group.avatar || 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'%237C3AED\'%3E%3Cpath d=\'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z\'/%3E%3C/svg%3E'}" class="chat-avatar" alt="${group.name}">
            </div>
            <div class="chat-info">
                <div class="chat-name">${group.name}</div>
                <div class="chat-last-msg">${lastMessage}</div>
            </div>
            <div class="chat-meta">
                <div class="chat-time">${lastTime}</div>
            </div>
        `;

        groupItem.addEventListener('click', () => {
            openGroupChat(group);
        });

        groupsList.appendChild(groupItem);
    });
}

// ===== BROADCAST MANAGEMENT =====

// Load broadcasts from server
async function loadBroadcasts() {
    if (!currentUser) return;

    try {
        const response = await fetch(`/user-broadcasts/${currentUser.email}`);
        if (response.ok) {
            broadcasts = await response.json();
            renderBroadcasts();
        }
    } catch (error) {
        console.error('Error loading broadcasts:', error);
    }
}

// Render broadcasts list
function renderBroadcasts() {
    if (!broadcastsList) return;
    
    if (!broadcasts || broadcasts.length === 0) {
        broadcastsList.innerHTML = `
            <div class="no-contacts">
                <i class="fas fa-bullhorn" style="font-size: 48px; margin-bottom: 16px; opacity: 0.5;"></i>
                <p>No broadcast lists yet.</p>
                <button class="nexus-btn secondary" onclick="window.openModal(document.getElementById('create-broadcast-modal'))" style="margin-top: 16px;">
                    <i class="fas fa-plus"></i> Create Broadcast
                </button>
            </div>
        `;
        return;
    }

    broadcastsList.innerHTML = '';
    broadcasts.sort((a, b) => {
        const timeA = a.lastMessageTime ? new Date(a.lastMessageTime).getTime() : 0;
        const timeB = b.lastMessageTime ? new Date(b.lastMessageTime).getTime() : 0;
        return timeB - timeA;
    });

    broadcasts.forEach((broadcast, index) => {
        const broadcastItem = document.createElement('div');
        broadcastItem.className = 'chat-item';
        broadcastItem.dataset.broadcastId = broadcast.id;
        broadcastItem.dataset.type = 'broadcast';
        broadcastItem.style.animationDelay = `${index * 0.1}s`;

        const lastMessage = broadcast.lastMessage || 'No messages yet';
        const lastTime = broadcast.lastMessageTime ? formatTime(broadcast.lastMessageTime) : '';

        broadcastItem.innerHTML = `
            <div class="chat-avatar-container">
                <img src="${broadcast.avatar || 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'%237C3AED\'%3E%3Cpath d=\'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 4c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm0 13c-2.33 0-4.31-1.46-5.11-3.5h10.22c-.8 2.04-2.78 3.5-5.11 3.5z\'/%3E%3C/svg%3E'}" class="chat-avatar" alt="${broadcast.name}">
            </div>
            <div class="chat-info">
                <div class="chat-name">${broadcast.name}</div>
                <div class="chat-last-msg">${lastMessage}</div>
            </div>
            <div class="chat-meta">
                <div class="chat-time">${lastTime}</div>
            </div>
        `;

        broadcastItem.addEventListener('click', () => {
            openBroadcastChat(broadcast);
        });

        broadcastsList.appendChild(broadcastItem);
    });
}

// ===== CHAT OPENING FUNCTIONS =====

// Open chat with a contact
function openChat(contact) {
    currentChat = contact;
    currentChatType = 'contact';

    // Update UI
    currentChatAvatar.src = contact.avatar || currentChatAvatar.src;
    currentChatName.textContent = contact.name;

    // Update status
    updateChatStatus(contact);

    // Hide sidebar and show chat area on mobile
    if (window.innerWidth <= 768) {
        sidebar.classList.add('hidden');
        chatArea.style.display = 'flex';
        emptyChat.style.display = 'none';
        history.pushState({ chat: contact.email }, '');
    } else {
        emptyChat.style.display = 'none';
    }

    // Highlight active chat
    document.querySelectorAll('.chat-item').forEach(item => {
        item.classList.remove('active');
    });
    const selector = document.querySelector(`.chat-item[data-email="${contact.email}"]`);
    if (selector) selector.classList.add('active');

    // Load chat messages
    loadChatMessages(contact.email);

    // Focus on message input
    messageInput.focus();

    // Mark messages as seen
    markMessagesAsSeen();

    // Enable call buttons
    if (voiceCallBtn) voiceCallBtn.style.display = 'flex';
    if (videoCallBtn) videoCallBtn.style.display = 'flex';
}

// Open group chat
function openGroupChat(group) {
    currentChat = {
        ...group,
        isGroup: true,
        email: group.id,
        name: group.name,
        avatar: group.avatar
    };
    currentChatType = 'group';

    // Update UI
    currentChatAvatar.src = group.avatar || 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'%237C3AED\'%3E%3Cpath d=\'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z\'/%3E%3C/svg%3E';
    currentChatName.textContent = group.name;
    currentChatStatus.textContent = `${group.members.length} members`;
    chatStatusIndicator.className = 'status-indicator online';

    // Hide sidebar and show chat area on mobile
    if (window.innerWidth <= 768) {
        sidebar.classList.add('hidden');
        chatArea.style.display = 'flex';
        emptyChat.style.display = 'none';
        history.pushState({ groupChat: group.id }, '');
    } else {
        emptyChat.style.display = 'none';
    }

    // Load group messages
    loadGroupMessages(group.id);

    // Focus on message input
    messageInput.focus();

    // Disable call buttons for groups
    if (voiceCallBtn) voiceCallBtn.style.display = 'none';
    if (videoCallBtn) videoCallBtn.style.display = 'none';
}

// Open broadcast chat
function openBroadcastChat(broadcast) {
    currentChat = {
        ...broadcast,
        isBroadcast: true,
        email: broadcast.id,
        name: broadcast.name,
        avatar: broadcast.avatar
    };
    currentChatType = 'broadcast';

    // Update UI
    currentChatAvatar.src = broadcast.avatar || 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'%237C3AED\'%3E%3Cpath d=\'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 4c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm0 13c-2.33 0-4.31-1.46-5.11-3.5h10.22c-.8 2.04-2.78 3.5-5.11 3.5z\'/%3E%3C/svg%3E';
    currentChatName.textContent = broadcast.name;
    currentChatStatus.textContent = `${broadcast.members.length} recipients`;
    chatStatusIndicator.className = 'status-indicator online';

    // Hide sidebar and show chat area on mobile
    if (window.innerWidth <= 768) {
        sidebar.classList.add('hidden');
        chatArea.style.display = 'flex';
        emptyChat.style.display = 'none';
        history.pushState({ broadcastChat: broadcast.id }, '');
    } else {
        emptyChat.style.display = 'none';
    }

    // Load broadcast messages
    loadBroadcastMessages(broadcast.id);

    // Focus on message input
    messageInput.focus();

    // Disable call buttons for broadcasts
    if (voiceCallBtn) voiceCallBtn.style.display = 'none';
    if (videoCallBtn) videoCallBtn.style.display = 'none';
}

// Update chat status
function updateChatStatus(contact) {
    if (contact.online) {
        currentChatStatus.textContent = 'Online';
        currentChatStatus.style.color = 'var(--nexus-online)';
        chatStatusIndicator.className = 'status-indicator online';
    } else {
        const lastSeen = formatLastSeen(contact.lastSeen);
        currentChatStatus.textContent = lastSeen;
        currentChatStatus.style.color = 'var(--nexus-text-secondary)';
        chatStatusIndicator.className = 'status-indicator offline';
    }
}

// ===== MESSAGE LOADING =====

// Load chat messages
async function loadChatMessages(contactEmail) {
    if (!currentUser) return;

    try {
        const response = await fetch('/get-chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user1: currentUser.email,
                user2: contactEmail
            })
        });

        if (response.ok) {
            const chat = await response.json();
            chats[contactEmail] = chat || { messages: [] };

            // Update contact last message
            const contact = contacts.find(c => c.email === contactEmail);
            if (contact && chat.messages && chat.messages.length > 0) {
                const lastMsg = chat.messages[chat.messages.length - 1];
                contact.lastMessage = formatMessagePreview(lastMsg);
                contact.lastTime = lastMsg.timestamp;
            }
            
            renderMessages(chat.messages);
            renderContacts();
        }
    } catch (error) {
        console.error('Error loading chat messages:', error);
        showToast('Error loading messages', 'error');
    }
}

// Load group messages
async function loadGroupMessages(groupId) {
    if (!currentUser) return;

    try {
        const response = await fetch('/get-group-chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ groupId })
        });

        if (response.ok) {
            const chatData = await response.json();
            groupChats[groupId] = chatData.messages || [];
            renderMessages(chatData.messages || []);
        }
    } catch (error) {
        console.error('Error loading group messages:', error);
        showToast('Error loading group messages', 'error');
    }
}

// Load broadcast messages
async function loadBroadcastMessages(broadcastId) {
    if (!currentUser) return;

    try {
        const response = await fetch('/get-broadcast-chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ broadcastId })
        });

        if (response.ok) {
            const chatData = await response.json();
            broadcastChats[broadcastId] = chatData.messages || [];
            renderMessages(chatData.messages || []);
        }
    } catch (error) {
        console.error('Error loading broadcast messages:', error);
        showToast('Error loading broadcast messages', 'error');
    }
}

// ===== MESSAGE RENDERING =====

// Render messages
function renderMessages(messages) {
    if (!messagesContainer) return;
    
    messagesContainer.innerHTML = '';

    if (!messages || messages.length === 0) {
        messagesContainer.innerHTML = `
            <div class="welcome-message">
                <div class="welcome-icon">
                    <i class="fas fa-comments"></i>
                </div>
                <h3>Start a conversation</h3>
                <p>Say hello to ${currentChat.name}</p>
            </div>
        `;
        return;
    }

    let lastDate = null;
    messages.forEach(msg => {
        // Add date separator if needed
        const msgDate = new Date(msg.timestamp).toDateString();
        if (msgDate !== lastDate) {
            addDateSeparator(msg.timestamp);
            lastDate = msgDate;
        }
        
        addMessageToUI(msg, false);
    });

    // Scroll to bottom
    scrollToBottom();
}

// Add date separator
function addDateSeparator(timestamp) {
    const date = new Date(timestamp);
    const today = new Date().toDateString();
    const yesterday = new Date(Date.now() - 86400000).toDateString();
    
    let dateText = '';
    if (date.toDateString() === today) {
        dateText = 'Today';
    } else if (date.toDateString() === yesterday) {
        dateText = 'Yesterday';
    } else {
        dateText = date.toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
    }

    const separator = document.createElement('div');
    separator.className = 'date-separator';
    separator.innerHTML = `<span>${dateText}</span>`;
    messagesContainer.appendChild(separator);
}

// Add message to UI
function addMessageToUI(msg, animate = true) {
    if (!messagesContainer) return;
    
    const messageEl = document.createElement('div');
    const isOutgoing = msg.from === currentUser.email;

    messageEl.className = `message ${isOutgoing ? 'message-outgoing' : 'message-incoming'}`;
    if (animate) {
        messageEl.style.animation = 'messageSlide 0.3s ease';
    }
    messageEl.dataset.messageId = msg.id;

    // Check if message is deleted
    if (msg.deleted) {
        messageEl.innerHTML = `
            <div class="message-bubble message-deleted">
                <div class="message-text">
                    <i class="fas fa-trash"></i> This message was deleted
                </div>
                <div class="message-time">
                    ${formatTime(msg.timestamp)}
                </div>
            </div>
        `;
        messagesContainer.appendChild(messageEl);
        return;
    }

    // Build message content based on type
    let messageContent = buildMessageContent(msg);
    
    // Add reply preview if this is a reply
    let replyPreview = '';
    if (msg.replyTo) {
        replyPreview = buildReplyPreview(msg.replyTo);
    }

    // Add status icon for outgoing messages
    let statusIcon = '';
    if (isOutgoing) {
        statusIcon = getStatusIcon(msg.status);
    }

    // Add reactions if any
    let reactionsHTML = '';
    if (msg.reactions && msg.reactions.length > 0) {
        reactionsHTML = buildReactionsHTML(msg.reactions, msg.id);
    }

    messageEl.innerHTML = `
        <div class="message-bubble">
            ${replyPreview}
            ${messageContent}
            <div class="message-time">
                ${formatTime(msg.timestamp)}
                ${statusIcon}
                ${msg.edited ? '<span class="message-edited">edited</span>' : ''}
            </div>
            ${reactionsHTML}
        </div>
    `;

    // Add context menu
    messageEl.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        showMessageContextMenu(msg, e.clientX, e.clientY);
    });

    messagesContainer.appendChild(messageEl);

    // Scroll to bottom if this is a new message
    if (animate) {
        scrollToBottom();

        // Play sound for incoming messages
        if (!isOutgoing && messageSoundEnabled) {
            playMessageSound('received');
        }
    }
}

// Build message content based on type
function buildMessageContent(msg) {
    switch (msg.type) {
        case 'image':
            return `
                <div class="message-image" onclick="window.viewMedia('${msg.message}', 'image')">
                    <img src="${msg.message}" alt="Shared image" loading="lazy">
                    <div class="image-actions">
                        <button onclick="window.downloadMedia('${msg.message}', 'image-${msg.id}.jpg'); event.stopPropagation();">
                            <i class="fas fa-download"></i>
                        </button>
                    </div>
                </div>
            `;
        
        case 'video':
            return `
                <div class="message-video">
                    <video controls preload="metadata">
                        <source src="${msg.message}" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>
            `;
        
        case 'audio':
            return `
                <div class="message-audio">
                    <audio controls preload="metadata">
                        <source src="${msg.message}" type="audio/mpeg">
                        Your browser does not support the audio element.
                    </audio>
                </div>
            `;
        
        case 'voice':
            return `
                <div class="message-audio voice-message">
                    <div class="voice-player" data-src="${msg.message}">
                        <i class="fas fa-play-circle play-btn"></i>
                        <div class="voice-waveform" id="waveform-${msg.id}"></div>
                        <span class="voice-duration">${msg.duration || '0:00'}</span>
                    </div>
                </div>
            `;
        
        case 'file':
            const fileName = msg.fileName || 'File';
            const fileSize = msg.fileSize ? formatFileSize(msg.fileSize) : '';
            return `
                <div class="message-file" onclick="window.downloadMedia('${msg.message}', '${fileName}')">
                    <i class="fas fa-file"></i>
                    <div class="file-info">
                        <div class="file-name">${fileName}</div>
                        ${fileSize ? `<div class="file-size">${fileSize}</div>` : ''}
                    </div>
                    <div class="file-download">
                        <i class="fas fa-download"></i>
                    </div>
                </div>
            `;
        
        default:
            return `<div class="message-text">${linkify(msg.message)}</div>`;
    }
}

// Build reply preview
function buildReplyPreview(replyTo) {
    const originalMsg = findMessageById(replyTo);
    if (!originalMsg) return '';

    return `
        <div class="message-reply" onclick="scrollToMessage('${replyTo}')">
            <div class="reply-sender">${originalMsg.from === currentUser.email ? 'You' : originalMsg.senderName || originalMsg.from}</div>
            <div class="reply-content">${originalMsg.message.substring(0, 50)}${originalMsg.message.length > 50 ? '...' : ''}</div>
        </div>
    `;
}

// Build reactions HTML
function buildReactionsHTML(reactions, messageId) {
    const reactionCounts = {};
    reactions.forEach(r => {
        reactionCounts[r.reaction] = (reactionCounts[r.reaction] || 0) + 1;
    });

    let html = '<div class="message-reactions">';
    for (const [reaction, count] of Object.entries(reactionCounts)) {
        const userReacted = reactions.some(r => r.user === currentUser.email && r.reaction === reaction);
        html += `
            <div class="reaction ${userReacted ? 'active' : ''}" onclick="window.toggleReaction('${messageId}', '${reaction}')">
                ${reaction} <span class="reaction-count">${count}</span>
            </div>
        `;
    }
    html += '</div>';
    return html;
}

// Get status icon
function getStatusIcon(status) {
    switch (status) {
        case 'sent':
            return '<i class="fas fa-check message-status sent"></i>';
        case 'delivered':
            return '<i class="fas fa-check-double message-status delivered"></i>';
        case 'seen':
            return '<i class="fas fa-check-double message-status seen" style="color: var(--nexus-online);"></i>';
        default:
            return '';
    }
}

// ===== MESSAGE ACTIONS =====

// Send message
async function sendMessage() {
    if (currentChatType === 'group') {
        await sendGroupMessage();
        return;
    }
    if (currentChatType === 'broadcast') {
        await sendBroadcastMessage();
        return;
    }

    let message = messageInput.value.trim();
    const file = fileUpload.files[0];
    let type = 'text';

    if (!message && !file) return;
    if (!currentChat || !currentUser) return;

    try {
        // If there's a file, upload it first
        if (file) {
            showToast('Uploading file...', 'info');
            const formData = new FormData();
            formData.append('file', file);
            
            const uploadResponse = await fetch('/upload-file', {
                method: 'POST',
                body: formData
            });

            const uploadData = await uploadResponse.json();
            if (uploadData.status === 'ok') {
                message = uploadData.fileUrl;
                type = uploadData.fileType;
            } else {
                showToast('Failed to upload file', 'error');
                return;
            }
        }

        const response = await fetch('/send-message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                from: currentUser.email,
                to: currentChat.email,
                message,
                type,
                replyTo: replyToMessage ? replyToMessage.id : null,
                fileName: file ? file.name : null,
                fileSize: file ? file.size : null
            })
        });

        const data = await response.json();
        if (data.status === 'ok') {
            // Add message to data model
            if (!chats[currentChat.email]) {
                chats[currentChat.email] = { messages: [] };
            }
            chats[currentChat.email].messages.push(data.message);

            // Update contact last message
            const contact = contacts.find(c => c.email === currentChat.email);
            if (contact) {
                contact.lastMessage = formatMessagePreview(data.message);
                contact.lastTime = data.message.timestamp;
            }

            addMessageToUI(data.message, true);

            // Play sent sound
            playMessageSound('sent');

            // Clear input and reset
            clearMessageInput();
            
            // Update contact list
            renderContacts();

            // Clear reply
            if (replyToMessage) {
                clearReply();
            }
        }
    } catch (error) {
        console.error('Error sending message:', error);
        showToast('Error sending message', 'error');
    }
}

// Send group message
async function sendGroupMessage() {
    let message = messageInput.value.trim();
    const file = fileUpload.files[0];
    let type = 'text';

    if (!message && !file) return;
    if (!currentChat || !currentUser) return;

    try {
        if (file) {
            showToast('Uploading file...', 'info');
            const formData = new FormData();
            formData.append('file', file);
            
            const uploadResponse = await fetch('/upload-file', {
                method: 'POST',
                body: formData
            });

            const uploadData = await uploadResponse.json();
            if (uploadData.status === 'ok') {
                message = uploadData.fileUrl;
                type = uploadData.fileType;
            } else {
                showToast('Failed to upload file', 'error');
                return;
            }
        }

        const response = await fetch('/send-group-message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                groupId: currentChat.email,
                from: currentUser.email,
                message,
                type,
                replyTo: replyToMessage ? replyToMessage.id : null
            })
        });

        const data = await response.json();
        if (data.status === 'ok') {
            if (!groupChats[currentChat.email]) {
                groupChats[currentChat.email] = [];
            }
            groupChats[currentChat.email].push(data.message);

            // Update group last message
            const group = groups.find(g => g.id === currentChat.email);
            if (group) {
                group.lastMessage = formatMessagePreview(data.message);
                group.lastMessageTime = data.message.timestamp;
            }

            addMessageToUI(data.message, true);
            playMessageSound('sent');
            clearMessageInput();
            renderGroups();

            if (replyToMessage) {
                clearReply();
            }
        }
    } catch (error) {
        console.error('Error sending group message:', error);
        showToast('Error sending message', 'error');
    }
}

// Send broadcast message
async function sendBroadcastMessage() {
    let message = messageInput.value.trim();
    const file = fileUpload.files[0];
    let type = 'text';

    if (!message && !file) return;
    if (!currentChat || !currentUser) return;

    try {
        if (file) {
            showToast('Uploading file...', 'info');
            const formData = new FormData();
            formData.append('file', file);
            
            const uploadResponse = await fetch('/upload-file', {
                method: 'POST',
                body: formData
            });

            const uploadData = await uploadResponse.json();
            if (uploadData.status === 'ok') {
                message = uploadData.fileUrl;
                type = uploadData.fileType;
            } else {
                showToast('Failed to upload file', 'error');
                return;
            }
        }

        const response = await fetch('/send-broadcast', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                broadcastId: currentChat.email,
                from: currentUser.email,
                message,
                type
            })
        });

        const data = await response.json();
        if (data.status === 'ok') {
            if (!broadcastChats[currentChat.email]) {
                broadcastChats[currentChat.email] = [];
            }
            broadcastChats[currentChat.email].push(data.message);

            addMessageToUI(data.message, true);
            playMessageSound('sent');
            clearMessageInput();
        }
    } catch (error) {
        console.error('Error sending broadcast message:', error);
        showToast('Error sending message', 'error');
    }
}

// ===== REAL-TIME HANDLERS =====

// Handle new message from socket
function handleNewMessage(message) {
    if (!message) return;

    const chatEmail = message.from === currentUser.email ? message.to : message.from;

    // Add or update contact
    let contact = contacts.find(c => c.email === chatEmail);
    if (!contact) {
        // Create temporary contact
        contact = {
            email: chatEmail,
            name: message.fromName || chatEmail.split('@')[0],
            avatar: message.fromAvatar || '',
            online: false,
            lastMessage: formatMessagePreview(message),
            lastTime: message.timestamp,
            unreadCount: 0
        };
        contacts.unshift(contact);
    } else {
        // Update existing contact
        contact.lastMessage = formatMessagePreview(message);
        contact.lastTime = message.timestamp;
    }

    // Add to chats
    if (!chats[chatEmail]) {
        chats[chatEmail] = { messages: [] };
    }
    chats[chatEmail].messages.push(message);

    // Update unread count for incoming messages
    if (message.from !== currentUser.email) {
        contact.unreadCount = (contact.unreadCount || 0) + 1;
    }

    // Check if this is the current chat
    const isCurrentChat = currentChat && 
        (message.from === currentChat.email || message.to === currentChat.email);

    if (isCurrentChat) {
        addMessageToUI(message, true);

        // Mark as delivered and seen
        if (message.from !== currentUser.email) {
            updateMessageStatus(message.id, 'delivered');
            setTimeout(() => {
                updateMessageStatus(message.id, 'seen');
                contact.unreadCount = Math.max(0, (contact.unreadCount || 0) - 1);
            }, 1000);
        }
    }

    // Re-render contacts
    renderContacts();
}

// Handle new group message
function handleNewGroupMessage(message) {
    if (!message) return;

    // Update group last message
    const group = groups.find(g => g.id === message.groupId);
    if (group) {
        group.lastMessage = formatMessagePreview(message);
        group.lastMessageTime = message.timestamp;
    }

    // Add to group chats
    if (!groupChats[message.groupId]) {
        groupChats[message.groupId] = [];
    }
    groupChats[message.groupId].push(message);

    // Check if this is the current group
    const isCurrentChat = currentChat && currentChat.isGroup && currentChat.email === message.groupId;

    if (isCurrentChat) {
        addMessageToUI(message, true);
    }

    renderGroups();
}

// Handle new broadcast message
function handleNewBroadcastMessage(message) {
    if (!message) return;

    // Update broadcast last message
    const broadcast = broadcasts.find(b => b.id === message.broadcastId);
    if (broadcast) {
        broadcast.lastMessage = formatMessagePreview(message);
        broadcast.lastMessageTime = message.timestamp;
    }

    // Add to broadcast chats
    if (!broadcastChats[message.broadcastId]) {
        broadcastChats[message.broadcastId] = [];
    }
    broadcastChats[message.broadcastId].push(message);

    // Check if this is the current broadcast
    const isCurrentChat = currentChat && currentChat.isBroadcast && currentChat.email === message.broadcastId;

    if (isCurrentChat) {
        addMessageToUI(message, true);
    }

    renderBroadcasts();
}

// ===== MESSAGE STATUS =====

// Update message status
function updateMessageStatus(messageId, status) {
    // Update UI
    const messages = messagesContainer.querySelectorAll('.message-outgoing');
    messages.forEach(message => {
        const timeElement = message.querySelector('.message-time');
        if (timeElement) {
            const statusIcon = timeElement.querySelector('.message-status');
            if (statusIcon) {
                if (status === 'delivered') {
                    statusIcon.className = 'fas fa-check-double message-status delivered';
                } else if (status === 'seen') {
                    statusIcon.className = 'fas fa-check-double message-status seen';
                    statusIcon.style.color = 'var(--nexus-online)';
                }
            }
        }
    });

    // Update data model
    for (const chatEmail in chats) {
        chats[chatEmail].messages.forEach(m => {
            if (m.id === messageId) {
                m.status = status;
            }
        });
    }
}

// Mark messages as seen
async function markMessagesAsSeen() {
    if (!currentUser || !currentChat || currentChat.isGroup || currentChat.isBroadcast) return;

    try {
        await fetch('/mark-messages-seen', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userEmail: currentUser.email,
                contactEmail: currentChat.email
            })
        });

        const contact = contacts.find(c => c.email === currentChat.email);
        if (contact) {
            contact.unreadCount = 0;
        }

        // Update message statuses in data model
        if (chats[currentChat.email]) {
            chats[currentChat.email].messages.forEach(m => {
                if (m.from === currentChat.email && m.to === currentUser.email) {
                    m.status = 'seen';
                }
            });
        }

        renderContacts();
    } catch (error) {
        console.error('Error marking messages as seen:', error);
    }
}

// ===== TYPING INDICATOR =====

// Handle typing
function handleTyping() {
    if (!currentChat || currentChat.isGroup || currentChat.isBroadcast) return;

    socket.emit('typing', {
        to: currentChat.email,
        typing: true
    });

    if (typingTimeout) clearTimeout(typingTimeout);

    typingTimeout = setTimeout(() => {
        socket.emit('typing', {
            to: currentChat.email,
            typing: false
        });
    }, 1000);
}

// Handle incoming typing indicator
function handleTypingIndicator(data) {
    if (!currentChat || data.from !== currentChat.email) return;

    if (data.typing) {
        typingText.textContent = `${currentChat.name} is typing...`;
        typingIndicator.style.display = 'flex';
        
        // Update contact typing status
        const contact = contacts.find(c => c.email === data.from);
        if (contact) {
            contact.typing = true;
            renderContacts();
        }
    } else {
        typingIndicator.style.display = 'none';
        
        const contact = contacts.find(c => c.email === data.from);
        if (contact) {
            contact.typing = false;
            renderContacts();
        }
    }
}

// ===== REACTIONS =====

// Toggle reaction on message
async function toggleReaction(messageId, reaction) {
    if (!currentUser || !currentChat) return;

    try {
        const chatId = currentChat.isGroup ? currentChat.email : 
                      [currentUser.email, currentChat.email].sort().join('_');

        const response = await fetch('/add-reaction', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                chatId,
                messageId,
                userEmail: currentUser.email,
                reaction
            })
        });

        const data = await response.json();
        if (data.status === 'ok') {
            // Update UI will be handled by socket event
        }
    } catch (error) {
        console.error('Error adding reaction:', error);
    }
}

// Handle message reaction from socket
function handleMessageReaction(data) {
    const messageEl = document.querySelector(`[data-message-id="${data.messageId}"]`);
    if (messageEl) {
        const reactionsContainer = messageEl.querySelector('.message-reactions');
        if (reactionsContainer) {
            reactionsContainer.innerHTML = buildReactionsHTML(data.reactions, data.messageId);
        }
    }
}

// ===== EDIT/DELETE MESSAGES =====

// Delete message
async function deleteMessage(messageId) {
    if (!currentUser || !currentChat) return;

    if (!confirm('Are you sure you want to delete this message?')) return;

    try {
        const chatId = currentChat.isGroup ? currentChat.email : 
                      [currentUser.email, currentChat.email].sort().join('_');

        const response = await fetch('/delete-message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                chatId,
                messageId,
                userEmail: currentUser.email
            })
        });

        if (response.ok) {
            const messageEl = document.querySelector(`[data-message-id="${messageId}"]`);
            if (messageEl) {
                messageEl.remove();
            }
            showToast('Message deleted', 'success');
        }
    } catch (error) {
        console.error('Error deleting message:', error);
        showToast('Error deleting message', 'error');
    }
}

// Edit message
async function editMessage(messageId, newMessage) {
    if (!currentUser || !currentChat || !newMessage.trim()) return;

    try {
        const chatId = currentChat.isGroup ? currentChat.email : 
                      [currentUser.email, currentChat.email].sort().join('_');

        const response = await fetch('/edit-message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                chatId,
                messageId,
                userEmail: currentUser.email,
                newMessage: newMessage.trim()
            })
        });

        const data = await response.json();
        if (data.status === 'ok') {
            const messageEl = document.querySelector(`[data-message-id="${messageId}"]`);
            if (messageEl) {
                const textEl = messageEl.querySelector('.message-text');
                if (textEl) {
                    textEl.textContent = newMessage.trim();
                }
                const timeEl = messageEl.querySelector('.message-time');
                if (timeEl && !timeEl.querySelector('.message-edited')) {
                    timeEl.innerHTML += '<span class="message-edited">edited</span>';
                }
            }
            showToast('Message edited', 'success');
        }
    } catch (error) {
        console.error('Error editing message:', error);
        showToast('Error editing message', 'error');
    }
}

// Handle message deleted from socket
function handleMessageDeleted(data) {
    const messageEl = document.querySelector(`[data-message-id="${data.messageId}"]`);
    if (messageEl) {
        messageEl.innerHTML = `
            <div class="message-bubble message-deleted">
                <div class="message-text">
                    <i class="fas fa-trash"></i> This message was deleted
                </div>
            </div>
        `;
    }
}

// Handle message edited from socket
function handleMessageEdited(data) {
    const messageEl = document.querySelector(`[data-message-id="${data.messageId}"]`);
    if (messageEl) {
        const textEl = messageEl.querySelector('.message-text');
        if (textEl) {
            textEl.textContent = data.newMessage;
        }
        const timeEl = messageEl.querySelector('.message-time');
        if (timeEl && !timeEl.querySelector('.message-edited')) {
            timeEl.innerHTML += '<span class="message-edited">edited</span>';
        }
    }
}

// ===== MESSAGE CONTEXT MENU =====

// Show message context menu
function showMessageContextMenu(msg, x, y) {
    const menu = document.createElement('div');
    menu.className = 'message-context-menu';
    menu.style.left = `${x}px`;
    menu.style.top = `${y}px`;
    menu.style.zIndex = '2000';

    const isOutgoing = msg.from === currentUser.email;

    let menuItems = '';

    // Reply option
    menuItems += `
        <div class="context-menu-item" onclick="window.setReplyTo('${msg.id}')">
            <i class="fas fa-reply"></i> Reply
        </div>
    `;

    // Copy option for text messages
    if (msg.type === 'text') {
        menuItems += `
            <div class="context-menu-item" onclick="window.copyMessage('${msg.message.replace(/'/g, "\\'")}')">
                <i class="fas fa-copy"></i> Copy
            </div>
        `;
    }

    // Forward option
    menuItems += `
        <div class="context-menu-item" onclick="window.forwardMessage('${msg.id}')">
            <i class="fas fa-forward"></i> Forward
        </div>
    `;

    // Edit option for own messages
    if (isOutgoing && msg.type === 'text') {
        menuItems += `
            <div class="context-menu-item" onclick="window.editMessagePrompt('${msg.id}', '${msg.message.replace(/'/g, "\\'")}')">
                <i class="fas fa-edit"></i> Edit
            </div>
        `;
    }

    // Delete option for own messages
    if (isOutgoing) {
        menuItems += `
            <div class="context-menu-item delete" onclick="window.deleteMessage('${msg.id}')">
                <i class="fas fa-trash"></i> Delete
            </div>
        `;
    }

    // Star option
    menuItems += `
        <div class="context-menu-item" onclick="window.starMessage('${msg.id}')">
            <i class="fas fa-star"></i> Star
        </div>
    `;

    menu.innerHTML = menuItems;

    document.body.appendChild(menu);

    // Close menu on click outside
    setTimeout(() => {
        document.addEventListener('click', function closeMenu(e) {
            if (!menu.contains(e.target)) {
                menu.remove();
                document.removeEventListener('click', closeMenu);
            }
        });
    }, 100);
}

// Set reply to message
function setReplyTo(messageId) {
    const msg = findMessageById(messageId);
    if (!msg) return;

    replyToMessage = msg;
    
    // Show reply preview
    const replyPreview = document.createElement('div');
    replyPreview.className = 'reply-preview';
    replyPreview.id = 'reply-preview';
    replyPreview.innerHTML = `
        <div class="reply-info">
            <i class="fas fa-reply"></i>
            <span>Replying to ${msg.from === currentUser.email ? 'yourself' : msg.senderName || msg.from}</span>
        </div>
        <div class="reply-content">${msg.message.substring(0, 50)}${msg.message.length > 50 ? '...' : ''}</div>
        <i class="fas fa-times" onclick="window.clearReply()"></i>
    `;

    // Insert before message input
    const inputContainer = document.querySelector('.message-input-container');
    document.querySelector('.chat-area').insertBefore(replyPreview, inputContainer);
}

// Clear reply
function clearReply() {
    replyToMessage = null;
    const replyPreview = document.getElementById('reply-preview');
    if (replyPreview) {
        replyPreview.remove();
    }
}

// Copy message
function copyMessage(text) {
    navigator.clipboard.writeText(text).then(() => {
        showToast('Message copied', 'success');
    });
}

// Edit message prompt
function editMessagePrompt(messageId, currentText) {
    const newText = prompt('Edit message:', currentText);
    if (newText !== null && newText.trim() !== currentText) {
        editMessage(messageId, newText);
    }
}

// ===== VOICE RECORDING =====

// Setup voice recording
function setupVoiceRecording() {
    if (!voiceRecordBtn) return;

    voiceRecordBtn.addEventListener('click', startVoiceRecording);
    cancelVoice.addEventListener('click', cancelVoiceRecording);
    sendVoice.addEventListener('click', sendVoiceMessage);
}

// Start voice recording
async function startVoiceRecording() {
    try {
        recordingStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        mediaRecorder = new MediaRecorder(recordingStream);
        audioChunks = [];

        mediaRecorder.ondataavailable = event => {
            audioChunks.push(event.data);
        };

        mediaRecorder.onstop = async () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
            const audioUrl = URL.createObjectURL(audioBlob);
            
            // Show recording interface
            voiceRecording.style.display = 'flex';
            voiceRecordBtn.style.display = 'none';
            
            // Start timer
            recordingSeconds = 0;
            updateVoiceTimer();
            recordingTimer = setInterval(updateVoiceTimer, 1000);
        };

        mediaRecorder.start();
        showToast('Recording started...', 'info');
    } catch (error) {
        console.error('Error starting recording:', error);
        showToast('Could not access microphone', 'error');
    }
}

// Update voice timer
function updateVoiceTimer() {
    const minutes = Math.floor(recordingSeconds / 60);
    const seconds = recordingSeconds % 60;
    voiceTimer.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    recordingSeconds++;
}

// Cancel voice recording
function cancelVoiceRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        recordingStream.getTracks().forEach(track => track.stop());
    }
    
    voiceRecording.style.display = 'none';
    voiceRecordBtn.style.display = 'block';
    clearInterval(recordingTimer);
    audioChunks = [];
}

// Send voice message
async function sendVoiceMessage() {
    if (audioChunks.length === 0) return;

    const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
    const formData = new FormData();
    formData.append('audio', audioBlob, 'voice-message.webm');
    formData.append('duration', voiceTimer.textContent);

    try {
        showToast('Uploading voice message...', 'info');
        
        const response = await fetch('/upload-voice', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();
        if (data.status === 'ok') {
            // Send as voice message
            messageInput.value = data.fileUrl;
            await sendMessage();
        }
    } catch (error) {
        console.error('Error uploading voice:', error);
        showToast('Failed to send voice message', 'error');
    }

    // Clean up
    cancelVoiceRecording();
}

// ===== EMOJI PICKER =====

// Setup emoji picker
function setupEmojiPicker() {
    if (!emojiPickerBtn || !emojiPicker) return;

    emojiPickerBtn.addEventListener('click', toggleEmojiPicker);
}

// Toggle emoji picker
function toggleEmojiPicker() {
    if (emojiPicker.style.display === 'none') {
        emojiPicker.style.display = 'block';
    } else {
        emojiPicker.style.display = 'none';
    }
}

// ===== ATTACHMENT MENU =====

// Setup attachment menu
function setupAttachmentMenu() {
    if (!attachMenuBtn || !attachmentMenu) return;

    attachMenuBtn.addEventListener('click', toggleAttachmentMenu);

    // Handle attachment options
    document.querySelectorAll('.attachment-item').forEach(item => {
        item.addEventListener('click', () => {
            const type = item.dataset.type;
            handleAttachment(type);
            attachmentMenu.style.display = 'none';
        });
    });

    // Close on click outside
    document.addEventListener('click', (e) => {
        if (!attachMenuBtn.contains(e.target) && !attachmentMenu.contains(e.target)) {
            attachmentMenu.style.display = 'none';
        }
    });
}

// Toggle attachment menu
function toggleAttachmentMenu() {
    if (attachmentMenu.style.display === 'none') {
        attachmentMenu.style.display = 'grid';
    } else {
        attachmentMenu.style.display = 'none';
    }
}

// Handle attachment
function handleAttachment(type) {
    switch (type) {
        case 'camera':
            // Open camera
            fileUpload.accept = 'image/*';
            fileUpload.capture = 'camera';
            fileUpload.click();
            break;
        case 'image':
            fileUpload.accept = 'image/*';
            fileUpload.multiple = true;
            fileUpload.click();
            break;
        case 'document':
            fileUpload.accept = '.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip';
            fileUpload.click();
            break;
        case 'contact':
            openShareContact();
            break;
        case 'location':
            shareLocation();
            break;
    }
}

// ===== SELECTION MODE =====

// Setup long press for selection
function setupLongPress() {
    let longPressActive = false;

    chatList.addEventListener('mousedown', (e) => {
        const chatItem = e.target.closest('.chat-item');
        if (chatItem) {
            longPressTimer = setTimeout(() => {
                longPressActive = true;
                enterSelectionMode();
                toggleChatSelection(chatItem);
            }, 500);
        }
    });

    chatList.addEventListener('mouseup', () => {
        clearTimeout(longPressTimer);
    });

    chatList.addEventListener('mouseleave', () => {
        clearTimeout(longPressTimer);
    });

    // Touch events for mobile
    chatList.addEventListener('touchstart', (e) => {
        const chatItem = e.target.closest('.chat-item');
        if (chatItem) {
            longPressTimer = setTimeout(() => {
                enterSelectionMode();
                toggleChatSelection(chatItem);
            }, 500);
        }
    });

    chatList.addEventListener('touchend', () => {
        clearTimeout(longPressTimer);
    });

    chatList.addEventListener('touchmove', () => {
        clearTimeout(longPressTimer);
    });
}

// Enter selection mode
function enterSelectionMode() {
    isSelectionMode = true;
    selectionHeader.style.display = 'flex';
    document.querySelectorAll('.chat-item').forEach(item => {
        item.style.cursor = 'pointer';
    });
}

// Exit selection mode
function exitSelectionMode() {
    isSelectionMode = false;
    selectionHeader.style.display = 'none';
    selectedChats.clear();
    updateSelectionCount();
    document.querySelectorAll('.chat-item').forEach(item => {
        item.classList.remove('selected');
        item.style.cursor = 'pointer';
    });
}

// Toggle chat selection
function toggleChatSelection(chatItem) {
    const id = chatItem.dataset.email || chatItem.dataset.groupId || chatItem.dataset.broadcastId;
    if (selectedChats.has(id)) {
        selectedChats.delete(id);
        chatItem.classList.remove('selected');
    } else {
        selectedChats.add(id);
        chatItem.classList.add('selected');
    }
    updateSelectionCount();
}

// Update selection count
function updateSelectionCount() {
    selectionCount.textContent = `${selectedChats.size} selected`;
    
    const hasSelection = selectedChats.size > 0;
    selectionDelete.style.opacity = hasSelection ? 1 : 0.5;
    selectionMute.style.opacity = hasSelection ? 1 : 0.5;
    selectionBlock.style.opacity = hasSelection ? 1 : 0.5;
    selectionRead.style.opacity = hasSelection ? 1 : 0.5;
    selectionArchive.style.opacity = hasSelection ? 1 : 0.5;
}

// Delete selected chats
async function deleteSelectedChats() {
    if (selectedChats.size === 0) return;

    if (!confirm(`Delete ${selectedChats.size} conversation(s)?`)) return;

    for (const id of selectedChats) {
        // Find which list this belongs to
        const contact = contacts.find(c => c.email === id);
        if (contact) {
            await fetch('/delete-contact', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userEmail: currentUser.email,
                    contactEmail: id
                })
            });
            contacts = contacts.filter(c => c.email !== id);
            delete chats[id];
        }
    }

    renderContacts();
    exitSelectionMode();
    showToast('Conversations deleted', 'success');
}

// ===== UTILITY FUNCTIONS =====

// Format time
function formatTime(timestamp) {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (days === 1) {
        return 'Yesterday';
    } else if (days < 7) {
        return date.toLocaleDateString([], { weekday: 'short' });
    } else {
        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
}

// Format last seen
function formatLastSeen(timestamp) {
    if (!timestamp) return 'Unknown';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);

    if (diff < 60) return 'Last seen just now';
    if (diff < 3600) return `Last seen ${Math.floor(diff / 60)} minutes ago`;
    if (diff < 86400) return `Last seen ${Math.floor(diff / 3600)} hours ago`;
    if (diff < 604800) return `Last seen ${Math.floor(diff / 86400)} days ago`;
    
    return `Last seen ${date.toLocaleDateString()}`;
}

// Format message preview
function formatMessagePreview(msg) {
    if (!msg) return 'No messages yet';
    
    switch (msg.type) {
        case 'image': return '📷 Photo';
        case 'video': return '🎥 Video';
        case 'audio': return '🎵 Audio';
        case 'voice': return '🎤 Voice message';
        case 'file': return '📄 File';
        default: return msg.message;
    }
}

// Format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Linkify text
function linkify(text) {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    return text.replace(urlRegex, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
}

// Find message by ID
function findMessageById(messageId) {
    if (currentChatType === 'group') {
        return groupChats[currentChat.email]?.find(m => m.id === messageId);
    } else if (currentChatType === 'broadcast') {
        return broadcastChats[currentChat.email]?.find(m => m.id === messageId);
    } else {
        return chats[currentChat.email]?.messages.find(m => m.id === messageId);
    }
}

// Scroll to bottom
function scrollToBottom() {
    messagesContainer.scrollTo({
        top: messagesContainer.scrollHeight,
        behavior: 'smooth'
    });
}

// Scroll to message
function scrollToMessage(messageId) {
    const messageEl = document.querySelector(`[data-message-id="${messageId}"]`);
    if (messageEl) {
        messageEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        messageEl.classList.add('highlight');
        setTimeout(() => messageEl.classList.remove('highlight'), 2000);
    }
}

// Play message sound
function playMessageSound(type) {
    const sound = document.getElementById(`message-${type}-sound`);
    if (sound && messageSoundEnabled) {
        sound.currentTime = 0;
        sound.play().catch(e => console.log('Audio play failed:', e));
    }
}

// Clear message input
function clearMessageInput() {
    messageInput.value = '';
    fileUpload.value = '';
    toggleSendButton();
}

// Toggle send button
function toggleSendButton() {
    if (messageInput.value.trim() || fileUpload.files.length > 0) {
        sendMessageBtn.classList.add('active');
    } else {
        sendMessageBtn.classList.remove('active');
    }
}

// Show toast
function showToast(message, type = 'info') {
    if (window.showToast) {
        window.showToast(message, type);
    }
}

// ===== EVENT LISTENERS =====

// Send message on click
sendMessageBtn.addEventListener('click', sendMessage);

// Send message on Enter
messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
});

// Toggle send button on input
messageInput.addEventListener('input', toggleSendButton);

// Handle typing
messageInput.addEventListener('input', handleTyping);

// File upload
fileUpload.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        toggleSendButton();
        showToast(`${e.target.files.length} file(s) selected`, 'info');
    }
});

// Search contacts
searchContacts.addEventListener('input', filterContacts);

// Back button
backButton.addEventListener('click', showChatList);

// Selection actions
selectionBack.addEventListener('click', exitSelectionMode);
selectionDelete.addEventListener('click', deleteSelectedChats);

// Tab switching
chatTabs.forEach(tab => {
    tab.addEventListener('click', () => {
        const tabName = tab.dataset.tab;
        switchTab(tabName);
    });
});

// Switch tabs
function switchTab(tabName) {
    chatTabs.forEach(tab => {
        tab.classList.remove('active');
        if (tab.dataset.tab === tabName) {
            tab.classList.add('active');
        }
    });

    chatList.style.display = tabName === 'chats' ? 'block' : 'none';
    groupsList.style.display = tabName === 'groups' ? 'block' : 'none';
    broadcastsList.style.display = tabName === 'broadcasts' ? 'block' : 'none';
}

// Filter contacts
function filterContacts() {
    const query = searchContacts.value.toLowerCase();
    
    document.querySelectorAll('.chat-item').forEach(item => {
        const name = item.querySelector('.chat-name').textContent.toLowerCase();
        const lastMsg = item.querySelector('.chat-last-msg').textContent.toLowerCase();
        
        item.style.display = name.includes(query) || lastMsg.includes(query) ? 'flex' : 'none';
    });
}

// Show chat list (mobile)
function showChatList() {
    sidebar.classList.remove('hidden');
    chatArea.style.display = 'none';
    
    if (window.innerWidth > 768 && !currentChat) {
        emptyChat.style.display = 'flex';
    }

    currentChat = null;
    
    if (isSelectionMode) {
        exitSelectionMode();
    }
    
    history.replaceState({}, '', window.location.pathname);
}

// Handle new contact
function handleNewContact(contact) {
    contacts.unshift(contact);
    renderContacts();
    showToast(`${contact.name} added to contacts`, 'success');
}

// Handle user status update
function handleUserStatusUpdate(data) {
    if (!data || !data.email) return;

    const contact = contacts.find(c => c.email === data.email);
    if (contact) {
        contact.online = data.online;
        if (!data.online && data.lastSeen) {
            contact.lastSeen = data.lastSeen;
        }
    }

    updateUserStatusUI(data.email, data.online, data.lastSeen);

    if (currentChat && currentChat.email === data.email) {
        updateChatStatus(contact || { online: data.online, lastSeen: data.lastSeen });
    }

    renderContacts();
}

// Update user status UI
function updateUserStatusUI(email, online, lastSeen) {
    const contactItem = document.querySelector(`.chat-item[data-email="${email}"]`);
    if (contactItem) {
        const statusIndicator = contactItem.querySelector('.status-indicator');
        if (statusIndicator) {
            statusIndicator.className = `status-indicator ${online ? 'online' : 'offline'}`;
        }
    }
}

// Setup back button handler for mobile
function setupBackButtonHandler() {
    window.addEventListener('popstate', (event) => {
        if (window.innerWidth <= 768 && currentChat) {
            showChatList();
            history.pushState({ chatClosed: true }, '');
        }
    });
}

// Setup chat menu
function setupChatMenu() {
    if (chatMenuBtn) {
        chatMenuBtn.addEventListener('click', showChatMenu);
    }
}

// Show chat menu
function showChatMenu() {
    const chatMenuModal = document.getElementById('chat-menu-modal');
    if (chatMenuModal) {
        chatMenuModal.classList.add('active');
        
        document.querySelectorAll('#chat-menu-modal .menu-item').forEach(item => {
            item.addEventListener('click', () => {
                const action = item.dataset.action;
                handleChatMenuAction(action);
                chatMenuModal.classList.remove('active');
            });
        });
    }
}

// Handle chat menu actions
function handleChatMenuAction(action) {
    if (!currentChat) return;

    switch (action) {
        case 'view-profile':
            viewProfile(currentChat);
            break;
        case 'search':
            openSearchInChat();
            break;
        case 'mute':
            muteChat(currentChat.email);
            break;
        case 'block':
            blockUser(currentChat.email);
            break;
        case 'clear':
            clearChat(currentChat.email);
            break;
        case 'export':
            exportChat();
            break;
    }
}

// View profile
function viewProfile(contact) {
    const profileViewModal = document.getElementById('profile-view-modal');
    if (profileViewModal) {
        document.getElementById('view-profile-avatar').src = contact.avatar || '';
        document.getElementById('view-profile-name').textContent = contact.name;
        document.getElementById('view-profile-about').textContent = contact.about || 'No bio available';
        document.getElementById('view-profile-email').textContent = contact.email;
        
        const lastSeen = contact.online ? 'Online' : formatLastSeen(contact.lastSeen);
        document.getElementById('view-profile-lastseen').textContent = lastSeen;
        
        const statusEl = document.getElementById('view-profile-status');
        statusEl.className = `status-indicator-large ${contact.online ? 'online' : 'offline'}`;

        profileViewModal.classList.add('active');
    }
}

// Mute chat
function muteChat(email) {
    let mutedChats = JSON.parse(localStorage.getItem('mutedChats') || '{}');
    mutedChats[email] = true;
    localStorage.setItem('mutedChats', JSON.stringify(mutedChats));
    showToast('Chat muted', 'success');
}

// Block user
async function blockUser(email) {
    if (!confirm(`Block ${currentChat.name}?`)) return;

    try {
        await fetch('/block-user', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userEmail: currentUser.email,
                blockEmail: email
            })
        });

        contacts = contacts.filter(c => c.email !== email);
        renderContacts();
        
        if (currentChat && currentChat.email === email) {
            showChatList();
        }
        
        showToast('User blocked', 'success');
    } catch (error) {
        console.error('Error blocking user:', error);
        showToast('Error blocking user', 'error');
    }
}

// Clear chat
async function clearChat(email) {
    if (!confirm('Clear this chat?')) return;

    const chatId = [currentUser.email, email].sort().join('_');
    
    if (chats[email]) {
        chats[email].messages = [];
    }

    if (currentChat && currentChat.email === email) {
        messagesContainer.innerHTML = `
            <div class="welcome-message">
                <div class="welcome-icon"><i class="fas fa-comments"></i></div>
                <h3>Chat cleared</h3>
                <p>Start a new conversation</p>
            </div>
        `;
    }

    const contact = contacts.find(c => c.email === email);
    if (contact) {
        contact.lastMessage = 'No messages yet';
        contact.lastTime = '';
    }

    renderContacts();
    showToast('Chat cleared', 'success');
}

// Export chat
function exportChat() {
    if (!currentChat || !chats[currentChat.email]) return;

    const chatData = {
        contact: currentChat,
        messages: chats[currentChat.email].messages,
        exportedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(chatData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chat-${currentChat.name}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);

    showToast('Chat exported', 'success');
}

// Open search in chat
function openSearchInChat() {
    const searchModal = document.getElementById('search-chat-modal');
    if (searchModal) {
        searchModal.classList.add('active');
        document.getElementById('chat-search-input').focus();
    }
}

// Setup infinite scroll
function setupInfiniteScroll() {
    messagesContainer.addEventListener('scroll', () => {
        if (messagesContainer.scrollTop === 0) {
            loadMoreMessages();
        }
    });
}

// Load more messages (for infinite scroll)
async function loadMoreMessages() {
    // Implement pagination
    console.log('Load more messages');
}

// Setup message events
function setupMessageEvents() {
    // Add socket listeners
    socket.on('new-message', handleNewMessage);
    socket.on('typing', handleTypingIndicator);
    socket.on('messages-seen', markMessagesAsSeen);
    socket.on('message-status-updated', updateMessageStatus);
}

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', initChat);

// Export functions to window
window.handleNewMessage = handleNewMessage;
window.handleNewGroupMessage = handleNewGroupMessage;
window.handleNewBroadcastMessage = handleNewBroadcastMessage;
window.handleTypingIndicator = handleTypingIndicator;
window.updateUserOnlineStatus = updateUserStatusUI;
window.updateMessageStatus = updateMessageStatus;
window.renderContacts = renderContacts;
window.toggleReaction = toggleReaction;
window.deleteMessage = deleteMessage;
window.editMessagePrompt = editMessagePrompt;
window.setReplyTo = setReplyTo;
window.clearReply = clearReply;
window.copyMessage = copyMessage;
window.scrollToMessage = scrollToMessage;
window.showChatList = showChatList;
window.loadContacts = loadContacts;
window.loadGroups = loadGroups;
window.loadBroadcasts = loadBroadcasts;
window.sendMessage = sendMessage;
window.starMessage = function(messageId) {
    fetch('/star-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            userEmail: currentUser.email,
            messageId: messageId,
            chatId: currentChat.isGroup ? currentChat.email : 
                   [currentUser.email, currentChat.email].sort().join('_')
        })
    }).then(() => showToast('Message starred', 'success'));
};

window.forwardMessage = function(messageId) {
    showToast('Forward feature coming soon', 'info');
};

window.openShareContact = function() {
    showToast('Share contact feature coming soon', 'info');
};

window.shareLocation = function() {
    showToast('Location sharing coming soon', 'info');
};