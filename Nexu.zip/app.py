from flask import Flask, render_template, request, jsonify, send_from_directory, session
from flask_socketio import SocketIO, emit, join_room, leave_room
import os
import json
import smtplib
import random
import string
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from werkzeug.utils import secure_filename
import uuid
import time
import base64
import mimetypes
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = 'nexus-chat-secret-key-2024'
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['SESSION_TYPE'] = 'filesystem'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=30)

socketio = SocketIO(app, cors_allowed_origins="*", ping_timeout=60, ping_interval=25)

# Create upload directories
UPLOAD_FOLDER = 'uploads'
for folder in ['images', 'videos', 'audios', 'avatars', 'documents']:
    os.makedirs(os.path.join(UPLOAD_FOLDER, folder), exist_ok=True)

# Data directories
DATA_DIR = 'data'
CONTACTS_DIR = os.path.join(DATA_DIR, 'contacts')
CHATS_DIR = os.path.join(DATA_DIR, 'chats')
GROUPS_DIR = os.path.join(DATA_DIR, 'groups')
BROADCASTS_DIR = os.path.join(DATA_DIR, 'broadcasts')
STARRED_DIR = os.path.join(DATA_DIR, 'starred')

for dir_path in [DATA_DIR, CONTACTS_DIR, CHATS_DIR, GROUPS_DIR, BROADCASTS_DIR, STARRED_DIR]:
    os.makedirs(dir_path, exist_ok=True)

# Data files
USERS_FILE = os.path.join(DATA_DIR, 'users.json')
OTP_FILE = os.path.join(DATA_DIR, 'otp.json')
BLOCKED_FILE = os.path.join(DATA_DIR, 'blocked.json')
SETTINGS_FILE = os.path.join(DATA_DIR, 'settings.json')

# Initialize data files
def init_json_file(file_path, default_data):
    if not os.path.exists(file_path):
        with open(file_path, 'w') as f:
            json.dump(default_data, f, indent=2)

init_json_file(USERS_FILE, [])
init_json_file(OTP_FILE, {})
init_json_file(BLOCKED_FILE, {})
init_json_file(SETTINGS_FILE, {})

# Online users tracking
online_users = {}
user_sessions = {}

# Helper functions
def load_json(file_path):
    with open(file_path, 'r') as f:
        return json.load(f)

def save_json(file_path, data):
    with open(file_path, 'w') as f:
        json.dump(data, f, indent=2)

def generate_otp():
    return ''.join(random.choices(string.digits, k=6))

def send_email_otp(to_email, otp):
    try:
        sender_email = "mamir34310@gmail.com"
        sender_password = "vlycilovlpejgqev"
        
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = to_email
        msg['Subject'] = "Nexus Chat Verification Code"
        
        html = f"""
        <div style="font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; padding: 20px; border: 1px solid #7C3AED; border-radius: 10px;">
            <h2 style="color: #7C3AED; text-align: center;">Nexus Chat Verification</h2>
            <p style="color: #333;">Your verification code is:</p>
            <div style="text-align: center; margin: 30px 0;">
                <span style="font-size: 32px; font-weight: bold; letter-spacing: 10px; color: #7C3AED; padding: 15px 25px; background: #f0f0f0; border-radius: 8px;">{otp}</span>
            </div>
            <p style="color: #666;">Use this code to verify your account. This code will expire in 10 minutes.</p>
            <hr style="border: 1px solid #eee;">
            <p style="color: #999; font-size: 12px; text-align: center;">If you didn't request this code, please ignore this email.</p>
        </div>
        """
        
        msg.attach(MIMEText(html, 'html'))
        
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(msg)
        server.quit()
        return True
    except Exception as e:
        print(f"Email error: {e}")
        return False

def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'mp4', 'webm', 'mp3', 'wav', 'ogg', 'pdf', 'doc', 'docx', 'txt', 'zip'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_file_type(filename):
    ext = filename.rsplit('.', 1)[1].lower()
    if ext in ['jpg', 'jpeg', 'png', 'gif', 'webp']:
        return 'image'
    elif ext in ['mp4', 'webm', 'mov', 'avi']:
        return 'video'
    elif ext in ['mp3', 'wav', 'ogg', 'm4a']:
        return 'audio'
    else:
        return 'file'

def get_avatar_url(email):
    users = load_json(USERS_FILE)
    user = next((u for u in users if u['email'] == email), None)
    if user and user.get('profile', {}).get('avatar'):
        return user['profile']['avatar']
    return "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%237C3AED'%3E%3Cpath d='M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-6.627 0-12 5.373-12 12h24c0-6.627-5.373-12-12-12z'/%3E%3C/svg%3E"

def get_user_by_email(email):
    users = load_json(USERS_FILE)
    return next((u for u in users if u['email'] == email), None)

def update_user_online_status(email, online):
    timestamp = datetime.now().isoformat()
    
    users = load_json(USERS_FILE)
    for user in users:
        if user['email'] == email:
            if 'profile' not in user:
                user['profile'] = {}
            user['profile']['lastSeen'] = timestamp
            break
    save_json(USERS_FILE, users)
    
    socketio.emit('user-status-updated', {
        'email': email,
        'online': online,
        'lastSeen': None if online else timestamp
    })

def create_chat_id(user1, user2):
    return '_'.join(sorted([user1, user2]))

def get_chat_messages(chat_id):
    chat_file = os.path.join(CHATS_DIR, f"{chat_id}.json")
    if os.path.exists(chat_file):
        return load_json(chat_file).get('messages', [])
    return []

def save_chat_message(chat_id, message):
    chat_file = os.path.join(CHATS_DIR, f"{chat_id}.json")
    chat = {'messages': []}
    if os.path.exists(chat_file):
        chat = load_json(chat_file)
    chat['messages'].append(message)
    save_json(chat_file, chat)

def format_message_preview(message):
    if message['type'] == 'text':
        return message['message'][:50] + ('...' if len(message['message']) > 50 else '')
    elif message['type'] == 'image':
        return '📷 Photo'
    elif message['type'] == 'video':
        return '🎥 Video'
    elif message['type'] == 'audio':
        return '🎵 Audio'
    elif message['type'] == 'voice':
        return '🎤 Voice message'
    else:
        return '📄 File'

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

@app.route('/uploads/<path:filename>')
def serve_upload(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

# Auth Routes
@app.route('/send-otp', methods=['POST'])
def send_otp():
    data = request.json
    email = data.get('email')
    
    if not email:
        return jsonify({'status': 'error', 'msg': 'Email required'})
    
    otp = generate_otp()
    
    if send_email_otp(email, otp):
        otps = load_json(OTP_FILE)
        otps[email] = {
            'code': otp,
            'expires': (datetime.now() + timedelta(minutes=10)).isoformat()
        }
        save_json(OTP_FILE, otps)
        return jsonify({'status': 'ok', 'msg': 'OTP sent successfully'})
    else:
        return jsonify({'status': 'error', 'msg': 'Failed to send OTP. Please try again.'})

@app.route('/verify-otp', methods=['POST'])
def verify_otp():
    data = request.json
    email = data.get('email')
    code = data.get('code')
    username = data.get('username', '')
    
    otps = load_json(OTP_FILE)
    
    if email not in otps:
        return jsonify({'status': 'error', 'msg': 'OTP not found or expired'})
    
    otp_data = otps[email]
    if otp_data['code'] != code:
        return jsonify({'status': 'error', 'msg': 'Invalid OTP'})
    
    if datetime.fromisoformat(otp_data['expires']) < datetime.now():
        del otps[email]
        save_json(OTP_FILE, otps)
        return jsonify({'status': 'error', 'msg': 'OTP expired'})
    
    del otps[email]
    save_json(OTP_FILE, otps)
    
    users = load_json(USERS_FILE)
    user = next((u for u in users if u['email'] == email), None)
    
    if not user:
        user = {
            'email': email,
            'username': username or email.split('@')[0],
            'id': str(uuid.uuid4()),
            'createdAt': datetime.now().isoformat(),
            'profile': {
                'name': username or email.split('@')[0],
                'about': 'Hey there! I\'m using Nexus Chat',
                'avatar': get_avatar_url(email),
                'lastSeen': datetime.now().isoformat()
            },
            'settings': {
                'theme': 'dark',
                'notifications': True,
                'sound': True,
                'vibration': True,
                'preview': True
            }
        }
        users.append(user)
        save_json(USERS_FILE, users)
        
        contacts_file = os.path.join(CONTACTS_DIR, f"{email}.json")
        if not os.path.exists(contacts_file):
            save_json(contacts_file, [])
    
    session['user'] = user
    session.permanent = True
    
    return jsonify({'status': 'ok', 'msg': 'Verified', 'user': user})

@app.route('/logout', methods=['POST'])
def logout():
    data = request.json
    email = data.get('email')
    
    if email:
        if email in online_users:
            del online_users[email]
        
        update_user_online_status(email, False)
        
        for sid, user_email in list(user_sessions.items()):
            if user_email == email:
                del user_sessions[sid]
    
    session.clear()
    
    return jsonify({'status': 'ok', 'msg': 'Logged out'})

# Profile Routes
@app.route('/update-profile', methods=['POST'])
def update_profile():
    data = request.json
    email = data.get('email')
    name = data.get('name')
    about = data.get('about')
    avatar = data.get('avatar')
    
    users = load_json(USERS_FILE)
    user = None
    
    for u in users:
        if u['email'] == email:
            if 'profile' not in u:
                u['profile'] = {}
            if name:
                u['profile']['name'] = name
            if about:
                u['profile']['about'] = about
            if avatar:
                u['profile']['avatar'] = avatar
            user = u
            break
    
    save_json(USERS_FILE, users)
    
    # Update in contacts
    for filename in os.listdir(CONTACTS_DIR):
        if filename.endswith('.json'):
            contacts_file = os.path.join(CONTACTS_DIR, filename)
            contacts = load_json(contacts_file)
            updated = False
            for contact in contacts:
                if contact['email'] == email:
                    if name:
                        contact['name'] = name
                    if about:
                        contact['about'] = about
                    if avatar:
                        contact['avatar'] = avatar
                    updated = True
            if updated:
                save_json(contacts_file, contacts)
    
    # Notify all connected clients
    socketio.emit('profile-updated', {
        'email': email,
        'profile': user['profile'] if user else {}
    })
    
    return jsonify({'status': 'ok', 'user': user})

@app.route('/upload-avatar', methods=['POST'])
def upload_avatar():
    if 'avatar' not in request.files:
        return jsonify({'status': 'error', 'msg': 'No file uploaded'})
    
    file = request.files['avatar']
    if file.filename == '':
        return jsonify({'status': 'error', 'msg': 'No file selected'})
    
    if file and allowed_file(file.filename):
        ext = file.filename.rsplit('.', 1)[1].lower()
        filename = f"{uuid.uuid4()}.{ext}"
        filepath = os.path.join(UPLOAD_FOLDER, 'avatars', filename)
        file.save(filepath)
        
        return jsonify({
            'status': 'ok',
            'avatarUrl': f'/uploads/avatars/{filename}'
        })
    
    return jsonify({'status': 'error', 'msg': 'Invalid file type'})

# Contact Routes
@app.route('/users', methods=['GET'])
def get_users():
    users = load_json(USERS_FILE)
    result = []
    for user in users:
        result.append({
            'email': user['email'],
            'username': user.get('username', ''),
            'profile': user.get('profile', {}),
            'online': user['email'] in online_users
        })
    return jsonify(result)

@app.route('/contacts/<email>', methods=['GET'])
def get_contacts(email):
    contacts_file = os.path.join(CONTACTS_DIR, f"{email}.json")
    
    if not os.path.exists(contacts_file):
        return jsonify([])
    
    contacts = load_json(contacts_file)
    result = []
    
    for contact in contacts:
        online = contact['email'] in online_users
        
        chat_id = create_chat_id(email, contact['email'])
        chat_file = os.path.join(CHATS_DIR, f"{chat_id}.json")
        
        last_message = 'No messages yet'
        last_time = ''
        unread_count = 0
        
        if os.path.exists(chat_file):
            chat = load_json(chat_file)
            if chat.get('messages'):
                last_msg = chat['messages'][-1]
                last_message = format_message_preview(last_msg)
                last_time = last_msg['timestamp']
                unread_count = sum(1 for m in chat['messages'] 
                                 if m['from'] == contact['email'] and m.get('status') != 'seen')
        
        result.append({
            **contact,
            'online': online,
            'lastMessage': last_message,
            'lastTime': last_time,
            'unreadCount': unread_count,
            'typing': False
        })
    
    return jsonify(result)

@app.route('/add-contact', methods=['POST'])
def add_contact():
    data = request.json
    user_email = data.get('userEmail')
    contact_email = data.get('contactEmail')
    
    if not user_email or not contact_email:
        return jsonify({'status': 'error', 'msg': 'Emails required'})
    
    if user_email == contact_email:
        return jsonify({'status': 'error', 'msg': 'Cannot add yourself'})
    
    users = load_json(USERS_FILE)
    contact_user = next((u for u in users if u['email'] == contact_email), None)
    
    if not contact_user:
        return jsonify({'status': 'error', 'msg': 'User not found'})
    
    contacts_file = os.path.join(CONTACTS_DIR, f"{user_email}.json")
    contacts = load_json(contacts_file) if os.path.exists(contacts_file) else []
    
    if any(c['email'] == contact_email for c in contacts):
        return jsonify({'status': 'error', 'msg': 'Contact already exists'})
    
    new_contact = {
        'email': contact_email,
        'name': contact_user['profile'].get('name', contact_user['username']),
        'avatar': get_avatar_url(contact_email),
        'about': contact_user['profile'].get('about', 'Hey there!'),
        'addedAt': datetime.now().isoformat()
    }
    
    contacts.append(new_contact)
    save_json(contacts_file, contacts)
    
    return jsonify({'status': 'ok', 'contact': new_contact})

@app.route('/delete-contact', methods=['POST'])
def delete_contact():
    data = request.json
    user_email = data.get('userEmail')
    contact_email = data.get('contactEmail')
    
    contacts_file = os.path.join(CONTACTS_DIR, f"{user_email}.json")
    
    if os.path.exists(contacts_file):
        contacts = load_json(contacts_file)
        contacts = [c for c in contacts if c['email'] != contact_email]
        save_json(contacts_file, contacts)
    
    return jsonify({'status': 'ok', 'msg': 'Contact deleted'})

# Chat Routes
@app.route('/get-chat', methods=['POST'])
def get_chat():
    data = request.json
    user1 = data.get('user1')
    user2 = data.get('user2')
    
    chat_id = create_chat_id(user1, user2)
    chat_file = os.path.join(CHATS_DIR, f"{chat_id}.json")
    
    if os.path.exists(chat_file):
        chat = load_json(chat_file)
    else:
        chat = {'messages': []}
        save_json(chat_file, chat)
    
    return jsonify(chat)

@app.route('/send-message', methods=['POST'])
def send_message():
    data = request.json
    from_email = data.get('from')
    to_email = data.get('to')
    message = data.get('message')
    msg_type = data.get('type', 'text')
    reply_to = data.get('replyTo')
    duration = data.get('duration')
    file_name = data.get('fileName')
    file_size = data.get('fileSize')
    
    message_id = str(uuid.uuid4())
    timestamp = datetime.now().isoformat()
    
    new_message = {
        'id': message_id,
        'from': from_email,
        'to': to_email,
        'message': message,
        'type': msg_type,
        'timestamp': timestamp,
        'status': 'sent'
    }
    
    if reply_to:
        new_message['replyTo'] = reply_to
    
    if duration:
        new_message['duration'] = duration
    
    if file_name:
        new_message['fileName'] = file_name
    
    if file_size:
        new_message['fileSize'] = file_size
    
    chat_id = create_chat_id(from_email, to_email)
    save_chat_message(chat_id, new_message)
    
    # Update contact's last message
    contacts_file = os.path.join(CONTACTS_DIR, f"{from_email}.json")
    if os.path.exists(contacts_file):
        contacts = load_json(contacts_file)
        for contact in contacts:
            if contact['email'] == to_email:
                contact['lastMessage'] = format_message_preview(new_message)
                contact['lastTime'] = timestamp
                break
        save_json(contacts_file, contacts)
    
    # Auto-add contact if not exists
    contacts_file_to = os.path.join(CONTACTS_DIR, f"{to_email}.json")
    if os.path.exists(contacts_file_to):
        contacts_to = load_json(contacts_file_to)
        if not any(c['email'] == from_email for c in contacts_to):
            from_user = get_user_by_email(from_email)
            if from_user:
                new_contact = {
                    'email': from_email,
                    'name': from_user['profile'].get('name', from_user['username']),
                    'avatar': get_avatar_url(from_email),
                    'about': from_user['profile'].get('about', 'Hey there!'),
                    'addedAt': timestamp
                }
                contacts_to.append(new_contact)
                save_json(contacts_file_to, contacts_to)
    
    # Send real-time update
    if to_email in online_users:
        socketio.emit('new-message', new_message, room=online_users[to_email])
        
        # Update status to delivered
        new_message['status'] = 'delivered'
        socketio.emit('message-status-updated', {
            'messageId': message_id,
            'status': 'delivered'
        }, room=online_users[from_email] if from_email in online_users else None)
    
    return jsonify({'status': 'ok', 'message': new_message})

@app.route('/upload-file', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'status': 'error', 'msg': 'No file uploaded'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'status': 'error', 'msg': 'No file selected'})
    
    if file and allowed_file(file.filename):
        file_type = get_file_type(file.filename)
        ext = file.filename.rsplit('.', 1)[1].lower()
        filename = f"{uuid.uuid4()}.{ext}"
        
        folder_map = {
            'image': 'images',
            'video': 'videos',
            'audio': 'audios',
            'file': 'documents'
        }
        
        filepath = os.path.join(UPLOAD_FOLDER, folder_map[file_type], filename)
        file.save(filepath)
        
        return jsonify({
            'status': 'ok',
            'fileUrl': f'/uploads/{folder_map[file_type]}/{filename}',
            'fileName': file.filename,
            'fileSize': os.path.getsize(filepath),
            'fileType': file_type
        })
    
    return jsonify({'status': 'error', 'msg': 'Invalid file type'})

@app.route('/upload-voice', methods=['POST'])
def upload_voice():
    if 'audio' not in request.files:
        return jsonify({'status': 'error', 'msg': 'No audio file uploaded'})
    
    file = request.files['audio']
    if file.filename == '':
        return jsonify({'status': 'error', 'msg': 'No file selected'})
    
    filename = f"{uuid.uuid4()}.webm"
    filepath = os.path.join(UPLOAD_FOLDER, 'audios', filename)
    file.save(filepath)
    
    duration = request.form.get('duration', '0:00')
    
    return jsonify({
        'status': 'ok',
        'fileUrl': f'/uploads/audios/{filename}',
        'duration': duration,
        'fileSize': os.path.getsize(filepath)
    })

@app.route('/mark-messages-seen', methods=['POST'])
def mark_messages_seen():
    data = request.json
    user_email = data.get('userEmail')
    contact_email = data.get('contactEmail')
    
    chat_id = create_chat_id(user_email, contact_email)
    chat_file = os.path.join(CHATS_DIR, f"{chat_id}.json")
    
    if os.path.exists(chat_file):
        chat = load_json(chat_file)
        updated = False
        
        for message in chat['messages']:
            if message['from'] == contact_email and message.get('status') != 'seen':
                message['status'] = 'seen'
                updated = True
                
                if contact_email in online_users:
                    socketio.emit('message-status-updated', {
                        'messageId': message['id'],
                        'status': 'seen'
                    }, room=online_users[contact_email])
        
        if updated:
            save_json(chat_file, chat)
            
            # Update unread count in contacts
            contacts_file = os.path.join(CONTACTS_DIR, f"{user_email}.json")
            if os.path.exists(contacts_file):
                contacts = load_json(contacts_file)
                for contact in contacts:
                    if contact['email'] == contact_email:
                        contact['unreadCount'] = 0
                        break
                save_json(contacts_file, contacts)
    
    return jsonify({'status': 'ok'})

@app.route('/delete-message', methods=['POST'])
def delete_message():
    data = request.json
    chat_id = data.get('chatId')
    message_id = data.get('messageId')
    user_email = data.get('userEmail')
    
    chat_file = os.path.join(CHATS_DIR, f"{chat_id}.json")
    
    if os.path.exists(chat_file):
        chat = load_json(chat_file)
        
        for message in chat['messages']:
            if message['id'] == message_id and message['from'] == user_email:
                message['deleted'] = True
                message['message'] = 'This message was deleted'
                break
        
        save_json(chat_file, chat)
        
        # Notify other user
        other_email = chat_id.split('_')[0] if chat_id.split('_')[0] != user_email else chat_id.split('_')[1]
        if other_email in online_users:
            socketio.emit('message-deleted', {
                'messageId': message_id,
                'chatId': chat_id
            }, room=online_users[other_email])
    
    return jsonify({'status': 'ok'})

@app.route('/edit-message', methods=['POST'])
def edit_message():
    data = request.json
    chat_id = data.get('chatId')
    message_id = data.get('messageId')
    user_email = data.get('userEmail')
    new_message = data.get('newMessage')
    
    chat_file = os.path.join(CHATS_DIR, f"{chat_id}.json")
    
    if os.path.exists(chat_file):
        chat = load_json(chat_file)
        
        for message in chat['messages']:
            if message['id'] == message_id and message['from'] == user_email:
                message['message'] = new_message
                message['edited'] = True
                message['editedAt'] = datetime.now().isoformat()
                break
        
        save_json(chat_file, chat)
        
        # Notify other user
        other_email = chat_id.split('_')[0] if chat_id.split('_')[0] != user_email else chat_id.split('_')[1]
        if other_email in online_users:
            socketio.emit('message-edited', {
                'messageId': message_id,
                'chatId': chat_id,
                'newMessage': new_message
            }, room=online_users[other_email])
    
    return jsonify({'status': 'ok'})

@app.route('/add-reaction', methods=['POST'])
def add_reaction():
    data = request.json
    chat_id = data.get('chatId')
    message_id = data.get('messageId')
    user_email = data.get('userEmail')
    reaction = data.get('reaction')
    
    chat_file = os.path.join(CHATS_DIR, f"{chat_id}.json")
    
    if os.path.exists(chat_file):
        chat = load_json(chat_file)
        
        for message in chat['messages']:
            if message['id'] == message_id:
                if 'reactions' not in message:
                    message['reactions'] = []
                
                # Check if user already reacted
                existing = next((r for r in message['reactions'] if r['user'] == user_email), None)
                
                if existing:
                    if existing['reaction'] == reaction:
                        message['reactions'].remove(existing)
                    else:
                        existing['reaction'] = reaction
                else:
                    message['reactions'].append({
                        'user': user_email,
                        'reaction': reaction
                    })
                
                break
        
        save_json(chat_file, chat)
        
        # Notify other user
        other_email = chat_id.split('_')[0] if chat_id.split('_')[0] != user_email else chat_id.split('_')[1]
        if other_email in online_users:
            socketio.emit('message-reaction', {
                'messageId': message_id,
                'chatId': chat_id,
                'reactions': message.get('reactions', [])
            }, room=online_users[other_email])
    
    return jsonify({'status': 'ok'})

@app.route('/star-message', methods=['POST'])
def star_message():
    data = request.json
    user_email = data.get('userEmail')
    message_id = data.get('messageId')
    chat_id = data.get('chatId')
    
    starred_file = os.path.join(STARRED_DIR, f"{user_email}.json")
    starred = load_json(starred_file) if os.path.exists(starred_file) else []
    
    if message_id not in starred:
        starred.append({
            'messageId': message_id,
            'chatId': chat_id,
            'starredAt': datetime.now().isoformat()
        })
        save_json(starred_file, starred)
    
    return jsonify({'status': 'ok'})

@app.route('/search-messages', methods=['POST'])
def search_messages():
    data = request.json
    chat_id = data.get('chatId')
    query = data.get('query')
    
    chat_file = os.path.join(CHATS_DIR, f"{chat_id}.json")
    
    if not os.path.exists(chat_file):
        return jsonify({'messages': []})
    
    chat = load_json(chat_file)
    results = []
    
    for message in chat['messages']:
        if message['type'] == 'text' and query.lower() in message['message'].lower():
            results.append(message)
    
    return jsonify({'messages': results})

# Group Routes
@app.route('/create-group', methods=['POST'])
def create_group():
    data = request.json
    creator_email = data.get('creatorEmail')
    group_name = data.get('groupName')
    members = data.get('members', [])
    avatar = data.get('groupAvatar')
    
    group_id = f"group_{uuid.uuid4().hex[:8]}"
    
    group = {
        'id': group_id,
        'name': group_name,
        'avatar': avatar or "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%237C3AED'%3E%3Cpath d='M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'/%3E%3C/svg%3E",
        'creator': creator_email,
        'admins': [creator_email],
        'members': [creator_email] + members,
        'createdAt': datetime.now().isoformat(),
        'lastMessage': None,
        'lastMessageTime': None
    }
    
    group_file = os.path.join(GROUPS_DIR, f"{group_id}.json")
    save_json(group_file, group)
    
    chat_file = os.path.join(CHATS_DIR, f"{group_id}.json")
    save_json(chat_file, {'messages': [], 'groupId': group_id, 'type': 'group'})
    
    return jsonify({'status': 'ok', 'group': group})

@app.route('/send-group-message', methods=['POST'])
def send_group_message():
    data = request.json
    group_id = data.get('groupId')
    from_email = data.get('from')
    message = data.get('message')
    msg_type = data.get('type', 'text')
    reply_to = data.get('replyTo')
    duration = data.get('duration')
    
    message_id = str(uuid.uuid4())
    timestamp = datetime.now().isoformat()
    
    new_message = {
        'id': message_id,
        'from': from_email,
        'groupId': group_id,
        'message': message,
        'type': msg_type,
        'timestamp': timestamp,
        'status': 'sent'
    }
    
    if reply_to:
        new_message['replyTo'] = reply_to
    
    if duration:
        new_message['duration'] = duration
    
    chat_file = os.path.join(CHATS_DIR, f"{group_id}.json")
    chat = load_json(chat_file) if os.path.exists(chat_file) else {'messages': []}
    chat['messages'].append(new_message)
    save_json(chat_file, chat)
    
    group_file = os.path.join(GROUPS_DIR, f"{group_id}.json")
    if os.path.exists(group_file):
        group = load_json(group_file)
        group['lastMessage'] = format_message_preview(new_message)
        group['lastMessageTime'] = timestamp
        save_json(group_file, group)
        
        for member in group['members']:
            if member != from_email and member in online_users:
                socketio.emit('new-group-message', new_message, room=online_users[member])
    
    return jsonify({'status': 'ok', 'message': new_message})

@app.route('/get-group-chat', methods=['POST'])
def get_group_chat():
    data = request.json
    group_id = data.get('groupId')
    
    chat_file = os.path.join(CHATS_DIR, f"{group_id}.json")
    
    if os.path.exists(chat_file):
        chat = load_json(chat_file)
    else:
        chat = {'messages': []}
    
    return jsonify(chat)

@app.route('/user-groups/<email>', methods=['GET'])
def user_groups(email):
    groups = []
    
    for filename in os.listdir(GROUPS_DIR):
        if filename.endswith('.json'):
            group = load_json(os.path.join(GROUPS_DIR, filename))
            if email in group['members']:
                groups.append(group)
    
    return jsonify(groups)

# Broadcast Routes
@app.route('/create-broadcast', methods=['POST'])
def create_broadcast():
    data = request.json
    creator_email = data.get('creatorEmail')
    name = data.get('name')
    members = data.get('members', [])
    
    broadcast_id = f"broadcast_{uuid.uuid4().hex[:8]}"
    
    broadcast = {
        'id': broadcast_id,
        'name': name,
        'creator': creator_email,
        'members': members,
        'createdAt': datetime.now().isoformat(),
        'lastMessage': None,
        'lastMessageTime': None,
        'avatar': "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%237C3AED'%3E%3Cpath d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 4c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm0 13c-2.33 0-4.31-1.46-5.11-3.5h10.22c-.8 2.04-2.78 3.5-5.11 3.5z'/%3E%3C/svg%3E"
    }
    
    broadcast_file = os.path.join(BROADCASTS_DIR, f"{broadcast_id}.json")
    save_json(broadcast_file, broadcast)
    
    chat_file = os.path.join(CHATS_DIR, f"{broadcast_id}.json")
    save_json(chat_file, {'messages': [], 'broadcastId': broadcast_id, 'type': 'broadcast'})
    
    return jsonify({'status': 'ok', 'broadcast': broadcast})

@app.route('/send-broadcast', methods=['POST'])
def send_broadcast():
    data = request.json
    broadcast_id = data.get('broadcastId')
    from_email = data.get('from')
    message = data.get('message')
    msg_type = data.get('type', 'text')
    
    message_id = str(uuid.uuid4())
    timestamp = datetime.now().isoformat()
    
    new_message = {
        'id': message_id,
        'from': from_email,
        'broadcastId': broadcast_id,
        'message': message,
        'type': msg_type,
        'timestamp': timestamp,
        'status': 'sent'
    }
    
    chat_file = os.path.join(CHATS_DIR, f"{broadcast_id}.json")
    chat = load_json(chat_file) if os.path.exists(chat_file) else {'messages': []}
    chat['messages'].append(new_message)
    save_json(chat_file, chat)
    
    broadcast_file = os.path.join(BROADCASTS_DIR, f"{broadcast_id}.json")
    if os.path.exists(broadcast_file):
        broadcast = load_json(broadcast_file)
        broadcast['lastMessage'] = format_message_preview(new_message)
        broadcast['lastMessageTime'] = timestamp
        save_json(broadcast_file, broadcast)
        
        for member in broadcast['members']:
            if member != from_email and member in online_users:
                socketio.emit('new-broadcast-message', new_message, room=online_users[member])
    
    return jsonify({'status': 'ok', 'message': new_message})

@app.route('/get-broadcast-chat', methods=['POST'])
def get_broadcast_chat():
    data = request.json
    broadcast_id = data.get('broadcastId')
    
    chat_file = os.path.join(CHATS_DIR, f"{broadcast_id}.json")
    
    if os.path.exists(chat_file):
        chat = load_json(chat_file)
    else:
        chat = {'messages': []}
    
    return jsonify(chat)

@app.route('/user-broadcasts/<email>', methods=['GET'])
def user_broadcasts(email):
    broadcasts = []
    
    for filename in os.listdir(BROADCASTS_DIR):
        if filename.endswith('.json'):
            broadcast = load_json(os.path.join(BROADCASTS_DIR, filename))
            if email in broadcast['members']:
                broadcasts.append(broadcast)
    
    return jsonify(broadcasts)

# Settings Routes
@app.route('/update-settings', methods=['POST'])
def update_settings():
    data = request.json
    email = data.get('email')
    
    settings = load_json(SETTINGS_FILE)
    settings[email] = data
    save_json(SETTINGS_FILE, settings)
    
    users = load_json(USERS_FILE)
    for user in users:
        if user['email'] == email:
            if 'settings' not in user:
                user['settings'] = {}
            user['settings'].update(data)
            break
    save_json(USERS_FILE, users)
    
    return jsonify({'status': 'ok'})

@app.route('/get-settings/<email>', methods=['GET'])
def get_settings(email):
    settings = load_json(SETTINGS_FILE)
    return jsonify(settings.get(email, {}))

# Block/Unblock Routes
@app.route('/block-user', methods=['POST'])
def block_user():
    data = request.json
    user_email = data.get('userEmail')
    block_email = data.get('blockEmail')
    
    blocked = load_json(BLOCKED_FILE)
    
    if user_email not in blocked:
        blocked[user_email] = []
    
    if block_email not in blocked[user_email]:
        blocked[user_email].append(block_email)
        save_json(BLOCKED_FILE, blocked)
    
    return jsonify({'status': 'ok'})

@app.route('/unblock-user', methods=['POST'])
def unblock_user():
    data = request.json
    user_email = data.get('userEmail')
    unblock_email = data.get('unblockEmail')
    
    blocked = load_json(BLOCKED_FILE)
    
    if user_email in blocked:
        blocked[user_email] = [e for e in blocked[user_email] if e != unblock_email]
        save_json(BLOCKED_FILE, blocked)
    
    return jsonify({'status': 'ok'})

@app.route('/blocked-users/<email>', methods=['GET'])
def get_blocked_users(email):
    blocked = load_json(BLOCKED_FILE)
    return jsonify(blocked.get(email, []))

# Socket.IO Events
@socketio.on('connect')
def handle_connect():
    print(f"Client connected: {request.sid}")

@socketio.on('user-login')
def handle_user_login(email):
    online_users[email] = request.sid
    user_sessions[request.sid] = email
    
    update_user_online_status(email, True)
    
    emit('user-login-success', {'email': email})

@socketio.on('typing')
def handle_typing(data):
    to_email = data.get('to')
    typing = data.get('typing')
    from_email = user_sessions.get(request.sid)
    
    if to_email and from_email and to_email in online_users:
        emit('typing', {
            'from': from_email,
            'typing': typing
        }, room=online_users[to_email])

@socketio.on('messages-seen')
def handle_messages_seen(data):
    contact_email = data.get('contactEmail')
    user_email = user_sessions.get(request.sid)
    
    if user_email and contact_email:
        chat_id = create_chat_id(user_email, contact_email)
        chat_file = os.path.join(CHATS_DIR, f"{chat_id}.json")
        
        if os.path.exists(chat_file):
            chat = load_json(chat_file)
            updated = False
            
            for message in chat['messages']:
                if message['from'] == contact_email and message.get('status') != 'seen':
                    message['status'] = 'seen'
                    updated = True
                    
                    if contact_email in online_users:
                        emit('message-status-updated', {
                            'messageId': message['id'],
                            'status': 'seen'
                        }, room=online_users[contact_email])
            
            if updated:
                save_json(chat_file, chat)
                
                emit('messages-seen', {
                    'by': user_email,
                    'chatId': chat_id
                }, room=online_users[contact_email] if contact_email in online_users else None)

@socketio.on('disconnect')
def handle_disconnect():
    email = user_sessions.get(request.sid)
    if email:
        if email in online_users:
            del online_users[email]
        if request.sid in user_sessions:
            del user_sessions[request.sid]
        
        update_user_online_status(email, False)
    
    print(f"Client disconnected: {request.sid}")

if __name__ == '__main__':
    socketio.run(app, debug=True, port=3000)