import uvicorn
from backend.config import Config
import os
import webbrowser
from time import sleep

if __name__ == "__main__":
    # Clear screen
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # Print banner
    print("""
    ╔══════════════════════════════════════════════════════════╗
    ║                                                          ║
    ║    ╔═══╗╔╗   ╔═══╗╔═══╗╔╗ ╔╗    ╔═══╗╔═══╗╔═══╗╔═══╗    ║
    ║    ║╔═╗║║║   ║╔═╗║║╔═╗║║║ ║║    ║╔═╗║║╔═╗║║╔═╗║║╔═╗║    ║
    ║    ║╚══╗║║   ║╚═╝║║╚═╝║║╚═╝║    ║╚═╝║║╚═╝║║╚═╝║║╚═╝║    ║
    ║    ╚══╗║║║   ║╔╗╔╝║╔╗╔╝║╔╗ ║    ║╔╗╔╝║╔╗╔╝║╔╗╔╝║╔╗╔╝    ║
    ║    ║╚═╝║║╚═╗ ║║║╚╗║║║╚╗║║╚═╝    ║║║╚╗║║║╚╗║║║╚╗║║║╚╗    ║
    ║    ╚═══╝╚═══╝╚╝╚═╝╚╝╚═╝╚═══╝    ╚╝╚═╝╚╝╚═╝╚╝╚═╝╚╝╚═╝    ║
    ║                                                          ║
    ║                 COSMIC CHAT EXPERIENCE                  ║
    ║                      v1.0.0 - NEO                       ║
    ╚══════════════════════════════════════════════════════════╝
    """)
    
    print(f"\n    🚀 Starting Nexus Chat Server...")
    print(f"    📡 Host: {Config.HOST}")
    print(f"    🔌 Port: {Config.PORT}")
    print(f"    🌐 URL: http://{Config.HOST}:{Config.PORT}")
    print(f"\n    ⏳ Waiting for server to start...\n")
    
    # Open browser after a short delay
    def open_browser():
        sleep(2)
        webbrowser.open(f"http://{Config.HOST}:{Config.PORT}")
    
    import threading
    threading.Thread(target=open_browser, daemon=True).start()
    
    # Run server
    uvicorn.run(
        "backend.app:socket_app",
        host=Config.HOST,
        port=Config.PORT,
        reload=True,
        log_level="info"
    )