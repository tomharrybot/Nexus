import json
import os
from config import Config

class Database:
    def __init__(self):
        self.ensure_directories()
        
    def ensure_directories(self):
        """Create necessary directories if they don't exist"""
        dirs = [
            Config.DATA_DIR,
            Config.CONTACTS_DIR,
            Config.CHATS_DIR,
            Config.GROUPS_DIR,
            Config.UPLOADS_DIR,
            f"{Config.UPLOADS_DIR}/images",
            f"{Config.UPLOADS_DIR}/videos",
            f"{Config.UPLOADS_DIR}/audio",
            f"{Config.UPLOADS_DIR}/documents"
        ]
        for dir_path in dirs:
            os.makedirs(dir_path, exist_ok=True)
    
    def read_json(self, file_path, default=None):
        """Read JSON file with error handling"""
        try:
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return default if default is not None else {}
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return default if default is not None else {}
    
    def write_json(self, file_path, data):
        """Write JSON file with error handling"""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"Error writing {file_path}: {e}")
            return False
    
    # User operations
    def get_users(self):
        return self.read_json(Config.USERS_FILE, [])
    
    def save_users(self, users):
        return self.write_json(Config.USERS_FILE, users)
    
    def find_user(self, email):
        users = self.get_users()
        return next((u for u in users if u['email'] == email), None)
    
    def create_user(self, user_data):
        users = self.get_users()
        users.append(user_data)
        self.save_users(users)
        
        # Create contacts file
        contacts_file = f"{Config.CONTACTS_DIR}/{user_data['email']}.json"
        self.write_json(contacts_file, [])
        
        return user_data
    
    # OTP operations
    def get_otps(self):
        return self.read_json(Config.OTP_FILE, {})
    
    def save_otps(self, otps):
        return self.write_json(Config.OTP_FILE, otps)
    
    # Contact operations
    def get_contacts(self, email):
        contacts_file = f"{Config.CONTACTS_DIR}/{email}.json"
        return self.read_json(contacts_file, [])
    
    def save_contacts(self, email, contacts):
        contacts_file = f"{Config.CONTACTS_DIR}/{email}.json"
        return self.write_json(contacts_file, contacts)
    
    # Chat operations
    def get_chat(self, user1, user2):
        chat_id = '_'.join(sorted([user1, user2]))
        chat_file = f"{Config.CHATS_DIR}/{chat_id}.json"
        return self.read_json(chat_file, {'messages': []})
    
    def save_chat(self, user1, user2, chat_data):
        chat_id = '_'.join(sorted([user1, user2]))
        chat_file = f"{Config.CHATS_DIR}/{chat_id}.json"
        return self.write_json(chat_file, chat_data)

db = Database()