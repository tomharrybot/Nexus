# Email Service for OTP
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
import os
from config import Config

class EmailService:
    def __init__(self):
        self.smtp_server = "smtp.gmail.com"
        self.smtp_port = 587
        self.sender_email = Config.EMAIL_USER
        self.password = Config.EMAIL_PASS
    
    def send_otp(self, to_email, otp):
        """Send OTP verification email"""
        try:
            # Create message
            message = MIMEMultipart("alternative")
            message["Subject"] = "Nexus Chat - Your Verification Code"
            message["From"] = self.sender_email
            message["To"] = to_email
            
            # Create HTML content
            html = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>
                    body {{
                        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                        background: linear-gradient(135deg, #03050B, #0F0A1F);
                        margin: 0;
                        padding: 30px 20px;
                    }}
                    .container {{
                        max-width: 500px;
                        margin: 0 auto;
                        background: rgba(15, 10, 31, 0.95);
                        backdrop-filter: blur(20px);
                        border: 2px solid #FF00E5;
                        border-radius: 30px;
                        padding: 40px 30px;
                        box-shadow: 0 0 50px rgba(255, 0, 229, 0.3);
                    }}
                    .logo {{
                        text-align: center;
                        margin-bottom: 20px;
                    }}
                    .logo svg {{
                        width: 80px;
                        height: 80px;
                        filter: drop-shadow(0 0 20px #FF00E5);
                    }}
                    h1 {{
                        text-align: center;
                        font-size: 32px;
                        font-weight: 800;
                        background: linear-gradient(135deg, #FF00E5, #00E5FF);
                        -webkit-background-clip: text;
                        -webkit-text-fill-color: transparent;
                        margin-bottom: 20px;
                    }}
                    .otp-box {{
                        background: rgba(0, 0, 0, 0.4);
                        border: 2px solid #00E5FF;
                        border-radius: 20px;
                        padding: 20px;
                        text-align: center;
                        margin: 30px 0;
                    }}
                    .otp-code {{
                        font-size: 48px;
                        font-weight: 900;
                        letter-spacing: 10px;
                        color: #00E5FF;
                        text-shadow: 0 0 30px #00E5FF;
                        font-family: monospace;
                    }}
                    .message {{
                        color: #D8B4FF;
                        font-size: 16px;
                        line-height: 1.6;
                        text-align: center;
                    }}
                    .footer {{
                        text-align: center;
                        color: #6B5E7E;
                        font-size: 14px;
                        margin-top: 30px;
                        padding-top: 20px;
                        border-top: 1px solid rgba(255, 0, 229, 0.2);
                    }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="logo">
                        <svg viewBox="0 0 24 24" width="80" height="80">
                            <defs>
                                <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                                    <stop offset="0%" stop-color="#FF00E5"/>
                                    <stop offset="100%" stop-color="#00E5FF"/>
                                </linearGradient>
                            </defs>
                            <path d="M12 2C6.477 2 2 6.477 2 12c0 2.237.73 4.306 1.96 5.99L2 22l4.25-1.66A9.95 9.95 0 0 0 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2z" fill="url(#grad)"/>
                        </svg>
                    </div>
                    <h1>NEXUS CHAT</h1>
                    <div class="message">
                        Welcome to Nexus Chat!<br>
                        Use the verification code below:
                    </div>
                    <div class="otp-box">
                        <div class="otp-code">{otp}</div>
                    </div>
                    <div class="message">
                        This code will expire in 10 minutes.<br>
                        If you didn't request this, please ignore this email.
                    </div>
                    <div class="footer">
                        © 2024 Nexus Chat. All rights reserved.
                    </div>
                </div>
            </body>
            </html>
            """.format(otp=otp)
            
            # Attach HTML
            message.attach(MIMEText(html, "html"))
            
            # Send email
            context = ssl.create_default_context()
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls(context=context)
                server.login(self.sender_email, self.password)
                server.sendmail(self.sender_email, to_email, message.as_string())
            
            return True, "OTP sent successfully"
            
        except Exception as e:
            print(f"Email error: {e}")
            return False, str(e)
    
    def send_welcome_email(self, to_email, username):
        """Send welcome email to new users"""
        try:
            message = MIMEMultipart("alternative")
            message["Subject"] = "Welcome to Nexus Chat!"
            message["From"] = self.sender_email
            message["To"] = to_email
            
            html = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body {{
                        font-family: Arial, sans-serif;
                        background: #03050B;
                        color: white;
                    }}
                    .container {{
                        max-width: 500px;
                        margin: 0 auto;
                        padding: 30px;
                        background: linear-gradient(135deg, #0F0A1F, #1A1029);
                        border-radius: 30px;
                    }}
                    h1 {{ color: #FF00E5; }}
                    p {{ color: #D8B4FF; line-height: 1.6; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Welcome to Nexus, {username}!</h1>
                    <p>You've successfully joined the most cosmic chat experience.</p>
                    <p>Start connecting with friends and exploring the universe of conversations.</p>
                </div>
            </body>
            </html>
            """.format(username=username)
            
            message.attach(MIMEText(html, "html"))
            
            context = ssl.create_default_context()
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls(context=context)
                server.login(self.sender_email, self.password)
                server.sendmail(self.sender_email, to_email, message.as_string())
            
            return True, "Welcome email sent"
            
        except Exception as e:
            print(f"Welcome email error: {e}")
            return False, str(e)

# Singleton instance
email_service = EmailService()