# Constants

# Message types
MESSAGE_TYPES = {
    'text': 'Text Message',
    'image': 'Image',
    'video': 'Video',
    'audio': 'Voice Message',
    'file': 'File',
    'location': 'Location',
    'contact': 'Contact',
    'sticker': 'Sticker',
    'gif': 'GIF'
}

# Message status
MESSAGE_STATUS = {
    'sent': 'Sent',
    'delivered': 'Delivered',
    'seen': 'Seen',
    'failed': 'Failed',
    'deleted': 'Deleted'
}

# Notification types
NOTIFICATION_TYPES = {
    'message': 'New Message',
    'group_invite': 'Group Invite',
    'contact_request': 'Contact Request',
    'mention': 'Mentioned You',
    'reply': 'Replied to You',
    'reaction': 'Reacted to Your Message'
}

# Privacy settings
PRIVACY_OPTIONS = {
    'everyone': 'Everyone',
    'contacts': 'My Contacts',
    'nobody': 'Nobody'
}

# User roles
USER_ROLES = {
    'user': 'User',
    'admin': 'Admin',
    'moderator': 'Moderator'
}

# File size limits (in bytes)
FILE_SIZE_LIMITS = {
    'image': 10 * 1024 * 1024,   # 10MB
    'video': 50 * 1024 * 1024,    # 50MB
    'audio': 20 * 1024 * 1024,    # 20MB
    'document': 25 * 1024 * 1024  # 25MB
}

# Pagination defaults
PAGINATION = {
    'messages_per_page': 50,
    'contacts_per_page': 50,
    'notifications_per_page': 30
}

# Cache durations (in seconds)
CACHE_DURATIONS = {
    'user_profile': 300,      # 5 minutes
    'contacts_list': 60,       # 1 minute
    'chat_history': 30         # 30 seconds
}