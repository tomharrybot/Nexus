# Input Validators
import re
from typing import Union, List
from config import Config

class Validators:
    @staticmethod
    def validate_email(email: str) -> bool:
        """Validate email format"""
        if not email or not isinstance(email, str):
            return False
        
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    @staticmethod
    def validate_otp(otp: str) -> bool:
        """Validate OTP (6 digits)"""
        if not otp or not isinstance(otp, str):
            return False
        
        return len(otp) == 6 and otp.isdigit()
    
    @staticmethod
    def validate_username(username: str) -> bool:
        """Validate username"""
        if not username or not isinstance(username, str):
            return False
        
        if len(username) < 2 or len(username) > 50:
            return False
        
        # Allow letters, numbers, spaces, dots, underscores, hyphens
        pattern = r'^[a-zA-Z0-9\s._-]+$'
        return bool(re.match(pattern, username))
    
    @staticmethod
    def validate_password(password: str) -> tuple:
        """Validate password strength"""
        if not password or not isinstance(password, str):
            return False, "Password required"
        
        if len(password) < 6:
            return False, "Password must be at least 6 characters"
        
        if len(password) > 100:
            return False, "Password too long"
        
        # Check for at least one number
        if not re.search(r'\d', password):
            return False, "Password must contain at least one number"
        
        # Check for at least one letter
        if not re.search(r'[a-zA-Z]', password):
            return False, "Password must contain at least one letter"
        
        return True, "Password is valid"
    
    @staticmethod
    def validate_message(message: str) -> bool:
        """Validate message content"""
        if not message:
            return False
        
        if len(message) > 5000:
            return False
        
        return True
    
    @staticmethod
    def validate_file_size(file_size: int, file_type: str = 'document') -> bool:
        """Validate file size"""
        limits = {
            'image': 10 * 1024 * 1024,   # 10MB
            'video': 50 * 1024 * 1024,    # 50MB
            'audio': 20 * 1024 * 1024,    # 20MB
            'document': 25 * 1024 * 1024  # 25MB
        }
        
        max_size = limits.get(file_type, 25 * 1024 * 1024)
        return file_size <= max_size
    
    @staticmethod
    def validate_file_extension(filename: str, allowed_extensions: List[str]) -> bool:
        """Validate file extension"""
        if not filename or '.' not in filename:
            return False
        
        ext = filename.split('.')[-1].lower()
        return ext in allowed_extensions
    
    @staticmethod
    def sanitize_input(text: str) -> str:
        """Sanitize user input (remove harmful characters)"""
        if not text:
            return ""
        
        # Remove any HTML tags
        text = re.sub(r'<[^>]+>', '', text)
        
        # Remove any script tags
        text = re.sub(r'<script.*?>.*?</script>', '', text, flags=re.DOTALL)
        
        # Escape special characters
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        text = text.replace('"', '&quot;')
        text = text.replace("'", '&#x27;')
        
        return text.strip()
    
    @staticmethod
    def validate_group_name(name: str) -> bool:
        """Validate group name"""
        if not name or not isinstance(name, str):
            return False
        
        if len(name) < 3 or len(name) > 50:
            return False
        
        return True
    
    @staticmethod
    def validate_search_query(query: str) -> bool:
        """Validate search query"""
        if not query:
            return False
        
        if len(query) > 100:
            return False
        
        return True

# Singleton instance
validators = Validators()