# Helper Functions
import time
import uuid
import re

def format_timestamp(timestamp, format='short'):
    """Format timestamp for display"""
    if not timestamp:
        return ''
    
    date = time.localtime(timestamp)
    
    if format == 'short':
        return time.strftime('%H:%M', date)
    elif format == 'medium':
        return time.strftime('%d %b %H:%M', date)
    elif format == 'long':
        return time.strftime('%d %B %Y %H:%M', date)
    else:
        return str(timestamp)

def generate_id(prefix=''):
    """Generate unique ID"""
    unique = str(uuid.uuid4()).replace('-', '')[:16]
    if prefix:
        return f"{prefix}_{unique}"
    return unique

def sanitize_filename(filename):
    """Sanitize filename"""
    # Remove path
    filename = filename.split('/')[-1].split('\\')[-1]
    
    # Remove special characters
    filename = re.sub(r'[^\w\-_\. ]', '', filename)
    
    return filename

def truncate_text(text, max_length=100):
    """Truncate text to max length"""
    if len(text) <= max_length:
        return text
    return text[:max_length] + '...'

def parse_user_agent(user_agent):
    """Parse user agent string"""
    # Simple parsing - can be expanded
    result = {
        'browser': 'Unknown',
        'os': 'Unknown',
        'device': 'Unknown'
    }
    
    ua = user_agent.lower()
    
    if 'chrome' in ua:
        result['browser'] = 'Chrome'
    elif 'firefox' in ua:
        result['browser'] = 'Firefox'
    elif 'safari' in ua:
        result['browser'] = 'Safari'
    
    if 'windows' in ua:
        result['os'] = 'Windows'
    elif 'mac' in ua:
        result['os'] = 'macOS'
    elif 'linux' in ua:
        result['os'] = 'Linux'
    elif 'android' in ua:
        result['os'] = 'Android'
        result['device'] = 'Mobile'
    elif 'iphone' in ua:
        result['os'] = 'iOS'
        result['device'] = 'Mobile'
    
    return result