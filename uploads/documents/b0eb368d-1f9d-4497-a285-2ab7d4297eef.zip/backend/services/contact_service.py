# Contact Service
from database import db

class ContactService:
    @staticmethod
    def get_contacts(email):
        """Get all contacts for a user"""
        return db.get_contacts(email)
    
    @staticmethod
    def add_contact(user_email, contact_email):
        """Add a contact"""
        # Get current contacts
        contacts = db.get_contacts(user_email)
        
        # Check if already exists
        if any(c['email'] == contact_email for c in contacts):
            return False, "Contact already exists"
        
        # Get contact user details
        contact_user = db.find_user(contact_email)
        if not contact_user:
            return False, "User not found"
        
        # Create contact
        new_contact = {
            'email': contact_email,
            'name': contact_user.get('profile', {}).get('name', contact_user.get('username')),
            'avatar': contact_user.get('profile', {}).get('avatar'),
            'about': contact_user.get('profile', {}).get('about', ''),
            'added_at': int(time.time()),
            'online': False
        }
        
        contacts.append(new_contact)
        db.save_contacts(user_email, contacts)
        
        return True, new_contact
    
    @staticmethod
    def remove_contact(user_email, contact_email):
        """Remove a contact"""
        contacts = db.get_contacts(user_email)
        contacts = [c for c in contacts if c['email'] != contact_email]
        db.save_contacts(user_email, contacts)
        return True
    
    @staticmethod
    def auto_add_contact(user_email, contact_email):
        """Automatically add contact when first message is sent"""
        # Check if users exist
        user = db.find_user(user_email)
        contact = db.find_user(contact_email)
        
        if not user or not contact:
            return
        
        # Check if already contacts
        user_contacts = db.get_contacts(user_email)
        if any(c['email'] == contact_email for c in user_contacts):
            return
        
        # Add contact
        ContactService.add_contact(user_email, contact_email)
        
        # Add reverse contact
        contact_contacts = db.get_contacts(contact_email)
        if not any(c['email'] == user_email for c in contact_contacts):
            ContactService.add_contact(contact_email, user_email)