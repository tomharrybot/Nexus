# User Service
from database import db
from models.user import User

class UserService:
    @staticmethod
    def get_user(email):
        """Get user by email"""
        return db.find_user(email)
    
    @staticmethod
    def get_all_users():
        """Get all users"""
        return db.get_users()
    
    @staticmethod
    def update_profile(email, profile_data):
        """Update user profile"""
        users = db.get_users()
        for user in users:
            if user['email'] == email:
                if 'profile' not in user:
                    user['profile'] = {}
                user['profile'].update(profile_data)
                db.save_users(users)
                return user
        return None
    
    @staticmethod
    def update_settings(email, settings):
        """Update user settings"""
        users = db.get_users()
        for user in users:
            if user['email'] == email:
                if 'settings' not in user:
                    user['settings'] = {}
                user['settings'].update(settings)
                db.save_users(users)
                return user['settings']
        return None
    
    @staticmethod
    def search_users(query):
        """Search users by email or name"""
        users = db.get_users()
        results = []
        
        for user in users:
            email = user['email'].lower()
            name = user.get('profile', {}).get('name', '').lower()
            
            if query.lower() in email or query.lower() in name:
                results.append({
                    'email': user['email'],
                    'name': user.get('profile', {}).get('name', user['username']),
                    'avatar': user.get('profile', {}).get('avatar'),
                    'about': user.get('profile', {}).get('about', '')
                })
        
        return results