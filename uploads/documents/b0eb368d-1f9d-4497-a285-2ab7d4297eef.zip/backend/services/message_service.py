# Message Service
import time
from database import db
from models.message import Message

class MessageService:
    @staticmethod
    def send_message(from_email, to_email, content, msg_type='text', reply_to=None):
        """Send a message"""
        # Create message
        message = Message.create(from_email, to_email, content, msg_type, reply_to)
        
        # Save to database
        chat = db.get_chat(from_email, to_email)
        if 'messages' not in chat:
            chat['messages'] = []
        
        chat['messages'].append(message)
        db.save_chat(from_email, to_email, chat)
        
        return message
    
    @staticmethod
    def get_chat_history(user1, user2, limit=50):
        """Get chat history between two users"""
        chat = db.get_chat(user1, user2)
        messages = chat.get('messages', [])
        
        # Return last 'limit' messages
        return messages[-limit:]
    
    @staticmethod
    def delete_message(chat_id, message_id, user_email, delete_for='me'):
        """Delete a message"""
        # Parse chat_id to get users
        users = chat_id.split('_')
        if len(users) != 2:
            return False
        
        chat = db.get_chat(users[0], users[1])
        
        for msg in chat.get('messages', []):
            if msg['id'] == message_id:
                if delete_for == 'everyone' and msg['from'] == user_email:
                    # Delete for everyone
                    msg['deleted'] = True
                    msg['message'] = "This message was deleted"
                elif delete_for == 'me':
                    # Just mark as deleted for this user (implementation depends on UI)
                    msg['deleted_for'] = msg.get('deleted_for', [])
                    if user_email not in msg['deleted_for']:
                        msg['deleted_for'].append(user_email)
                break
        
        db.save_chat(users[0], users[1], chat)
        return True
    
    @staticmethod
    def mark_as_read(user_email, contact_email):
        """Mark messages as read"""
        chat = db.get_chat(user_email, contact_email)
        updated = False
        
        for msg in chat.get('messages', []):
            if msg['from'] == contact_email and msg['to'] == user_email:
                if msg['status'] != 'seen':
                    msg['status'] = 'seen'
                    updated = True
        
        if updated:
            db.save_chat(user_email, contact_email, chat)
        
        return updated