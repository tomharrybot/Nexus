# Authentication Service
import random
import time
import hashlib
import secrets
from database import db
from utils.email import EmailService
from models.user import User

class AuthService:
    def __init__(self):
        self.email_service = EmailService()
    
    def generate_otp(self, email):
        """Generate and store OTP"""
        otp = str(random.randint(100000, 999999))
        otps = db.get_otps()
        otps[email] = {
            'code': otp,
            'timestamp': time.time()
        }
        db.save_otps(otps)
        return otp
    
    def send_otp_email(self, email, otp):
        """Send OTP via email"""
        return self.email_service.send_otp(email, otp)
    
    def verify_otp(self, email, code):
        """Verify OTP"""
        otps = db.get_otps()
        stored = otps.get(email)
        
        if not stored:
            return False, "OTP not found"
        
        if stored['code'] != code:
            return False, "Invalid OTP"
        
        if time.time() - stored['timestamp'] > 600:  # 10 minutes
            del otps[email]
            db.save_otps(otps)
            return False, "OTP expired"
        
        # Delete used OTP
        del otps[email]
        db.save_otps(otps)
        
        return True, "OTP verified"
    
    def register_or_login(self, email, username=None):
        """Register new user or login existing"""
        user = db.find_user(email)
        
        if not user:
            # Create new user
            user = User.create_new(email, username or email.split('@')[0])
            db.create_user(user)
        
        # Generate token
        token = self.generate_token(email)
        
        return user, token
    
    def generate_token(self, email):
        """Generate auth token"""
        data = f"{email}:{time.time()}:{secrets.token_hex(16)}"
        return hashlib.sha256(data.encode()).hexdigest()
    
    def validate_token(self, token):
        """Validate token (simplified)"""
        # In production, implement proper JWT validation
        return True