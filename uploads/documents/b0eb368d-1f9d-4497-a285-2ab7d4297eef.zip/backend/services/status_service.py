# Online/Offline Status Service
import time
from database import db

class StatusService:
    # In-memory store for online users
    _online_users = set()
    _user_last_seen = {}  # email -> timestamp
    
    @classmethod
    def update_user_status(cls, email, online):
        """Update user online status"""
        timestamp = int(time.time())
        
        if online:
            cls._online_users.add(email)
            cls._user_last_seen[email] = timestamp
        else:
            cls._online_users.discard(email)
            cls._user_last_seen[email] = timestamp
        
        # Update user's last seen in database
        cls._update_user_last_seen_in_db(email, timestamp)
        
        # Update in all contacts files
        cls._update_contacts_status(email, online, timestamp)
        
        return {
            'email': email,
            'online': online,
            'last_seen': timestamp
        }
    
    @classmethod
    def _update_user_last_seen_in_db(cls, email, timestamp):
        """Update last seen in users database"""
        users = db.get_users()
        for user in users:
            if user['email'] == email:
                if 'profile' not in user:
                    user['profile'] = {}
                user['profile']['lastSeen'] = timestamp
                break
        db.save_users(users)
    
    @classmethod
    def _update_contacts_status(cls, email, online, timestamp):
        """Update status in all contacts files"""
        try:
            import os
            from config import Config
            
            if not os.path.exists(Config.CONTACTS_DIR):
                return
            
            contact_files = os.listdir(Config.CONTACTS_DIR)
            
            for file in contact_files:
                if file.endswith('.json'):
                    file_path = f"{Config.CONTACTS_DIR}/{file}"
                    contacts = db.read_json(file_path, [])
                    
                    updated = False
                    for contact in contacts:
                        if contact.get('email') == email:
                            contact['online'] = online
                            if not online:
                                contact['lastSeen'] = timestamp
                            updated = True
                            break
                    
                    if updated:
                        db.write_json(file_path, contacts)
        except Exception as e:
            print(f"Error updating contacts status: {e}")
    
    @classmethod
    def get_online_users(cls):
        """Get set of online users"""
        return cls._online_users.copy()
    
    @classmethod
    def get_user_status(cls, email):
        """Get user status"""
        return {
            'online': email in cls._online_users,
            'lastSeen': cls._user_last_seen.get(email)
        }
    
    @classmethod
    def is_online(cls, email):
        """Check if user is online"""
        return email in cls._online_users
    
    @classmethod
    def get_last_seen(cls, email):
        """Get user's last seen timestamp"""
        return cls._user_last_seen.get(email)
    
    @classmethod
    def format_last_seen(cls, timestamp):
        """Format last seen timestamp for display"""
        if not timestamp:
            return 'Offline'
        
        now = time.time()
        diff = now - timestamp  # seconds
        
        if diff < 60:
            return 'Online'
        elif diff < 3600:
            mins = int(diff / 60)
            return f"Last seen {mins} minute{'s' if mins > 1 else ''} ago"
        elif diff < 86400:
            hours = int(diff / 3600)
            return f"Last seen {hours} hour{'s' if hours > 1 else ''} ago"
        elif diff < 604800:
            days = int(diff / 86400)
            return f"Last seen {days} day{'s' if days > 1 else ''} ago"
        else:
            from datetime import datetime
            date = datetime.fromtimestamp(timestamp)
            return f"Last seen {date.strftime('%d %b %Y')}"

# Singleton instance
status_service = StatusService()