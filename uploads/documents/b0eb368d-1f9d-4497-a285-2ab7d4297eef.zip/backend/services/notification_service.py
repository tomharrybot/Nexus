# Notification Service
import time
from database import db
from models.notification import Notification

class NotificationService:
    @staticmethod
    def create_notification(to_email, type, data):
        """Create a new notification"""
        notification = Notification.create(to_email, type, data)
        
        # Load existing notifications
        notifications_file = f"{Config.DATA_DIR}/notifications.json"
        notifications = db.read_json(notifications_file, [])
        
        notifications.append(notification)
        db.write_json(notifications_file, notifications)
        
        return notification
    
    @staticmethod
    def get_user_notifications(email, unread_only=False):
        """Get notifications for a user"""
        notifications_file = f"{Config.DATA_DIR}/notifications.json"
        notifications = db.read_json(notifications_file, [])
        
        user_notifications = [n for n in notifications if n['to'] == email]
        
        if unread_only:
            user_notifications = [n for n in user_notifications if not n['read']]
        
        # Sort by date (newest first)
        user_notifications.sort(key=lambda x: x['created_at'], reverse=True)
        
        return user_notifications
    
    @staticmethod
    def mark_as_read(notification_id):
        """Mark notification as read"""
        notifications_file = f"{Config.DATA_DIR}/notifications.json"
        notifications = db.read_json(notifications_file, [])
        
        for n in notifications:
            if n['id'] == notification_id:
                n['read'] = True
                break
        
        db.write_json(notifications_file, notifications)
        return True
    
    @staticmethod
    def mark_all_as_read(email):
        """Mark all notifications as read for a user"""
        notifications_file = f"{Config.DATA_DIR}/notifications.json"
        notifications = db.read_json(notifications_file, [])
        
        for n in notifications:
            if n['to'] == email:
                n['read'] = True
        
        db.write_json(notifications_file, notifications)
        return True
    
    @staticmethod
    def delete_old_notifications(days=30):
        """Delete notifications older than specified days"""
        cutoff = time.time() - (days * 24 * 60 * 60)
        
        notifications_file = f"{Config.DATA_DIR}/notifications.json"
        notifications = db.read_json(notifications_file, [])
        
        notifications = [n for n in notifications if n['created_at'] > cutoff]
        db.write_json(notifications_file, notifications)