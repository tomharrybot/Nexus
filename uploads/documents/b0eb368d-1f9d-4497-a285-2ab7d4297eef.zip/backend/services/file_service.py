# File Service
import os
import uuid
from pathlib import Path
from config import Config

class FileService:
    ALLOWED_EXTENSIONS = {
        'image': ['jpg', 'jpeg', 'png', 'gif', 'webp'],
        'video': ['mp4', 'webm', 'ogg', 'mov'],
        'audio': ['mp3', 'wav', 'ogg', 'm4a'],
        'document': ['pdf', 'doc', 'docx', 'txt', 'xlsx', 'pptx']
    }
    
    @staticmethod
    def save_file(file, file_type):
        """Save uploaded file"""
        # Validate file type
        extension = file.filename.split('.')[-1].lower()
        if extension not in FileService.ALLOWED_EXTENSIONS.get(file_type, []):
            return None, "Invalid file type"
        
        # Generate unique filename
        filename = f"{uuid.uuid4().hex}.{extension}"
        
        # Determine upload path
        upload_path = f"{Config.UPLOADS_DIR}/{file_type}s"
        os.makedirs(upload_path, exist_ok=True)
        
        # Save file
        file_path = f"{upload_path}/{filename}"
        file.save(file_path)
        
        # Get file size
        size = os.path.getsize(file_path)
        
        # Return file info
        return {
            'filename': filename,
            'original_name': file.filename,
            'path': f"/uploads/{file_type}s/{filename}",
            'size': size,
            'type': file_type,
            'extension': extension
        }, None
    
    @staticmethod
    def delete_file(file_path):
        """Delete a file"""
        full_path = f"{Config.UPLOADS_DIR}/{file_path}"
        if os.path.exists(full_path):
            os.remove(full_path)
            return True
        return False
    
    @staticmethod
    def get_file_info(file_path):
        """Get file information"""
        full_path = f"{Config.UPLOADS_DIR}/{file_path}"
        if not os.path.exists(full_path):
            return None
        
        stat = os.stat(full_path)
        return {
            'size': stat.st_size,
            'created': stat.st_ctime,
            'modified': stat.st_mtime
        }