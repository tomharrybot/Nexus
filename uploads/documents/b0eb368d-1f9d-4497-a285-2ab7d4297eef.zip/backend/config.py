import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Server
    PORT = int(os.getenv('PORT', 3000))
    HOST = os.getenv('HOST', '0.0.0.0')
    
    # Database
    DATA_DIR = 'data'
    USERS_FILE = f'{DATA_DIR}/users.json'
    OTP_FILE = f'{DATA_DIR}/otp.json'
    CONTACTS_DIR = f'{DATA_DIR}/contacts'
    CHATS_DIR = f'{DATA_DIR}/chats'
    GROUPS_DIR = f'{DATA_DIR}/groups'
    UPLOADS_DIR = 'uploads'
    
    # Email
    EMAIL_USER = os.getenv('EMAIL_USER', 'mamir34310@gmail.com')
    EMAIL_PASS = os.getenv('EMAIL_PASS', 'vlycilovlpejgqev')
    
    # Security
    JWT_SECRET = os.getenv('JWT_SECRET', 'your-secret-key')
    OTP_EXPIRY = 600  # 10 minutes
    
    # File uploads
    MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
    ALLOWED_EXTENSIONS = {
        'image': ['jpg', 'jpeg', 'png', 'gif', 'webp'],
        'video': ['mp4', 'webm', 'ogg'],
        'audio': ['mp3', 'wav', 'ogg'],
        'document': ['pdf', 'doc', 'docx', 'txt']
    }