# Group Model
import time
import uuid

class Group:
    @staticmethod
    def create(name, creator_email, members=[], avatar=None):
        """Create a new group"""
        group_id = f"group_{uuid.uuid4().hex[:8]}"
        return {
            'id': group_id,
            'name': name,
            'avatar': avatar or '/images/group-avatar.png',
            'creator': creator_email,
            'admins': [creator_email],
            'members': [creator_email] + members,
            'created_at': int(time.time()),
            'last_message': None,
            'last_message_time': None,
            'settings': {
                'allow_messages_from': 'everyone',  # everyone, admins_only
                'approve_new_members': False
            }
        }
    
    @staticmethod
    def add_member(group, email):
        """Add member to group"""
        if email not in group['members']:
            group['members'].append(email)
        return group
    
    @staticmethod
    def remove_member(group, email):
        """Remove member from group"""
        if email in group['members']:
            group['members'].remove(email)
        if email in group['admins']:
            group['admins'].remove(email)
        return group
    
    @staticmethod
    def make_admin(group, email):
        """Make member admin"""
        if email in group['members'] and email not in group['admins']:
            group['admins'].append(email)
        return group