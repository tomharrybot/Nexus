# Chat Model
import time

class Chat:
    @staticmethod
    def create(user1, user2):
        """Create a new chat between two users"""
        chat_id = '_'.join(sorted([user1, user2]))
        return {
            'id': chat_id,
            'users': [user1, user2],
            'messages': [],
            'created_at': int(time.time()),
            'last_message': None,
            'last_message_time': None,
            'is_archived': False,
            'is_muted': False
        }
    
    @staticmethod
    def add_message(chat, message):
        """Add message to chat"""
        if 'messages' not in chat:
            chat['messages'] = []
        chat['messages'].append(message)
        chat['last_message'] = message['id']
        chat['last_message_time'] = message['timestamp']
        return chat
    
    @staticmethod
    def get_messages(chat, limit=50, offset=0):
        """Get messages with pagination"""
        messages = chat.get('messages', [])
        start = len(messages) - offset - limit
        if start < 0:
            start = 0
        return messages[start:start + limit]
    
    @staticmethod
    def mark_as_read(chat, user_email):
        """Mark all messages as read for a user"""
        for msg in chat.get('messages', []):
            if msg['to'] == user_email and msg['status'] != 'seen':
                msg['status'] = 'seen'
        return chat