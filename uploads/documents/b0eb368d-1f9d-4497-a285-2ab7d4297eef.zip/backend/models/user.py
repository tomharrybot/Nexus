# User Model
import time
import hashlib
import secrets
from utils.validators import validators

class User:
    @staticmethod
    def create_new(email, username):
        """Create a new user with special UserID"""
        # Validate inputs
        if not validators.validate_email(email):
            raise ValueError("Invalid email format")
        
        if not validators.validate_username(username):
            raise ValueError("Invalid username")
        
        # Generate unique UserID (NX-XXXX-XXXX-XXXX)
        user_id = User.generate_user_id(email)
        
        # Default avatar
        default_avatar = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23ffffff'%3E%3Cpath d='M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-6.627 0-12 5.373-12 12h24c0-6.627-5.373-12-12-12z'/%3E%3C/svg%3E"
        
        user = {
            'id': user_id,
            'email': email,
            'username': username,
            'created_at': int(time.time()),
            'profile': {
                'name': username,
                'about': "Hey there! I'm using Nexus Chat",
                'avatar': default_avatar,
                'lastSeen': int(time.time())
            },
            'settings': {
                'theme': 'cosmic',
                'notifications': True,
                'sound': True,
                'vibration': True,
                'privacy': {
                    'last_seen': 'everyone',
                    'profile_photo': 'everyone',
                    'about': 'everyone',
                    'groups': 'everyone',
                    'read_receipts': True,
                    'typing_indicator': True
                },
                'security': {
                    'two_factor_auth': False,
                    'login_alerts': True,
                    'active_sessions': [],
                    'device_management': True,
                    'encryption': 'end-to-end'
                }
            },
            'stats': {
                'total_messages': 0,
                'total_contacts': 0,
                'total_groups': 0
            }
        }
        
        return user
    
    @staticmethod
    def generate_user_id(email):
        """Generate a special UserID in format NX-XXXX-XXXX-XXXX"""
        # Create a unique hash
        base = email + str(time.time()) + secrets.token_hex(8)
        hash_obj = hashlib.sha256(base.encode())
        hash_hex = hash_obj.hexdigest()
        
        # Format: NX-XXXX-XXXX-XXXX
        user_id = f"NX-{hash_hex[:4].upper()}-{hash_hex[4:8].upper()}-{hash_hex[8:12].upper()}"
        
        return user_id
    
    @staticmethod
    def generate_token(email):
        """Generate auth token"""
        token_data = f"{email}:{time.time()}:{secrets.token_hex(16)}"
        token = hashlib.sha256(token_data.encode()).hexdigest()
        return token
    
    @staticmethod
    def update_profile(user, updates):
        """Update user profile"""
        if 'profile' not in user:
            user['profile'] = {}
        
        # Update allowed fields
        allowed_fields = ['name', 'about', 'avatar']
        for field in allowed_fields:
            if field in updates:
                if field == 'name' and not validators.validate_username(updates[field]):
                    continue
                user['profile'][field] = updates[field]
        
        return user
    
    @staticmethod
    def update_settings(user, settings_updates):
        """Update user settings"""
        if 'settings' not in user:
            user['settings'] = {}
        
        # Update settings
        for key, value in settings_updates.items():
            if key in ['theme', 'notifications', 'sound', 'vibration']:
                user['settings'][key] = value
            elif key == 'privacy' and isinstance(value, dict):
                if 'privacy' not in user['settings']:
                    user['settings']['privacy'] = {}
                user['settings']['privacy'].update(value)
            elif key == 'security' and isinstance(value, dict):
                if 'security' not in user['settings']:
                    user['settings']['security'] = {}
                user['settings']['security'].update(value)
        
        return user
    
    @staticmethod
    def to_dict(user):
        """Convert user to dictionary (remove sensitive data)"""
        return {
            'id': user.get('id'),
            'email': user.get('email'),
            'username': user.get('username'),
            'profile': user.get('profile', {}),
            'settings': user.get('settings', {}),
            'stats': user.get('stats', {}),
            'created_at': user.get('created_at')
        }
    
    @staticmethod
    def search_match(user, query):
        """Check if user matches search query"""
        query = query.lower()
        
        # Search in email
        if query in user['email'].lower():
            return True
        
        # Search in name
        name = user.get('profile', {}).get('name', '').lower()
        if query in name:
            return True
        
        # Search in username
        if query in user.get('username', '').lower():
            return True
        
        return False

    @staticmethod
    def add_session(user, session_data):
        """Add active session"""
        if 'settings' not in user:
            user['settings'] = {}
        if 'security' not in user['settings']:
            user['settings']['security'] = {}
        if 'active_sessions' not in user['settings']['security']:
            user['settings']['security']['active_sessions'] = []
        
        user['settings']['security']['active_sessions'].append({
            'id': secrets.token_hex(8),
            'device': session_data.get('device', 'Unknown'),
            'location': session_data.get('location', 'Unknown'),
            'ip': session_data.get('ip'),
            'last_active': int(time.time()),
            'created_at': int(time.time())
        })
        
        return user
    
    @staticmethod
    def remove_session(user, session_id):
        """Remove active session"""
        if 'settings' in user and 'security' in user['settings']:
            sessions = user['settings']['security'].get('active_sessions', [])
            user['settings']['security']['active_sessions'] = [
                s for s in sessions if s.get('id') != session_id
            ]
        
        return user