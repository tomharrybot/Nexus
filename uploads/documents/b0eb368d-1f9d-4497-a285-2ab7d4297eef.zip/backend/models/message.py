# Message Model
import time
import uuid

class Message:
    @staticmethod
    def create(from_email, to_email, content, msg_type='text', reply_to=None):
        """Create a new message"""
        message = {
            'id': str(uuid.uuid4()),
            'from': from_email,
            'to': to_email,
            'message': content,
            'type': msg_type,
            'timestamp': int(time.time()),
            'status': 'sent',  # sent, delivered, seen
            'read': False,
            'delivered': False,
            'reply_to': reply_to,
            'forwarded': False,
            'deleted': False,
            'edited': False,
            'reactions': {}
        }
        
        return message
    
    @staticmethod
    def create_reply(original_message, reply_content):
        """Create a reply to a message"""
        reply = {
            'id': str(uuid.uuid4()),
            'from': original_message['to'],
            'to': original_message['from'],
            'message': reply_content,
            'type': 'reply',
            'timestamp': int(time.time()),
            'status': 'sent',
            'reply_to': original_message['id'],
            'original_message': {
                'id': original_message['id'],
                'from': original_message['from'],
                'message': original_message['message'][:100],  # Preview
                'type': original_message['type']
            }
        }
        
        return reply
    
    @staticmethod
    def create_forward(original_message, from_email, to_email):
        """Forward a message"""
        forwarded = {
            'id': str(uuid.uuid4()),
            'from': from_email,
            'to': to_email,
            'message': original_message['message'],
            'type': original_message['type'],
            'timestamp': int(time.time()),
            'status': 'sent',
            'forwarded': True,
            'original_from': original_message['from'],
            'original_timestamp': original_message['timestamp']
        }
        
        return forwarded
    
    @staticmethod
    def create_media_message(from_email, to_email, file_data, msg_type):
        """Create a media message"""
        message = {
            'id': str(uuid.uuid4()),
            'from': from_email,
            'to': to_email,
            'type': msg_type,
            'timestamp': int(time.time()),
            'status': 'sent',
            'file': {
                'url': file_data.get('path'),
                'name': file_data.get('original_name'),
                'size': file_data.get('size'),
                'type': file_data.get('type')
            }
        }
        
        return message
    
    @staticmethod
    def mark_as_delivered(message):
        """Mark message as delivered"""
        message['status'] = 'delivered'
        message['delivered'] = True
        return message
    
    @staticmethod
    def mark_as_read(message):
        """Mark message as read"""
        message['status'] = 'seen'
        message['read'] = True
        return message
    
    @staticmethod
    def mark_as_deleted(message, delete_for='everyone'):
        """Mark message as deleted"""
        message['deleted'] = True
        if delete_for == 'everyone':
            message['message'] = "This message was deleted"
        return message
    
    @staticmethod
    def add_reaction(message, user_email, reaction):
        """Add reaction to message"""
        if 'reactions' not in message:
            message['reactions'] = {}
        
        if reaction not in message['reactions']:
            message['reactions'][reaction] = []
        
        if user_email not in message['reactions'][reaction]:
            message['reactions'][reaction].append(user_email)
        
        return message
    
    @staticmethod
    def remove_reaction(message, user_email, reaction):
        """Remove reaction from message"""
        if 'reactions' in message and reaction in message['reactions']:
            message['reactions'][reaction] = [
                u for u in message['reactions'][reaction] if u != user_email
            ]
            if not message['reactions'][reaction]:
                del message['reactions'][reaction]
        
        return message
    
    @staticmethod
    def get_message_preview(message, max_length=50):
        """Get message preview for chat list"""
        if message.get('deleted'):
            return "This message was deleted"
        
        msg_type = message.get('type', 'text')
        content = message.get('message', '')
        
        previews = {
            'image': '📷 Photo',
            'video': '🎥 Video',
            'audio': '🎵 Voice message',
            'file': '📄 File',
            'location': '📍 Location',
            'contact': '👤 Contact',
            'sticker': '✨ Sticker',
            'gif': '🎬 GIF'
        }
        
        if msg_type in previews:
            return previews[msg_type]
        
        if len(content) > max_length:
            return content[:max_length] + '...'
        
        return content