# Notification Model
import time
import uuid

class Notification:
    TYPES = {
        'message': 'New Message',
        'group_invite': 'Group Invite',
        'contact_request': 'Contact Request',
        'mention': 'Mentioned You',
        'reply': 'Replied to You'
    }
    
    @staticmethod
    def create(to_email, type, data):
        """Create a new notification"""
        return {
            'id': str(uuid.uuid4()),
            'to': to_email,
            'type': type,
            'title': Notification.TYPES.get(type, 'Notification'),
            'data': data,
            'created_at': int(time.time()),
            'read': False,
            'clicked': False
        }
    
    @staticmethod
    def mark_as_read(notification):
        """Mark notification as read"""
        notification['read'] = True
        return notification
    
    @staticmethod
    def mark_as_clicked(notification):
        """Mark notification as clicked"""
        notification['clicked'] = True
        return notification