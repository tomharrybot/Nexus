from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn
import os

# Import routes
from routes import auth, users, chats, groups, contacts, media, privacy, security, support
from sockets.events import sio
from config import Config
import socketio

# Create FastAPI app
app = FastAPI(title="Nexus Chat API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory="../frontend"), name="static")
app.mount("/uploads", StaticFiles(directory=Config.UPLOADS_DIR), name="uploads")

# Include routers
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(chats.router)
app.include_router(groups.router)
app.include_router(contacts.router)
app.include_router(media.router)
app.include_router(privacy.router)
app.include_router(security.router)
app.include_router(support.router)

# Socket.IO app
socket_app = socketio.ASGIApp(sio, app)

@app.get("/")
async def root():
    return {"message": "Welcome to Nexus Chat API", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    uvicorn.run(
        "app:socket_app",
        host=Config.HOST,
        port=Config.PORT,
        reload=True
    )