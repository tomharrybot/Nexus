from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from database import db
import time
import uuid

router = APIRouter(prefix="/support", tags=["Support"])

class SupportTicket(BaseModel):
    email: EmailStr
    subject: str
    message: str
    category: str  # bug, feature, question, other
    attachments: list = []

class TicketResponse(BaseModel):
    ticket_id: str
    user_email: EmailStr
    message: str

class FAQItem(BaseModel):
    id: str
    question: str
    answer: str
    category: str

@router.post("/ticket/create")
async def create_ticket(ticket: SupportTicket):
    """Create a support ticket"""
    ticket_id = f"TICKET-{uuid.uuid4().hex[:8].upper()}"
    
    ticket_data = {
        'id': ticket_id,
        'email': ticket.email,
        'subject': ticket.subject,
        'message': ticket.message,
        'category': ticket.category,
        'attachments': ticket.attachments,
        'status': 'open',
        'created_at': str(int(time.time())),
        'responses': []
    }
    
    # Save ticket
    tickets_file = f"{Config.DATA_DIR}/tickets.json"
    tickets = db.read_json(tickets_file, [])
    tickets.append(ticket_data)
    db.write_json(tickets_file, tickets)
    
    return {
        "status": "ok",
        "message": "Ticket created",
        "ticket_id": ticket_id
    }

@router.get("/tickets/{email}")
async def get_user_tickets(email: str):
    """Get all tickets for a user"""
    tickets_file = f"{Config.DATA_DIR}/tickets.json"
    tickets = db.read_json(tickets_file, [])
    
    user_tickets = [t for t in tickets if t['email'] == email]
    return user_tickets

@router.get("/ticket/{ticket_id}")
async def get_ticket(ticket_id: str):
    """Get ticket details"""
    tickets_file = f"{Config.DATA_DIR}/tickets.json"
    tickets = db.read_json(tickets_file, [])
    
    ticket = next((t for t in tickets if t['id'] == ticket_id), None)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    return ticket

@router.post("/ticket/respond")
async def respond_to_ticket(response: TicketResponse):
    """Add response to ticket"""
    tickets_file = f"{Config.DATA_DIR}/tickets.json"
    tickets = db.read_json(tickets_file, [])
    
    ticket = next((t for t in tickets if t['id'] == response.ticket_id), None)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    if 'responses' not in ticket:
        ticket['responses'] = []
    
    ticket['responses'].append({
        'user_email': response.user_email,
        'message': response.message,
        'timestamp': str(int(time.time()))
    })
    
    db.write_json(tickets_file, tickets)
    
    return {"status": "ok", "message": "Response added"}

@router.get("/faq")
async def get_faq():
    """Get FAQ list"""
    faq = [
        {
            "id": "faq-1",
            "question": "How do I create an account?",
            "answer": "Simply enter your email, receive OTP, and verify. It's that easy!",
            "category": "account"
        },
        {
            "id": "faq-2",
            "question": "Is Nexus Chat free?",
            "answer": "Yes, Nexus Chat is completely free with premium features coming soon.",
            "category": "pricing"
        },
        {
            "id": "faq-3",
            "question": "How do I send media files?",
            "answer": "Click the attachment icon in chat to upload images, videos, audio, or documents.",
            "category": "features"
        },
        {
            "id": "faq-4",
            "question": "How do I block a user?",
            "answer": "Go to chat menu > Block, or visit Privacy settings to manage blocked users.",
            "category": "privacy"
        },
        {
            "id": "faq-5",
            "question": "Can I delete messages?",
            "answer": "Yes, long press on any message to see delete option.",
            "category": "features"
        }
    ]
    
    return faq

@router.get("/contact")
async def get_contact_info():
    """Get support contact information"""
    return {
        "email": "support@nexus.chat",
        "website": "https://nexus.chat",
        "hours": "24/7 Support",
        "response_time": "Within 24 hours"
    }