"""
Nexus Chat Routes Package
All API endpoints organized by feature
"""

from .auth import router as auth_router
from .users import router as users_router
from .chats import router as chats_router
from .groups import router as groups_router
from .contacts import router as contacts_router
from .media import router as media_router
from .privacy import router as privacy_router
from .security import router as security_router
from .support import router as support_router
from .admin import router as admin_router

__all__ = [
    'auth_router',
    'users_router',
    'chats_router',
    'groups_router',
    'contacts_router',
    'media_router',
    'privacy_router',
    'security_router',
    'support_router',
    'admin_router'
]