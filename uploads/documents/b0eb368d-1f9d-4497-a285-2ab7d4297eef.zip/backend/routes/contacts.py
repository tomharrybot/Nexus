from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from database import db
from models.user import User

router = APIRouter(prefix="/contacts", tags=["Contacts"])

class AddContactRequest(BaseModel):
    user_email: EmailStr
    contact_email: EmailStr

class DeleteContactRequest(BaseModel):
    user_email: EmailStr
    contact_email: EmailStr

@router.get("/{email}")
async def get_contacts(email: str):
    """Get all contacts for a user"""
    contacts = db.get_contacts(email)
    
    # Add online status
    from services.status_service import get_online_users
    online_users = get_online_users()
    
    for contact in contacts:
        contact['online'] = contact['email'] in online_users
    
    return contacts

@router.post("/add")
async def add_contact(request: AddContactRequest):
    """Add a new contact"""
    user_email = request.user_email
    contact_email = request.contact_email
    
    # Check if users exist
    contact_user = db.find_user(contact_email)
    if not contact_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Get current contacts
    contacts = db.get_contacts(user_email)
    
    # Check if already exists
    if any(c['email'] == contact_email for c in contacts):
        raise HTTPException(status_code=400, detail="Contact already exists")
    
    # Create contact
    new_contact = {
        'email': contact_email,
        'name': contact_user.get('profile', {}).get('name', contact_user.get('username')),
        'avatar': contact_user.get('profile', {}).get('avatar'),
        'about': contact_user.get('profile', {}).get('about', ''),
        'added_at': str(int(time.time())),
        'last_seen': contact_user.get('profile', {}).get('lastSeen'),
        'online': False,
        'last_message': '',
        'last_time': ''
    }
    
    contacts.append(new_contact)
    db.save_contacts(user_email, contacts)
    
    # Add reverse contact automatically
    reverse_contacts = db.get_contacts(contact_email)
    if not any(c['email'] == user_email for c in reverse_contacts):
        user = db.find_user(user_email)
        reverse_contact = {
            'email': user_email,
            'name': user.get('profile', {}).get('name', user.get('username')),
            'avatar': user.get('profile', {}).get('avatar'),
            'about': user.get('profile', {}).get('about', ''),
            'added_at': str(int(time.time())),
            'last_seen': user.get('profile', {}).get('lastSeen'),
            'online': False,
            'last_message': '',
            'last_time': ''
        }
        reverse_contacts.append(reverse_contact)
        db.save_contacts(contact_email, reverse_contacts)
    
    return {
        "status": "ok",
        "message": "Contact added",
        "contact": new_contact
    }

@router.post("/delete")
async def delete_contact(request: DeleteContactRequest):
    """Delete a contact"""
    contacts = db.get_contacts(request.user_email)
    contacts = [c for c in contacts if c['email'] != request.contact_email]
    db.save_contacts(request.user_email, contacts)
    
    return {"status": "ok", "message": "Contact deleted"}