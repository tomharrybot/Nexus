from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from database import db
import time
import uuid

router = APIRouter(prefix="/groups", tags=["Groups"])

class CreateGroupRequest(BaseModel):
    creator_email: str
    group_name: str
    group_avatar: str | None = None
    members: list[str]

class SendGroupMessageRequest(BaseModel):
    group_id: str
    from_email: str
    message: str
    type: str = "text"

@router.post("/create")
async def create_group(request: CreateGroupRequest):
    """Create a new group"""
    group_id = f"group_{uuid.uuid4().hex[:8]}"
    
    group = {
        'id': group_id,
        'name': request.group_name,
        'avatar': request.group_avatar,
        'creator': request.creator_email,
        'admins': [request.creator_email],
        'members': [request.creator_email] + request.members,
        'created_at': str(int(time.time())),
        'last_message': None,
        'last_message_time': None
    }
    
    # Save group
    group_file = f"{Config.GROUPS_DIR}/{group_id}.json"
    db.write_json(group_file, group)
    
    # Create group chat file
    chat_file = f"{Config.CHATS_DIR}/{group_id}.json"
    db.write_json(chat_file, {'messages': [], 'type': 'group'})
    
    return {
        "status": "ok",
        "message": "Group created",
        "group": group
    }

@router.post("/send-message")
async def send_group_message(request: SendGroupMessageRequest):
    """Send message to group"""
    message = {
        'id': str(int(time.time() * 1000)),
        'from': request.from_email,
        'group_id': request.group_id,
        'message': request.message,
        'type': request.type,
        'timestamp': str(int(time.time())),
        'status': 'sent'
    }
    
    # Save to group chat
    chat_file = f"{Config.CHATS_DIR}/{request.group_id}.json"
    chat = db.read_json(chat_file, {'messages': []})
    chat['messages'].append(message)
    db.write_json(chat_file, chat)
    
    # Update group last message
    group_file = f"{Config.GROUPS_DIR}/{request.group_id}.json"
    group = db.read_json(group_file)
    if group:
        group['last_message'] = message['message'] if request.type == 'text' else f"[{request.type}]"
        group['last_message_time'] = message['timestamp']
        db.write_json(group_file, group)
    
    return {
        "status": "ok",
        "message": message
    }

@router.get("/user/{email}")
async def get_user_groups(email: str):
    """Get all groups for a user"""
    groups = []
    
    # Read all group files
    for filename in os.listdir(Config.GROUPS_DIR):
        if filename.endswith('.json'):
            group_file = f"{Config.GROUPS_DIR}/{filename}"
            group = db.read_json(group_file)
            if group and email in group.get('members', []):
                groups.append(group)
    
    return groups