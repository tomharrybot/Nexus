from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
import random
import time
from utils.email import EmailService
from database import db
from models.user import User

router = APIRouter(prefix="/auth", tags=["Authentication"])
email_service = EmailService()

class SendOTPRequest(BaseModel):
    email: EmailStr

class VerifyOTPRequest(BaseModel):
    email: EmailStr
    code: str
    username: str | None = None

@router.post("/send-otp")
async def send_otp(request: SendOTPRequest):
    """Send OTP to user's email"""
    email = request.email
    
    # Generate 6-digit OTP
    otp = str(random.randint(100000, 999999))
    
    # Store OTP with timestamp
    otps = db.get_otps()
    otps[email] = {
        'code': otp,
        'timestamp': time.time()
    }
    db.save_otps(otps)
    
    # Send email
    if email_service.send_otp(email, otp):
        return {"status": "ok", "message": "OTP sent successfully"}
    else:
        raise HTTPException(status_code=500, detail="Failed to send OTP")

@router.post("/verify-otp")
async def verify_otp(request: VerifyOTPRequest):
    """Verify OTP and login/register user"""
    email = request.email
    code = request.code
    username = request.username
    
    # Check OTP
    otps = db.get_otps()
    stored = otps.get(email)
    
    if not stored:
        raise HTTPException(status_code=400, detail="OTP not found")
    
    if stored['code'] != code:
        raise HTTPException(status_code=400, detail="Invalid OTP")
    
    # Check expiry (10 minutes)
    if time.time() - stored['timestamp'] > 600:
        del otps[email]
        db.save_otps(otps)
        raise HTTPException(status_code=400, detail="OTP expired")
    
    # Delete used OTP
    del otps[email]
    db.save_otps(otps)
    
    # Find or create user
    user = db.find_user(email)
    if not user:
        # Create new user with special UserID
        user = User.create_new(
            email=email,
            username=username or email.split('@')[0]
        )
        db.create_user(user)
    
    # Generate token (for future use)
    token = User.generate_token(user['email'])
    
    return {
        "status": "ok",
        "message": "Verification successful",
        "user": user,
        "token": token
    }