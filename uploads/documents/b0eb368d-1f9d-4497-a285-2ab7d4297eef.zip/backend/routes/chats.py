from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from database import db
from models.message import Message
from models.user import User
import time

router = APIRouter(prefix="/chats", tags=["Chats"])

class GetChatRequest(BaseModel):
    user1: str
    user2: str

class SendMessageRequest(BaseModel):
    from_email: str
    to_email: str
    message: str
    type: str = "text"
    reply_to: str | None = None

class UpdateStatusRequest(BaseModel):
    chat_id: str
    message_id: str
    status: str

class MarkSeenRequest(BaseModel):
    user_email: str
    contact_email: str

class DeleteMessageRequest(BaseModel):
    message_id: str
    chat_id: str
    user_email: str

class ForwardMessageRequest(BaseModel):
    from_email: str
    to_email: str
    original_message: dict

@router.post("/get")
async def get_chat(request: GetChatRequest):
    """Get chat between two users"""
    chat = db.get_chat(request.user1, request.user2)
    return chat

@router.post("/send")
async def send_message(request: SendMessageRequest):
    """Send a message"""
    # Create message
    message = Message.create(
        from_email=request.from_email,
        to_email=request.to_email,
        content=request.message,
        msg_type=request.type,
        reply_to=request.reply_to
    )
    
    # Save to database
    chat = db.get_chat(request.from_email, request.to_email)
    chat['messages'].append(message)
    db.save_chat(request.from_email, request.to_email, chat)
    
    # Auto-add contact if not exists
    from services.contact_service import auto_add_contact
    auto_add_contact(request.from_email, request.to_email)
    auto_add_contact(request.to_email, request.from_email)
    
    return {
        "status": "ok",
        "message": message
    }

@router.post("/delete-message")
async def delete_message(request: DeleteMessageRequest):
    """Delete a message"""
    chat = db.get_chat_by_id(request.chat_id)
    
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    
    # Find and mark message as deleted
    for msg in chat['messages']:
        if msg['id'] == request.message_id:
            if msg['from'] != request.user_email:
                raise HTTPException(status_code=403, detail="Can only delete own messages")
            msg['deleted'] = True
            msg['message'] = "This message was deleted"
            break
    
    db.save_chat_by_id(request.chat_id, chat)
    
    return {"status": "ok", "message": "Message deleted"}

@router.post("/forward")
async def forward_message(request: ForwardMessageRequest):
    """Forward a message"""
    # Create forwarded message
    forwarded = request.original_message.copy()
    forwarded['id'] = str(int(time.time() * 1000))
    forwarded['from'] = request.from_email
    forwarded['to'] = request.to_email
    forwarded['timestamp'] = time.time()
    forwarded['forwarded'] = True
    forwarded['status'] = 'sent'
    
    # Save to database
    chat = db.get_chat(request.from_email, request.to_email)
    chat['messages'].append(forwarded)
    db.save_chat(request.from_email, request.to_email, chat)
    
    # Auto-add contact
    from services.contact_service import auto_add_contact
    auto_add_contact(request.from_email, request.to_email)
    
    return {
        "status": "ok",
        "message": forwarded
    }

@router.post("/update-status")
async def update_status(request: UpdateStatusRequest):
    """Update message status"""
    chat = db.get_chat_by_id(request.chat_id)
    
    if chat:
        for msg in chat['messages']:
            if msg['id'] == request.message_id:
                msg['status'] = request.status
                break
        db.save_chat_by_id(request.chat_id, chat)
    
    return {"status": "ok"}

@router.post("/mark-seen")
async def mark_seen(request: MarkSeenRequest):
    """Mark messages as seen"""
    chat = db.get_chat(request.user_email, request.contact_email)
    
    updated = False
    for msg in chat['messages']:
        if msg['from'] == request.contact_email and msg['status'] != 'seen':
            msg['status'] = 'seen'
            updated = True
    
    if updated:
        db.save_chat(request.user_email, request.contact_email, chat)
    
    return {"status": "ok", "updated": updated}