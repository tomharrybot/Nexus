from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from database import db
import os
import shutil

router = APIRouter(prefix="/admin", tags=["Admin"])

class AdminLoginRequest(BaseModel):
    username: str
    password: str

class SystemStats(BaseModel):
    total_users: int
    total_messages: int
    total_groups: int
    total_files: int
    storage_used: str
    online_users: int

@router.post("/login")
async def admin_login(request: AdminLoginRequest):
    """Admin login (simple for demo)"""
    if request.username == "admin" and request.password == "nexus2024":
        return {"status": "ok", "token": "admin-token"}
    raise HTTPException(status_code=401, detail="Invalid credentials")

@router.get("/stats")
async def get_system_stats():
    """Get system statistics"""
    users = db.get_users()
    
    # Count messages
    total_messages = 0
    chat_files = os.listdir(Config.CHATS_DIR)
    for chat_file in chat_files:
        if chat_file.endswith('.json'):
            chat = db.read_json(f"{Config.CHATS_DIR}/{chat_file}", {})
            total_messages += len(chat.get('messages', []))
    
    # Count groups
    group_files = os.listdir(Config.GROUPS_DIR)
    total_groups = len([f for f in group_files if f.endswith('.json')])
    
    # Count files
    upload_dirs = ['images', 'videos', 'audio', 'documents']
    total_files = 0
    total_size = 0
    
    for dir_name in upload_dirs:
        dir_path = f"{Config.UPLOADS_DIR}/{dir_name}"
        if os.path.exists(dir_path):
            files = os.listdir(dir_path)
            total_files += len(files)
            for file in files:
                file_path = f"{dir_path}/{file}"
                if os.path.isfile(file_path):
                    total_size += os.path.getsize(file_path)
    
    # Format storage
    if total_size < 1024 * 1024:
        storage = f"{total_size / 1024:.1f} KB"
    elif total_size < 1024 * 1024 * 1024:
        storage = f"{total_size / (1024 * 1024):.1f} MB"
    else:
        storage = f"{total_size / (1024 * 1024 * 1024):.1f} GB"
    
    # Online users
    from services.status_service import get_online_users
    online_users = len(get_online_users())
    
    return {
        "total_users": len(users),
        "total_messages": total_messages,
        "total_groups": total_groups,
        "total_files": total_files,
        "storage_used": storage,
        "online_users": online_users
    }

@router.get("/users")
async def get_all_users_admin():
    """Get all users (admin only)"""
    users = db.get_users()
    return users

@router.delete("/user/{email}")
async def delete_user(email: str):
    """Delete a user (admin only)"""
    users = db.get_users()
    users = [u for u in users if u['email'] != email]
    db.save_users(users)
    
    # Delete user data
    contact_file = f"{Config.CONTACTS_DIR}/{email}.json"
    if os.path.exists(contact_file):
        os.remove(contact_file)
    
    return {"status": "ok", "message": "User deleted"}

@router.post("/cleanup")
async def cleanup_orphaned_files():
    """Clean up orphaned files"""
    # Get all valid emails
    users = db.get_users()
    valid_emails = [u['email'] for u in users]
    
    # Clean up orphaned contacts
    contact_files = os.listdir(Config.CONTACTS_DIR)
    for file in contact_files:
        if file.endswith('.json'):
            email = file.replace('.json', '')
            if email not in valid_emails:
                os.remove(f"{Config.CONTACTS_DIR}/{file}")
    
    return {"status": "ok", "message": "Cleanup completed"}