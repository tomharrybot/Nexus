from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from database import db
from models.user import User
import time

router = APIRouter(prefix="/users", tags=["Users"])

class UpdateProfileRequest(BaseModel):
    email: EmailStr
    name: str | None = None
    about: str | None = None
    avatar: str | None = None

class UpdateSettingsRequest(BaseModel):
    email: EmailStr
    theme: str | None = None
    notifications: bool | None = None
    privacy: dict | None = None
    security: dict | None = None

class OnlineStatusRequest(BaseModel):
    email: EmailStr
    online: bool

@router.get("/all")
async def get_all_users():
    """Get all users"""
    users = db.get_users()
    
    # Add online status
    from services.status_service import get_online_users
    online_users = get_online_users()
    
    for user in users:
        user['online'] = user['email'] in online_users
    
    return users

@router.get("/{email}")
async def get_user(email: str):
    """Get user by email"""
    user = db.find_user(email)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Add online status
    from services.status_service import get_online_users
    user['online'] = email in get_online_users()
    
    return user

@router.post("/profile/update")
async def update_profile(request: UpdateProfileRequest):
    """Update user profile"""
    users = db.get_users()
    user = next((u for u in users if u['email'] == request.email), None)
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Update profile
    if 'profile' not in user:
        user['profile'] = {}
    
    if request.name:
        user['profile']['name'] = request.name
    if request.about:
        user['profile']['about'] = request.about
    if request.avatar:
        user['profile']['avatar'] = request.avatar
    
    db.save_users(users)
    
    return {
        "status": "ok",
        "message": "Profile updated",
        "user": user
    }

@router.post("/settings/update")
async def update_settings(request: UpdateSettingsRequest):
    """Update user settings"""
    users = db.get_users()
    user = next((u for u in users if u['email'] == request.email), None)
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Update settings
    if 'settings' not in user:
        user['settings'] = {}
    
    if request.theme:
        user['settings']['theme'] = request.theme
    if request.notifications is not None:
        user['settings']['notifications'] = request.notifications
    if request.privacy:
        user['settings']['privacy'] = request.privacy
    if request.security:
        user['settings']['security'] = request.security
    
    db.save_users(users)
    
    return {
        "status": "ok",
        "message": "Settings updated",
        "settings": user['settings']
    }

@router.post("/status")
async def update_online_status(request: OnlineStatusRequest):
    """Update user online status"""
    from services.status_service import update_user_status
    update_user_status(request.email, request.online)
    
    return {"status": "ok", "message": "Status updated"}

@router.get("/status/{email}")
async def get_online_status(email: str):
    """Get user online status"""
    from services.status_service import get_user_status
    status = get_user_status(email)
    
    return status