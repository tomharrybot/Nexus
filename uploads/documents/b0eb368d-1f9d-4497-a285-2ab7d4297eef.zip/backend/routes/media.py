from fastapi import APIRouter, UploadFile, File, HTTPException, Form
from fastapi.responses import FileResponse
import os
import uuid
from pathlib import Path
from config import Config

router = APIRouter(prefix="/media", tags=["Media"])

UPLOAD_DIR = Config.UPLOADS_DIR

@router.post("/upload")
async def upload_media(
    file: UploadFile = File(...),
    type: str = Form(...)
):
    """Upload media file"""
    # Validate file size
    file.file.seek(0, 2)
    file_size = file.file.tell()
    file.file.seek(0)
    
    if file_size > Config.MAX_FILE_SIZE:
        raise HTTPException(status_code=400, detail="File too large")
    
    # Validate file type
    extension = file.filename.split('.')[-1].lower()
    
    if type == 'image':
        if extension not in Config.ALLOWED_EXTENSIONS['image']:
            raise HTTPException(status_code=400, detail="Invalid image format")
        upload_path = f"{UPLOAD_DIR}/images"
    elif type == 'video':
        if extension not in Config.ALLOWED_EXTENSIONS['video']:
            raise HTTPException(status_code=400, detail="Invalid video format")
        upload_path = f"{UPLOAD_DIR}/videos"
    elif type == 'audio':
        if extension not in Config.ALLOWED_EXTENSIONS['audio']:
            raise HTTPException(status_code=400, detail="Invalid audio format")
        upload_path = f"{UPLOAD_DIR}/audio"
    else:
        if extension not in Config.ALLOWED_EXTENSIONS['document']:
            raise HTTPException(status_code=400, detail="Invalid document format")
        upload_path = f"{UPLOAD_DIR}/documents"
    
    # Generate unique filename
    filename = f"{uuid.uuid4()}.{extension}"
    file_path = f"{upload_path}/{filename}"
    
    # Save file
    os.makedirs(upload_path, exist_ok=True)
    with open(file_path, "wb") as buffer:
        content = await file.read()
        buffer.write(content)
    
    # Return URL
    file_url = f"/uploads/{type}s/{filename}"
    
    return {
        "status": "ok",
        "url": file_url,
        "filename": filename,
        "size": file_size
    }

@router.get("/{type}/{filename}")
async def get_media(type: str, filename: str):
    """Get media file"""
    file_path = f"{UPLOAD_DIR}/{type}s/{filename}"
    
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    
    return FileResponse(file_path)