from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from database import db

router = APIRouter(prefix="/privacy", tags=["Privacy"])

class PrivacySettings(BaseModel):
    last_seen: str = "everyone"  # everyone, contacts, nobody
    profile_photo: str = "everyone"
    about: str = "everyone"
    groups: str = "everyone"
    read_receipts: bool = True
    typing_indicator: bool = True

class UpdatePrivacyRequest(BaseModel):
    email: EmailStr
    settings: PrivacySettings

class BlockUserRequest(BaseModel):
    user_email: EmailStr
    block_email: EmailStr

class UnblockUserRequest(BaseModel):
    user_email: EmailStr
    unblock_email: EmailStr

@router.get("/settings/{email}")
async def get_privacy_settings(email: str):
    """Get user privacy settings"""
    user = db.find_user(email)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Return settings or default
    return user.get('settings', {}).get('privacy', PrivacySettings().dict())

@router.post("/settings/update")
async def update_privacy_settings(request: UpdatePrivacyRequest):
    """Update privacy settings"""
    users = db.get_users()
    user = next((u for u in users if u['email'] == request.email), None)
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if 'settings' not in user:
        user['settings'] = {}
    
    user['settings']['privacy'] = request.settings.dict()
    db.save_users(users)
    
    return {
        "status": "ok",
        "message": "Privacy settings updated",
        "settings": request.settings
    }

@router.post("/block")
async def block_user(request: BlockUserRequest):
    """Block a user"""
    blocked_file = f"{Config.DATA_DIR}/blocked.json"
    blocked = db.read_json(blocked_file, {})
    
    if request.user_email not in blocked:
        blocked[request.user_email] = []
    
    if request.block_email not in blocked[request.user_email]:
        blocked[request.user_email].append(request.block_email)
        db.write_json(blocked_file, blocked)
    
    return {"status": "ok", "message": "User blocked"}

@router.post("/unblock")
async def unblock_user(request: UnblockUserRequest):
    """Unblock a user"""
    blocked_file = f"{Config.DATA_DIR}/blocked.json"
    blocked = db.read_json(blocked_file, {})
    
    if request.user_email in blocked:
        blocked[request.user_email] = [
            email for email in blocked[request.user_email] 
            if email != request.unblock_email
        ]
        db.write_json(blocked_file, blocked)
    
    return {"status": "ok", "message": "User unblocked"}

@router.get("/blocked/{email}")
async def get_blocked_users(email: str):
    """Get list of blocked users"""
    blocked_file = f"{Config.DATA_DIR}/blocked.json"
    blocked = db.read_json(blocked_file, {})
    
    return blocked.get(email, [])