from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from database import db
import hashlib
import secrets

router = APIRouter(prefix="/security", tags=["Security"])

class SecuritySettings(BaseModel):
    two_factor_auth: bool = False
    login_alerts: bool = True
    active_sessions: list = []
    device_management: bool = True
    encryption: str = "end-to-end"

class UpdateSecurityRequest(BaseModel):
    email: EmailStr
    settings: SecuritySettings

class SessionRequest(BaseModel):
    email: EmailStr
    session_id: str | None = None

class ChangePasswordRequest(BaseModel):
    email: EmailStr
    current_password: str | None = None
    new_password: str

@router.get("/settings/{email}")
async def get_security_settings(email: str):
    """Get security settings"""
    user = db.find_user(email)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    return user.get('settings', {}).get('security', SecuritySettings().dict())

@router.post("/settings/update")
async def update_security_settings(request: UpdateSecurityRequest):
    """Update security settings"""
    users = db.get_users()
    user = next((u for u in users if u['email'] == request.email), None)
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if 'settings' not in user:
        user['settings'] = {}
    
    user['settings']['security'] = request.settings.dict()
    db.save_users(users)
    
    return {
        "status": "ok",
        "message": "Security settings updated"
    }

@router.post("/sessions/revoke")
async def revoke_session(request: SessionRequest):
    """Revoke a session"""
    users = db.get_users()
    user = next((u for u in users if u['email'] == request.email), None)
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if 'settings' not in user:
        user['settings'] = {}
    if 'security' not in user['settings']:
        user['settings']['security'] = SecuritySettings().dict()
    
    # Remove session
    sessions = user['settings']['security'].get('active_sessions', [])
    user['settings']['security']['active_sessions'] = [
        s for s in sessions if s.get('id') != request.session_id
    ]
    
    db.save_users(users)
    
    return {"status": "ok", "message": "Session revoked"}

@router.post("/password/change")
async def change_password(request: ChangePasswordRequest):
    """Change user password"""
    users = db.get_users()
    user = next((u for u in users if u['email'] == request.email), None)
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Hash new password
    hashed = hashlib.sha256(request.new_password.encode()).hexdigest()
    
    if 'security' not in user:
        user['security'] = {}
    
    user['security']['password'] = hashed
    db.save_users(users)
    
    return {"status": "ok", "message": "Password changed"}