# Main Socket Events
from socketio import AsyncServer
from services.status_service import status_service
from database import db
import time

sio = AsyncServer(cors_allowed_origins='*')

@sio.event
async def connect(sid, environ):
    """Handle client connection"""
    print(f"Client connected: {sid}")
    await sio.save_session(sid, {})

@sio.event
async def disconnect(sid):
    """Handle client disconnection"""
    session = await sio.get_session(sid)
    email = session.get('email')
    
    if email:
        # Update status to offline
        status_service.update_user_status(email, False)
        print(f"User {email} disconnected")
        
        # Notify contacts
        contacts = db.get_contacts(email)
        online_users = status_service.get_online_users()
        
        for contact in contacts:
            contact_email = contact.get('email')
            if contact_email in online_users:
                await sio.emit('user_offline', {
                    'email': email,
                    'lastSeen': int(time.time())
                }, room=contact_email)

@sio.event
async def user_login(sid, data):
    """Handle user login"""
    email = data.get('email')
    
    if email:
        await sio.save_session(sid, {'email': email})
        
        # Update status to online
        status_service.update_user_status(email, True)
        print(f"User {email} logged in")
        
        # Notify contacts
        contacts = db.get_contacts(email)
        online_users = status_service.get_online_users()
        
        for contact in contacts:
            contact_email = contact.get('email')
            if contact_email in online_users:
                await sio.emit('user_online', {
                    'email': email
                }, room=contact_email)
        
        return {'status': 'ok', 'message': 'Login successful'}

@sio.event
async def send_message(sid, data):
    """Handle sending message"""
    session = await sio.get_session(sid)
    from_email = session.get('email')
    
    if not from_email:
        return {'status': 'error', 'message': 'Not authenticated'}
    
    to_email = data.get('to')
    message = data.get('message')
    msg_type = data.get('type', 'text')
    
    if not to_email or not message:
        return {'status': 'error', 'message': 'Missing required fields'}
    
    # Create message
    from models.message import Message
    new_message = Message.create(from_email, to_email, message, msg_type)
    
    # Save to database
    chat = db.get_chat(from_email, to_email)
    if 'messages' not in chat:
        chat['messages'] = []
    chat['messages'].append(new_message)
    db.save_chat(from_email, to_email, chat)
    
    # Auto-add contacts
    from services.contact_service import ContactService
    ContactService.auto_add_contact(from_email, to_email)
    
    # Send to recipient if online
    online_users = status_service.get_online_users()
    if to_email in online_users:
        await sio.emit('new_message', {
            'message': new_message
        }, room=to_email)
        
        # Update status to delivered
        new_message['status'] = 'delivered'
        await sio.emit('message_status', {
            'messageId': new_message['id'],
            'status': 'delivered'
        }, room=from_email)
    
    return {'status': 'ok', 'message': new_message}

@sio.event
async def typing_start(sid, data):
    """User started typing"""
    session = await sio.get_session(sid)
    from_email = session.get('email')
    to_email = data.get('to')
    
    if from_email and to_email:
        online_users = status_service.get_online_users()
        if to_email in online_users:
            await sio.emit('typing_started', {
                'from': from_email
            }, room=to_email)

@sio.event
async def typing_stop(sid, data):
    """User stopped typing"""
    session = await sio.get_session(sid)
    from_email = session.get('email')
    to_email = data.get('to')
    
    if from_email and to_email:
        online_users = status_service.get_online_users()
        if to_email in online_users:
            await sio.emit('typing_stopped', {
                'from': from_email
            }, room=to_email)

@sio.event
async def mark_read(sid, data):
    """Mark messages as read"""
    session = await sio.get_session(sid)
    user_email = session.get('email')
    contact_email = data.get('contact')
    
    if user_email and contact_email:
        # Update in database
        chat = db.get_chat(user_email, contact_email)
        updated = False
        
        for msg in chat.get('messages', []):
            if msg['from'] == contact_email and msg['to'] == user_email:
                if msg['status'] != 'seen':
                    msg['status'] = 'seen'
                    msg['read'] = True
                    updated = True
        
        if updated:
            db.save_chat(user_email, contact_email, chat)
        
        # Notify sender
        online_users = status_service.get_online_users()
        if contact_email in online_users:
            await sio.emit('messages_read', {
                'by': user_email
            }, room=contact_email)

@sio.event
async def delete_message(sid, data):
    """Delete a message"""
    session = await sio.get_session(sid)
    user_email = session.get('email')
    
    if not user_email:
        return {'status': 'error', 'message': 'Not authenticated'}
    
    message_id = data.get('message_id')
    chat_id = data.get('chat_id')
    delete_for = data.get('delete_for', 'me')
    
    # Parse chat_id
    users = chat_id.split('_')
    if len(users) != 2:
        return {'status': 'error', 'message': 'Invalid chat ID'}
    
    # Update message
    chat = db.get_chat(users[0], users[1])
    for msg in chat.get('messages', []):
        if msg['id'] == message_id:
            if delete_for == 'everyone' and msg['from'] == user_email:
                msg['deleted'] = True
                msg['message'] = "This message was deleted"
            elif delete_for == 'me':
                if 'deleted_for' not in msg:
                    msg['deleted_for'] = []
                if user_email not in msg['deleted_for']:
                    msg['deleted_for'].append(user_email)
            break
    
    db.save_chat(users[0], users[1], chat)
    
    # Notify other user if online
    other_user = users[1] if users[0] == user_email else users[0]
    online_users = status_service.get_online_users()
    
    if other_user in online_users and delete_for == 'everyone':
        await sio.emit('message_deleted', {
            'message_id': message_id,
            'chat_id': chat_id,
            'deleted_by': user_email
        }, room=other_user)
    
    return {'status': 'ok', 'message': 'Message deleted'}

@sio.event
async def get_online_status(sid, data):
    """Get online status of users"""
    emails = data.get('emails', [])
    result = {}
    
    for email in emails:
        result[email] = status_service.is_online(email)
    
    return result