# Typing Socket Events

def register_typing_handlers(sio):
    @sio.event
    async def typing_start(sid, data):
        """User started typing"""
        session = await sio.get_session(sid)
        from_email = session.get('email')
        to_email = data.get('to')
        
        if from_email and to_email:
            await sio.emit('typing_started', {
                'from': from_email
            }, room=to_email)
    
    @sio.event
    async def typing_stop(sid, data):
        """User stopped typing"""
        session = await sio.get_session(sid)
        from_email = session.get('email')
        to_email = data.get('to')
        
        if from_email and to_email:
            await sio.emit('typing_stopped', {
                'from': from_email
            }, room=to_email)
    
    @sio.event
    async def typing_pulse(sid, data):
        """Typing pulse (sent every few seconds while typing)"""
        session = await sio.get_session(sid)
        from_email = session.get('email')
        to_email = data.get('to')
        
        if from_email and to_email:
            await sio.emit('typing_pulse', {
                'from': from_email
            }, room=to_email)