# Sockets package
from .events import sio
from .chat_events import register_chat_handlers
from .typing_events import register_typing_handlers

def register_all_handlers(sio):
    """Register all socket handlers"""
    register_chat_handlers(sio)
    register_typing_handlers(sio)

__all__ = ['sio', 'register_all_handlers']