# Chat Socket Events
from services.status_service import StatusService
from database import db

def register_chat_handlers(sio):
    @sio.event
    async def send_message(sid, data):
        """Handle sending message via socket"""
        session = await sio.get_session(sid)
        from_email = session.get('email')
        
        if not from_email:
            return
        
        message = data.get('message')
        to_email = data.get('to')
        
        if message and to_email:
            # Emit to recipient
            await sio.emit('new_message', {
                'from': from_email,
                'message': message,
                'timestamp': int(time.time())
            }, room=to_email)
    
    @sio.event
    async def mark_read(sid, data):
        """Mark messages as read"""
        session = await sio.get_session(sid)
        user_email = session.get('email')
        contact_email = data.get('contact')
        
        if user_email and contact_email:
            await sio.emit('messages_read', {
                'by': user_email
            }, room=contact_email)
    
    @sio.event
    async def delete_message(sid, data):
        """Delete message via socket"""
        session = await sio.get_session(sid)
        user_email = session.get('email')
        
        if not user_email:
            return
        
        message_id = data.get('message_id')
        chat_id = data.get('chat_id')
        
        # Broadcast deletion
        await sio.emit('message_deleted', {
            'message_id': message_id,
            'chat_id': chat_id,
            'deleted_by': user_email
        }, room=chat_id)