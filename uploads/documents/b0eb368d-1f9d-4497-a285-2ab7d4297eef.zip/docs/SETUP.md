# Nexus Chat Setup Guide

## 📋 Prerequisites

### System Requirements
- **OS**: Windows 10/11, macOS 10.15+, Linux (Ubuntu 20.04+)
- **RAM**: 2GB minimum, 4GB recommended
- **Storage**: 1GB free space
- **Python**: 3.9 or higher
- **Node**: Not required (pure Python)

### Account Requirements
- **Gmail Account** - For sending OTP emails
- **Domain** - Optional for production

---

## 🚀 Quick Installation

### 1. Clone Repository
```bash
git clone https://github.com/yourusername/nexus-chat.git
cd nexus-chat