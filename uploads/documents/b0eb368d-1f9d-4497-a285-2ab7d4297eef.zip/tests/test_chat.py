import pytest
from fastapi.testclient import TestClient
from backend.app import app

client = TestClient(app)

def test_send_message():
    # First create users
    response = client.post("/auth/verify-otp", json={
        "email": "user1@example.com",
        "code": "123456",  # This would fail in real test
        "username": "User 1"
    })
    
    response = client.post("/chats/send", json={
        "from_email": "user1@example.com",
        "to_email": "user2@example.com",
        "message": "Hello!",
        "type": "text"
    })
    
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_get_chat():
    response = client.post("/chats/get", json={
        "user1": "user1@example.com",
        "user2": "user2@example.com"
    })
    
    assert response.status_code == 200
    assert "messages" in response.json()