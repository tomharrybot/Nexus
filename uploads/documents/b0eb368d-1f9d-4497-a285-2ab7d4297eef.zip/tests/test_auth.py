import pytest
from fastapi.testclient import TestClient
from backend.app import app

client = TestClient(app)

def test_send_otp():
    response = client.post("/auth/send-otp", json={
        "email": "test@example.com"
    })
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_send_otp_invalid_email():
    response = client.post("/auth/send-otp", json={
        "email": "invalid-email"
    })
    assert response.status_code == 422  # Validation error

def test_verify_otp_invalid():
    response = client.post("/auth/verify-otp", json={
        "email": "test@example.com",
        "code": "000000"
    })
    assert response.status_code == 400
    assert response.json()["detail"] == "Invalid OTP"