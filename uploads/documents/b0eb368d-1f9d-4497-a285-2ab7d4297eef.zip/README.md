# Nexus Chat - Cosmic Neo Edition 🚀

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://github.com/nexus/chat)
[![Python](https://img.shields.io/badge/python-3.9+-green.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-purple.svg)](https://fastapi.tiangolo.com)

Nexus Chat is a next-generation messaging platform with cosmic neon aesthetics, end-to-end encryption, and a modular architecture. Every feature has its own file, making it incredibly easy to maintain and extend.

## ✨ Features

- **Authentication** - OTP-based email verification
- **Real-time Chat** - Instant messaging with socket.io
- **Media Sharing** - Images, videos, audio, documents
- **Voice Messages** - Record and send voice notes
- **Message Features** - Reply, forward, copy, delete
- **Groups** - Create and manage group chats
- **Privacy Controls** - Last seen, profile photo visibility
- **Security** - 2FA, session management, encryption
- **Support System** - Ticket-based help desk
- **Cosmic Theme** - Stunning neon gradients and animations
- **Special UserID** - Each user gets a unique NX-XXXX-XXXX format ID

## 📋 Prerequisites

- Python 3.9 or higher
- pip (Python package manager)
- A Gmail account for OTP emails

## 🚀 Quick Start

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/nexus-chat.git
   cd nexus-chat