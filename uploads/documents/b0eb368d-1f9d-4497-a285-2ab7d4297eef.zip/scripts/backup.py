#!/usr/bin/env python3
"""
Backup Script for Nexus Chat
Creates timestamped backups of data and uploads
"""

import os
import shutil
import datetime
import json
import sys

def create_backup():
    """Create a backup of all data"""
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = f"backups/nexus_backup_{timestamp}"
    
    print(f"📦 Creating backup: {backup_dir}")
    
    # Create backup directory
    os.makedirs(backup_dir, exist_ok=True)
    
    # Backup data directory
    if os.path.exists("data"):
        shutil.copytree("data", f"{backup_dir}/data")
        print("✅ Data backed up")
    
    # Backup uploads directory
    if os.path.exists("uploads"):
        shutil.copytree("uploads", f"{backup_dir}/uploads")
        print("✅ Uploads backed up")
    
    # Backup .env file
    if os.path.exists(".env"):
        shutil.copy(".env", f"{backup_dir}/.env")
        print("✅ Environment backed up")
    
    # Create manifest
    manifest = {
        "created_at": timestamp,
        "version": "1.0.0",
        "files": os.listdir(backup_dir)
    }
    
    with open(f"{backup_dir}/manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)
    
    # Create archive
    shutil.make_archive(backup_dir, 'zip', backup_dir)
    shutil.rmtree(backup_dir)
    
    print(f"✅ Backup complete: {backup_dir}.zip")
    
    # Keep only last 10 backups
    cleanup_old_backups()
    
    return f"{backup_dir}.zip"

def cleanup_old_backups(keep=10):
    """Keep only the last 'keep' backups"""
    backup_dir = "backups"
    if not os.path.exists(backup_dir):
        return
    
    backups = sorted([f for f in os.listdir(backup_dir) if f.endswith('.zip')])
    
    if len(backups) > keep:
        for old_backup in backups[:-keep]:
            os.remove(f"{backup_dir}/{old_backup}")
            print(f"🗑️ Removed old backup: {old_backup}")

def restore_backup(backup_file):
    """Restore from a backup file"""
    import zipfile
    
    if not os.path.exists(backup_file):
        print(f"❌ Backup file not found: {backup_file}")
        return False
    
    print(f"📦 Restoring from: {backup_file}")
    
    # Extract backup
    extract_dir = backup_file.replace('.zip', '')
    with zipfile.ZipFile(backup_file, 'r') as zip_ref:
        zip_ref.extractall(extract_dir)
    
    # Restore data
    if os.path.exists(f"{extract_dir}/data"):
        if os.path.exists("data"):
            shutil.rmtree("data")
        shutil.copytree(f"{extract_dir}/data", "data")
        print("✅ Data restored")
    
    # Restore uploads
    if os.path.exists(f"{extract_dir}/uploads"):
        if os.path.exists("uploads"):
            shutil.rmtree("uploads")
        shutil.copytree(f"{extract_dir}/uploads", "uploads")
        print("✅ Uploads restored")
    
    # Restore .env
    if os.path.exists(f"{extract_dir}/.env"):
        shutil.copy(f"{extract_dir}/.env", ".env")
        print("✅ Environment restored")
    
    # Cleanup
    shutil.rmtree(extract_dir)
    
    print("✅ Restore complete")
    return True

if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "restore" and len(sys.argv) > 2:
            restore_backup(sys.argv[2])
        else:
            print("Usage:")
            print("  python scripts/backup.py           # Create backup")
            print("  python scripts/backup.py restore <file>  # Restore backup")
    else:
        create_backup()