#!/usr/bin/env python3
"""
Migration Script for Nexus Chat
Handles database schema migrations
"""

import os
import json
import shutil
from datetime import datetime

def backup_current_state():
    """Create backup before migration"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = f"backups/pre_migration_{timestamp}"
    
    os.makedirs(backup_dir, exist_ok=True)
    
    if os.path.exists("data"):
        shutil.copytree("data", f"{backup_dir}/data")
    
    print(f"✅ Backup created: {backup_dir}")
    return backup_dir

def migrate_users_v1_to_v2():
    """Migrate users from v1 to v2 schema"""
    print("📦 Migrating users schema...")
    
    if not os.path.exists("data/users.json"):
        print("❌ users.json not found")
        return False
    
    with open("data/users.json", 'r') as f:
        users = json.load(f)
    
    migrated = 0
    for user in users:
        # Add missing fields
        if 'id' not in user:
            # Generate UserID
            import hashlib
            hash_obj = hashlib.sha256(user['email'].encode())
            hash_hex = hash_obj.hexdigest()
            user['id'] = f"NX-{hash_hex[:4].upper()}-{hash_hex[4:8].upper()}-{hash_hex[8:12].upper()}"
            migrated += 1
        
        if 'profile' not in user:
            user['profile'] = {
                'name': user.get('username', ''),
                'about': "Hey there! I'm using Nexus Chat",
                'avatar': "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23ffffff'%3E%3Cpath d='M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-6.627 0-12 5.373-12 12h24c0-6.627-5.373-12-12-12z'/%3E%3C/svg%3E",
                'lastSeen': user.get('created_at', 0)
            }
        
        if 'settings' not in user:
            user['settings'] = {
                'theme': 'cosmic',
                'notifications': True,
                'sound': True,
                'vibration': True,
                'privacy': {
                    'last_seen': 'everyone',
                    'profile_photo': 'everyone',
                    'about': 'everyone',
                    'groups': 'everyone',
                    'read_receipts': True,
                    'typing_indicator': True
                },
                'security': {
                    'two_factor_auth': False,
                    'login_alerts': True,
                    'active_sessions': [],
                    'device_management': True,
                    'encryption': 'end-to-end'
                }
            }
        
        if 'stats' not in user:
            user['stats'] = {
                'total_messages': 0,
                'total_contacts': 0,
                'total_groups': 0
            }
    
    with open("data/users.json", 'w') as f:
        json.dump(users, f, indent=2)
    
    print(f"✅ Migrated {migrated} users")
    return True

def migrate_messages_v1_to_v2():
    """Migrate messages to include new fields"""
    print("📦 Migrating messages schema...")
    
    chats_dir = "data/chats"
    if not os.path.exists(chats_dir):
        print("❌ chats directory not found")
        return False
    
    migrated = 0
    for chat_file in os.listdir(chats_dir):
        if chat_file.endswith('.json'):
            with open(f"{chats_dir}/{chat_file}", 'r') as f:
                chat = json.load(f)
            
            updated = False
            for msg in chat.get('messages', []):
                if 'id' not in msg:
                    import time
                    msg['id'] = str(int(time.time() * 1000)) + str(hash(msg['message']))[:4]
                    updated = True
                
                if 'status' not in msg:
                    msg['status'] = 'sent'
                    updated = True
                
                if 'read' not in msg:
                    msg['read'] = False
                    updated = True
                
                if 'delivered' not in msg:
                    msg['delivered'] = False
                    updated = True
            
            if updated:
                with open(f"{chats_dir}/{chat_file}", 'w') as f:
                    json.dump(chat, f, indent=2)
                migrated += 1
    
    print(f"✅ Migrated {migrated} chat files")
    return True

def migrate_contacts_v1_to_v2():
    """Migrate contacts to include new fields"""
    print("📦 Migrating contacts schema...")
    
    contacts_dir = "data/contacts"
    if not os.path.exists(contacts_dir):
        print("❌ contacts directory not found")
        return False
    
    migrated = 0
    for contact_file in os.listdir(contacts_dir):
        if contact_file.endswith('.json'):
            with open(f"{contacts_dir}/{contact_file}", 'r') as f:
                contacts = json.load(f)
            
            updated = False
            for contact in contacts:
                if 'last_message' not in contact:
                    contact['last_message'] = ''
                    updated = True
                
                if 'last_time' not in contact:
                    contact['last_time'] = 0
                    updated = True
                
                if 'unread_count' not in contact:
                    contact['unread_count'] = 0
                    updated = True
            
            if updated:
                with open(f"{contacts_dir}/{contact_file}", 'w') as f:
                    json.dump(contacts, f, indent=2)
                migrated += 1
    
    print(f"✅ Migrated {migrated} contact files")
    return True

def main():
    print("🚀 Nexus Chat Migration Utility")
    print("=" * 40)
    print("This script will migrate your data to the latest schema.")
    print("A backup will be created before migration.\n")
    
    response = input("Continue? (y/N): ")
    if response.lower() != 'y':
        print("Migration cancelled.")
        return
    
    # Create backup
    backup_dir = backup_current_state()
    print()
    
    # Run migrations
    success = True
    success &= migrate_users_v1_to_v2()
    print()
    success &= migrate_messages_v1_to_v2()
    print()
    success &= migrate_contacts_v1_to_v2()
    print()
    
    if success:
        print("✅ Migration completed successfully!")
        print(f"✅ Backup saved at: {backup_dir}")
    else:
        print("❌ Migration failed! Check the errors above.")
        print(f"💾 Restore from backup: {backup_dir}")

if __name__ == "__main__":
    main()