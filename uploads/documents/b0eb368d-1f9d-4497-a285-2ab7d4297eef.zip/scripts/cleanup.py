#!/usr/bin/env python3
"""
Cleanup Script for Nexus Chat
Removes orphaned files and old data
"""

import os
import json
import shutil
from datetime import datetime, timedelta

def cleanup_orphaned_files():
    """Remove orphaned files (uploads without corresponding messages)"""
    print("🧹 Cleaning up orphaned files...")
    
    # Get all message file references
    used_files = set()
    chats_dir = "data/chats"
    
    if os.path.exists(chats_dir):
        for chat_file in os.listdir(chats_dir):
            if chat_file.endswith('.json'):
                with open(f"{chats_dir}/{chat_file}", 'r') as f:
                    try:
                        chat = json.load(f)
                        for msg in chat.get('messages', []):
                            if msg.get('type') in ['image', 'video', 'audio', 'file']:
                                url = msg.get('file', {}).get('url') or msg.get('message')
                                if url and url.startswith('/uploads/'):
                                    used_files.add(url.replace('/uploads/', ''))
                    except:
                        continue
    
    # Check uploads directory
    uploads_dir = "uploads"
    removed = 0
    kept = 0
    
    if os.path.exists(uploads_dir):
        for root, dirs, files in os.walk(uploads_dir):
            for file in files:
                file_path = os.path.join(root, file)
                rel_path = os.path.relpath(file_path, uploads_dir)
                
                if rel_path not in used_files:
                    os.remove(file_path)
                    removed += 1
                else:
                    kept += 1
    
    print(f"✅ Removed: {removed} orphaned files")
    print(f"✅ Kept: {kept} used files")

def cleanup_old_logs(days=7):
    """Remove log files older than specified days"""
    print(f"🧹 Cleaning up logs older than {days} days...")
    
    cutoff = datetime.now() - timedelta(days=days)
    removed = 0
    
    if os.path.exists("logs"):
        for log_file in os.listdir("logs"):
            if log_file.endswith('.log'):
                file_path = f"logs/{log_file}"
                mtime = datetime.fromtimestamp(os.path.getmtime(file_path))
                
                if mtime < cutoff:
                    os.remove(file_path)
                    removed += 1
    
    print(f"✅ Removed {removed} old log files")

def cleanup_temp_files():
    """Remove temporary files"""
    print("🧹 Cleaning up temp files...")
    
    patterns = ['*.tmp', '*.temp', '*.bak', '*.swp']
    removed = 0
    
    for root, dirs, files in os.walk('.'):
        for file in files:
            if any(file.endswith(p.replace('*', '')) for p in patterns):
                file_path = os.path.join(root, file)
                os.remove(file_path)
                removed += 1
    
    print(f"✅ Removed {removed} temporary files")

def cleanup_empty_dirs():
    """Remove empty directories"""
    print("🧹 Cleaning up empty directories...")
    
    removed = 0
    
    for root, dirs, files in os.walk('.', topdown=False):
        if not dirs and not files and root != '.':
            os.rmdir(root)
            removed += 1
    
    print(f"✅ Removed {removed} empty directories")

def main():
    print("🚀 Nexus Chat Cleanup Utility")
    print("=" * 40)
    
    cleanup_orphaned_files()
    print()
    cleanup_old_logs()
    print()
    cleanup_temp_files()
    print()
    cleanup_empty_dirs()
    print()
    print("✅ Cleanup complete!")

if __name__ == "__main__":
    main()