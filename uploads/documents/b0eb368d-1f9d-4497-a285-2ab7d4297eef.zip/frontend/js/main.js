// Main Entry Point
document.addEventListener('DOMContentLoaded', () => {
    console.log('Nexus Chat - Cosmic Neo Edition v1.0.0');
    
    // Initialize all modules
    initModules();
    
    // Show splash screen
    showSplashScreen();
});

function initModules() {
    // Check if user is logged in
    const user = Storage.getUser();
    
    if (user) {
        // Show main screen
        document.getElementById('auth-screen').classList.remove('active');
        document.getElementById('main-screen').classList.add('active');
        
        // Initialize chat
        if (window.ChatScreen) {
            ChatScreen.init();
        }
    } else {
        // Show auth screen
        document.getElementById('auth-screen').classList.add('active');
        document.getElementById('main-screen').classList.remove('active');
        
        // Initialize auth
        if (window.AuthScreen) {
            AuthScreen.init();
        }
    }
    
    // Initialize groups
    if (window.GroupsScreen) {
        GroupsScreen.init();
    }
    
    // Initialize settings
    if (window.SettingsScreen) {
        SettingsScreen.init();
    }
    
    // Initialize features
    initFeatures();
    
    // Setup global event listeners
    setupGlobalListeners();
}

function initFeatures() {
    // Initialize all feature modules
    const features = [
        'ReplyFeature',
        'ForwardFeature',
        'CopyFeature',
        'DeleteFeature',
        'VoiceFeature',
        'PrivacyFeature',
        'SecurityFeature',
        'SupportFeature',
        'ProfileFeature',
        'MediaFeature',
        'UserIDFeature'
    ];
    
    features.forEach(feature => {
        if (window[feature] && window[feature].init) {
            try {
                window[feature].init();
            } catch (error) {
                console.error(`Error initializing ${feature}:`, error);
            }
        }
    });
}

function setupGlobalListeners() {
    // Close modals on escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal.active').forEach(modal => {
                modal.classList.remove('active');
            });
        }
    });
    
    // Handle window resize
    window.addEventListener('resize', handleResize);
    
    // Handle visibility change (online/offline)
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Handle before unload
    window.addEventListener('beforeunload', handleBeforeUnload);
}

function handleResize() {
    const width = window.innerWidth;
    const sidebar = document.getElementById('sidebar');
    const chatArea = document.getElementById('chat-area');
    const emptyChat = document.getElementById('empty-chat');
    
    if (width > 768) {
        sidebar?.classList.remove('hidden');
        if (window.ChatScreen?.currentChat) {
            chatArea.style.display = 'flex';
            if (emptyChat) emptyChat.style.display = 'none';
        } else {
            if (emptyChat) emptyChat.style.display = 'flex';
        }
    } else {
        if (window.ChatScreen?.currentChat) {
            chatArea.style.display = 'flex';
            if (emptyChat) emptyChat.style.display = 'none';
        }
    }
}

function handleVisibilityChange() {
    const user = Storage.getUser();
    if (!user) return;
    
    const online = !document.hidden;
    
    API.post('/users/status', {
        email: user.email,
        online
    }).catch(console.error);
}

function handleBeforeUnload() {
    const user = Storage.getUser();
    if (!user) return;
    
    navigator.sendBeacon('/users/status', JSON.stringify({
        email: user.email,
        online: false
    }));
}

function showSplashScreen() {
    const splash = document.getElementById('splash-screen');
    if (!splash) return;
    
    splash.classList.add('active');
    
    setTimeout(() => {
        splash.classList.remove('active');
    }, 2000);
}

// Global helper functions
window.openModal = (modalId) => {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add('active');
};

window.closeModal = (modalId) => {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('active');
};

window.showToast = (message, type = 'info') => {
    Toast.show(message, type);
};

window.copyToClipboard = async (text) => {
    try {
        await navigator.clipboard.writeText(text);
        Toast.success('Copied to clipboard');
        return true;
    } catch (err) {
        console.error('Failed to copy:', err);
        Toast.error('Failed to copy');
        return false;
    }
};

// Error handling
window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    Toast.error('An error occurred');
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    Toast.error('An error occurred');
});