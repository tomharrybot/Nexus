// Formatters Utility
const Formatters = {
    // Time formatting
    time(timestamp) {
        if (!timestamp) return '';
        
        const date = new Date(timestamp * 1000);
        const now = new Date();
        const diff = now - date;
        
        // Today
        if (date.toDateString() === now.toDateString()) {
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }
        
        // Yesterday
        const yesterday = new Date(now);
        yesterday.setDate(yesterday.getDate() - 1);
        if (date.toDateString() === yesterday.toDateString()) {
            return 'Yesterday';
        }
        
        // Within a week
        if (diff < 7 * 24 * 60 * 60 * 1000) {
            return date.toLocaleDateString([], { weekday: 'short' });
        }
        
        // Older
        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    },
    
    // Full date time
    dateTime(timestamp) {
        if (!timestamp) return '';
        const date = new Date(timestamp * 1000);
        return date.toLocaleString();
    },
    
    // Last seen formatter
    lastSeen(timestamp) {
        if (!timestamp) return 'Offline';
        
        const date = new Date(timestamp * 1000);
        const now = new Date();
        const diff = Math.floor((now - date) / 1000); // seconds
        
        if (diff < 60) return 'Online';
        if (diff < 3600) {
            const mins = Math.floor(diff / 60);
            return `Last seen ${mins} minute${mins > 1 ? 's' : ''} ago`;
        }
        if (diff < 86400) {
            const hours = Math.floor(diff / 3600);
            return `Last seen ${hours} hour${hours > 1 ? 's' : ''} ago`;
        }
        if (diff < 604800) {
            const days = Math.floor(diff / 86400);
            return `Last seen ${days} day${days > 1 ? 's' : ''} ago`;
        }
        
        return `Last seen ${date.toLocaleDateString()}`;
    },
    
    // File size formatter
    fileSize(bytes) {
        if (bytes === 0) return '0 B';
        if (!bytes) return '';
        
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        
        return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + units[i];
    },
    
    // Message preview
    messagePreview(message, type = 'text', maxLength = 50) {
        if (type !== 'text') {
            const icons = {
                image: '📷 Photo',
                video: '🎥 Video',
                audio: '🎵 Voice',
                file: '📄 File'
            };
            return icons[type] || '📎 Attachment';
        }
        
        if (message.length <= maxLength) return message;
        return message.substring(0, maxLength) + '...';
    },
    
    // Count formatter (for unread badges)
    count(num) {
        if (num < 1000) return num.toString();
        if (num < 1000000) return (num / 1000).toFixed(1) + 'k';
        return (num / 1000000).toFixed(1) + 'M';
    },
    
    // Duration formatter (for voice messages)
    duration(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }
};

// Make available globally
window.Formatters = Formatters;