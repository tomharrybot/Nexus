// Storage Utility - LocalStorage management
const Storage = {
    // User related
    getUser() {
        try {
            const user = localStorage.getItem('currentUser');
            return user ? JSON.parse(user) : null;
        } catch (e) {
            console.error('Error parsing user from storage:', e);
            return null;
        }
    },
    
    setUser(user) {
        try {
            localStorage.setItem('currentUser', JSON.stringify(user));
        } catch (e) {
            console.error('Error saving user to storage:', e);
        }
    },
    
    updateUser(updates) {
        const user = this.getUser();
        if (user) {
            const updated = { ...user, ...updates };
            this.setUser(updated);
            return updated;
        }
        return null;
    },
    
    // Theme
    getTheme() {
        return localStorage.getItem('theme') || 'cosmic';
    },
    
    setTheme(theme) {
        localStorage.setItem('theme', theme);
        document.body.className = theme + '-theme';
    },
    
    // Settings
    getSettings() {
        try {
            const settings = localStorage.getItem('userSettings');
            return settings ? JSON.parse(settings) : {
                notifications: true,
                sound: true,
                vibration: true
            };
        } catch (e) {
            return {
                notifications: true,
                sound: true,
                vibration: true
            };
        }
    },
    
    setSettings(settings) {
        localStorage.setItem('userSettings', JSON.stringify(settings));
    },
    
    // Chats cache
    getChat(chatId) {
        try {
            const chat = localStorage.getItem(`chat_${chatId}`);
            return chat ? JSON.parse(chat) : null;
        } catch (e) {
            return null;
        }
    },
    
    setChat(chatId, chatData) {
        try {
            localStorage.setItem(`chat_${chatId}`, JSON.stringify(chatData));
        } catch (e) {
            console.error('Error saving chat to storage:', e);
        }
    },
    
    // Clear all
    clear() {
        localStorage.clear();
    },
    
    // Clear chat cache only
    clearChats() {
        Object.keys(localStorage).forEach(key => {
            if (key.startsWith('chat_')) {
                localStorage.removeItem(key);
            }
        });
    }
};

// Make available globally
window.Storage = Storage;