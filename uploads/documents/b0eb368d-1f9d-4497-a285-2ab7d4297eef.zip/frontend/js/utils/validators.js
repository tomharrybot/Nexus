// Input Validators
const Validators = {
    // Email validation
    email(email) {
        if (!email || typeof email !== 'string') return false;
        const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return regex.test(email);
    },
    
    // OTP validation (6 digits)
    otp(otp) {
        if (!otp || typeof otp !== 'string') return false;
        return /^\d{6}$/.test(otp);
    },
    
    // Username validation
    username(username) {
        if (!username || typeof username !== 'string') return false;
        if (username.length < 2 || username.length > 50) return false;
        // Allow letters, numbers, spaces, dots, underscores, hyphens
        return /^[a-zA-Z0-9\s._-]+$/.test(username);
    },
    
    // Password validation
    password(password) {
        if (!password || typeof password !== 'string') {
            return { valid: false, message: 'Password required' };
        }
        
        if (password.length < 6) {
            return { valid: false, message: 'Password must be at least 6 characters' };
        }
        
        if (password.length > 100) {
            return { valid: false, message: 'Password too long' };
        }
        
        if (!/\d/.test(password)) {
            return { valid: false, message: 'Password must contain at least one number' };
        }
        
        if (!/[a-zA-Z]/.test(password)) {
            return { valid: false, message: 'Password must contain at least one letter' };
        }
        
        return { valid: true, message: 'Password is valid' };
    },
    
    // Message validation
    message(message) {
        if (!message || typeof message !== 'string') return false;
        return message.length <= 5000;
    },
    
    // File validation
    file(file, type = 'document') {
        if (!file) {
            return { valid: false, message: 'No file selected' };
        }
        
        // Check file size
        const limits = {
            image: 10 * 1024 * 1024,
            video: 50 * 1024 * 1024,
            audio: 20 * 1024 * 1024,
            document: 25 * 1024 * 1024
        };
        
        const maxSize = limits[type] || 25 * 1024 * 1024;
        if (file.size > maxSize) {
            const sizeMB = Math.floor(maxSize / (1024 * 1024));
            return { 
                valid: false, 
                message: `File too large. Maximum size: ${sizeMB}MB` 
            };
        }
        
        // Check file type
        const allowedTypes = {
            image: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
            video: ['video/mp4', 'video/webm', 'video/ogg'],
            audio: ['audio/mpeg', 'audio/wav', 'audio/ogg'],
            document: [
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'text/plain'
            ]
        };
        
        const allowed = allowedTypes[type] || allowedTypes.document;
        if (!allowed.includes(file.type)) {
            return { 
                valid: false, 
                message: `Invalid file type. Allowed: ${allowed.join(', ')}` 
            };
        }
        
        return { valid: true, message: 'File is valid' };
    },
    
    // Group name validation
    groupName(name) {
        if (!name || typeof name !== 'string') return false;
        return name.length >= 3 && name.length <= 50;
    },
    
    // Search query validation
    searchQuery(query) {
        if (!query || typeof query !== 'string') return false;
        return query.length <= 100;
    },
    
    // URL validation
    url(url) {
        if (!url || typeof url !== 'string') return false;
        try {
            new URL(url);
            return true;
        } catch {
            return false;
        }
    },
    
    // Phone number validation (basic)
    phone(phone) {
        if (!phone || typeof phone !== 'string') return false;
        // Remove common separators
        const cleaned = phone.replace(/[\s\-\(\)]/g, '');
        return /^\+?[\d]{10,15}$/.test(cleaned);
    },
    
    // UserID validation (NX-XXXX-XXXX-XXXX)
    userId(userId) {
        if (!userId || typeof userId !== 'string') return false;
        return /^NX-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(userId);
    },
    
    // Sanitize input (remove harmful characters)
    sanitize(input) {
        if (!input || typeof input !== 'string') return '';
        
        // Remove HTML tags
        let sanitized = input.replace(/<[^>]*>/g, '');
        
        // Remove script tags
        sanitized = sanitized.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
        
        // Escape special characters
        const escapeMap = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;',
            '/': '&#x2F;',
            '`': '&#x60;',
            '=': '&#x3D;'
        };
        
        sanitized = sanitized.replace(/[&<>"'`=/]/g, char => escapeMap[char]);
        
        return sanitized.trim();
    },
    
    // Validate all form fields
    validateForm(fields) {
        const errors = {};
        
        for (const [field, value] of Object.entries(fields)) {
            switch (field) {
                case 'email':
                    if (!this.email(value)) {
                        errors[field] = 'Invalid email address';
                    }
                    break;
                    
                case 'otp':
                    if (!this.otp(value)) {
                        errors[field] = 'OTP must be 6 digits';
                    }
                    break;
                    
                case 'username':
                case 'name':
                    if (!this.username(value)) {
                        errors[field] = 'Invalid username (2-50 characters, letters, numbers, spaces, ._-)';
                    }
                    break;
                    
                case 'password':
                    const result = this.password(value);
                    if (!result.valid) {
                        errors[field] = result.message;
                    }
                    break;
                    
                case 'groupName':
                    if (!this.groupName(value)) {
                        errors[field] = 'Group name must be 3-50 characters';
                    }
                    break;
            }
        }
        
        return {
            valid: Object.keys(errors).length === 0,
            errors
        };
    }
};

// Make globally available
window.Validators = Validators;