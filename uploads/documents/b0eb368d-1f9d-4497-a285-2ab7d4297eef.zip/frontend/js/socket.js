// Socket.IO Connection Manager
const SocketManager = (function() {
    let socket = null;
    let connected = false;
    let reconnectAttempts = 0;
    const maxReconnectAttempts = 5;
    
    // Event callbacks
    const eventHandlers = {
        'connect': [],
        'disconnect': [],
        'new-message': [],
        'message-status': [],
        'typing-started': [],
        'typing-stopped': [],
        'user-online': [],
        'user-offline': [],
        'messages-read': [],
        'message-deleted': [],
        'contact-added': [],
        'group-created': [],
        'new-group-message': [],
        'profile-updated': []
    };
    
    function init() {
        if (socket) return;
        
        socket = io(CONFIG.SOCKET_URL, {
            reconnection: true,
            reconnectionAttempts: maxReconnectAttempts,
            reconnectionDelay: 1000,
            reconnectionDelayMax: 5000,
            timeout: 20000
        });
        
        setupEventListeners();
    }
    
    function setupEventListeners() {
        socket.on('connect', () => {
            console.log('Socket connected');
            connected = true;
            reconnectAttempts = 0;
            triggerEvent('connect');
        });
        
        socket.on('disconnect', (reason) => {
            console.log('Socket disconnected:', reason);
            connected = false;
            triggerEvent('disconnect', { reason });
            
            if (reason === 'io server disconnect') {
                // Reconnect manually
                socket.connect();
            }
        });
        
        socket.on('connect_error', (error) => {
            console.error('Socket connection error:', error);
            reconnectAttempts++;
            
            if (reconnectAttempts >= maxReconnectAttempts) {
                console.error('Max reconnection attempts reached');
                Toast.error('Connection lost. Please refresh the page.');
            }
        });
        
        socket.on('new-message', (data) => {
            triggerEvent('new-message', data);
        });
        
        socket.on('message-status', (data) => {
            triggerEvent('message-status', data);
        });
        
        socket.on('typing-started', (data) => {
            triggerEvent('typing-started', data);
        });
        
        socket.on('typing-stopped', (data) => {
            triggerEvent('typing-stopped', data);
        });
        
        socket.on('user-online', (data) => {
            triggerEvent('user-online', data);
        });
        
        socket.on('user-offline', (data) => {
            triggerEvent('user-offline', data);
        });
        
        socket.on('messages-read', (data) => {
            triggerEvent('messages-read', data);
        });
        
        socket.on('message-deleted', (data) => {
            triggerEvent('message-deleted', data);
        });
        
        socket.on('contact-added', (data) => {
            triggerEvent('contact-added', data);
        });
        
        socket.on('group-created', (data) => {
            triggerEvent('group-created', data);
        });
        
        socket.on('new-group-message', (data) => {
            triggerEvent('new-group-message', data);
        });
        
        socket.on('profile-updated', (data) => {
            triggerEvent('profile-updated', data);
        });
    }
    
    // Event handling
    function on(event, callback) {
        if (eventHandlers[event]) {
            eventHandlers[event].push(callback);
        }
    }
    
    function off(event, callback) {
        if (eventHandlers[event]) {
            eventHandlers[event] = eventHandlers[event].filter(cb => cb !== callback);
        }
    }
    
    function triggerEvent(event, data) {
        if (eventHandlers[event]) {
            eventHandlers[event].forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error(`Error in ${event} handler:`, error);
                }
            });
        }
    }
    
    // Emit events
    function emit(event, data) {
        if (!socket || !connected) {
            console.warn('Socket not connected, cannot emit:', event);
            return false;
        }
        
        socket.emit(event, data);
        return true;
    }
    
    // User actions
    function login(email) {
        emit('user-login', { email });
    }
    
    function sendMessage(to, message, type = 'text', replyTo = null) {
        emit('send-message', { to, message, type, replyTo });
    }
    
    function sendGroupMessage(groupId, message, type = 'text') {
        emit('send-group-message', { groupId, message, type });
    }
    
    function startTyping(to) {
        emit('typing-start', { to });
    }
    
    function stopTyping(to) {
        emit('typing-stop', { to });
    }
    
    function markAsRead(contact) {
        emit('mark-read', { contact });
    }
    
    function deleteMessage(messageId, chatId, deleteFor = 'me') {
        emit('delete-message', { messageId, chatId, deleteFor });
    }
    
    // Status
    function isConnected() {
        return connected;
    }
    
    function getSocket() {
        return socket;
    }
    
    // Reconnect
    function reconnect() {
        if (socket) {
            socket.connect();
        }
    }
    
    // Disconnect
    function disconnect() {
        if (socket) {
            socket.disconnect();
        }
    }
    
    // Public API
    return {
        init,
        on,
        off,
        emit,
        login,
        sendMessage,
        sendGroupMessage,
        startTyping,
        stopTyping,
        markAsRead,
        deleteMessage,
        isConnected,
        getSocket,
        reconnect,
        disconnect
    };
})();

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    SocketManager.init();
});

// Make globally available
window.SocketManager = SocketManager;