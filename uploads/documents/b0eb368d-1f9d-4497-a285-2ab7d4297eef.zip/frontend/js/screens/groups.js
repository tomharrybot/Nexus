// Groups Screen
const GroupsScreen = {
    groups: [],
    
    init() {
        this.loadGroups();
        this.setupEventListeners();
    },
    
    async loadGroups() {
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const groups = await API.get(`/groups/user/${user.email}`);
            this.groups = groups;
            this.renderGroups();
        } catch (error) {
            console.error('Error loading groups:', error);
            Toast.error('Failed to load groups');
        }
    },
    
    renderGroups() {
        const container = document.getElementById('groups-list');
        if (!container) return;
        
        if (this.groups.length === 0) {
            container.innerHTML = `
                <div class="no-groups">
                    <i class="fas fa-users"></i>
                    <p>No groups yet</p>
                    <button class="nexus-btn nexus-btn-primary" onclick="GroupsScreen.openCreateGroupModal()">
                        Create Group
                    </button>
                </div>
            `;
            return;
        }
        
        container.innerHTML = this.groups.map(group => `
            <div class="chat-item" data-group-id="${group.id}" onclick="GroupsScreen.openGroup('${group.id}')">
                <img src="${group.avatar || '/images/group-avatar.png'}" class="chat-avatar">
                <div class="chat-info">
                    <div class="chat-name">${group.name}</div>
                    <div class="chat-last-msg">${group.last_message || 'No messages yet'}</div>
                </div>
                <div class="chat-meta">
                    <div class="chat-time">${Formatters.time(group.last_message_time)}</div>
                    <div class="chat-members">${group.members?.length || 0} members</div>
                </div>
            </div>
        `).join('');
    },
    
    openGroup(groupId) {
        const group = this.groups.find(g => g.id === groupId);
        if (group) {
            window.currentChat = {
                ...group,
                isGroup: true
            };
            document.dispatchEvent(new CustomEvent('group-opened', { detail: group }));
        }
    },
    
    openCreateGroupModal() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'create-group-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Create New Group</h2>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="group-avatar-upload">
                        <img id="group-avatar-preview" src="/images/group-avatar.png" class="avatar-preview">
                        <input type="file" id="group-avatar-upload" accept="image/*" style="display: none;">
                        <button class="nexus-btn nexus-btn-secondary" onclick="document.getElementById('group-avatar-upload').click()">
                            Change Photo
                        </button>
                    </div>
                    
                    <div class="group-form">
                        <label>Group Name</label>
                        <input type="text" id="group-name" class="nexus-input" placeholder="Enter group name">
                        
                        <label>Select Members</label>
                        <div class="members-search">
                            <input type="text" id="group-members-search" class="nexus-input" placeholder="Search contacts...">
                        </div>
                        
                        <div class="members-list" id="members-list"></div>
                        <div class="selected-members" id="selected-members"></div>
                    </div>
                    
                    <button class="nexus-btn nexus-btn-primary" onclick="GroupsScreen.createGroup()" id="create-group-btn" disabled>
                        Create Group
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        setTimeout(() => modal.classList.add('active'), 10);
        
        this.loadContactsForGroup();
        this.setupGroupModalEvents();
    },
    
    async loadContactsForGroup() {
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const contacts = await API.get(`/contacts/${user.email}`);
            this.renderMembersList(contacts);
        } catch (error) {
            console.error('Error loading contacts:', error);
        }
    },
    
    renderMembersList(contacts) {
        const container = document.getElementById('members-list');
        if (!container) return;
        
        if (contacts.length === 0) {
            container.innerHTML = '<div class="no-contacts">No contacts found</div>';
            return;
        }
        
        container.innerHTML = contacts.map(contact => `
            <div class="member-item" data-email="${contact.email}">
                <img src="${contact.avatar || '/images/default-avatar.png'}" class="member-avatar">
                <span class="member-name">${contact.name}</span>
                <input type="checkbox" class="member-checkbox">
            </div>
        `).join('');
        
        // Add checkbox listeners
        container.querySelectorAll('.member-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                const memberItem = e.target.closest('.member-item');
                const email = memberItem.dataset.email;
                const name = memberItem.querySelector('.member-name').textContent;
                const avatar = memberItem.querySelector('.member-avatar').src;
                
                if (e.target.checked) {
                    this.addSelectedMember({ email, name, avatar });
                } else {
                    this.removeSelectedMember(email);
                }
            });
        });
    },
    
    addSelectedMember(member) {
        const container = document.getElementById('selected-members');
        if (!container) return;
        
        const existing = container.querySelector(`[data-email="${member.email}"]`);
        if (existing) return;
        
        const el = document.createElement('div');
        el.className = 'selected-member';
        el.dataset.email = member.email;
        el.innerHTML = `
            <img src="${member.avatar}" class="selected-member-avatar">
            <span>${member.name}</span>
            <button class="remove-member" onclick="GroupsScreen.removeSelectedMember('${member.email}')">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        container.appendChild(el);
        this.updateCreateGroupButton();
    },
    
    removeSelectedMember(email) {
        const container = document.getElementById('selected-members');
        const member = container?.querySelector(`[data-email="${email}"]`);
        if (member) member.remove();
        
        // Uncheck checkbox
        const checkbox = document.querySelector(`.member-item[data-email="${email}"] .member-checkbox`);
        if (checkbox) checkbox.checked = false;
        
        this.updateCreateGroupButton();
    },
    
    updateCreateGroupButton() {
        const btn = document.getElementById('create-group-btn');
        const name = document.getElementById('group-name')?.value;
        const selectedCount = document.getElementById('selected-members')?.children.length || 0;
        
        if (btn) {
            btn.disabled = !name || selectedCount === 0;
        }
    },
    
    setupGroupModalEvents() {
        const nameInput = document.getElementById('group-name');
        if (nameInput) {
            nameInput.addEventListener('input', () => this.updateCreateGroupButton());
        }
        
        const searchInput = document.getElementById('group-members-search');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                const query = e.target.value.toLowerCase();
                document.querySelectorAll('.member-item').forEach(item => {
                    const name = item.querySelector('.member-name').textContent.toLowerCase();
                    const email = item.dataset.email.toLowerCase();
                    item.style.display = name.includes(query) || email.includes(query) ? 'flex' : 'none';
                });
            });
        }
        
        const avatarUpload = document.getElementById('group-avatar-upload');
        if (avatarUpload) {
            avatarUpload.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        document.getElementById('group-avatar-preview').src = e.target.result;
                    };
                    reader.readAsDataURL(file);
                }
            });
        }
    },
    
    async createGroup() {
        const name = document.getElementById('group-name')?.value;
        const avatar = document.getElementById('group-avatar-preview')?.src;
        const selectedMembers = Array.from(document.querySelectorAll('.selected-member')).map(el => el.dataset.email);
        
        if (!name || selectedMembers.length === 0) return;
        
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await API.post('/groups/create', {
                creator_email: user.email,
                group_name: name,
                group_avatar: avatar !== '/images/group-avatar.png' ? avatar : null,
                members: selectedMembers
            });
            
            if (response.status === 'ok') {
                Toast.success('Group created successfully');
                document.getElementById('create-group-modal')?.remove();
                this.loadGroups();
            }
        } catch (error) {
            console.error('Error creating group:', error);
            Toast.error('Failed to create group');
        }
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => GroupsScreen.init());
window.GroupsScreen = GroupsScreen;