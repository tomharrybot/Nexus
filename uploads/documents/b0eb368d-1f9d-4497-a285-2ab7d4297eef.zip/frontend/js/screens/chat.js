// Chat Screen
const ChatScreen = {
    currentChat: null,
    contacts: [],
    chats: {},
    messageSoundEnabled: true,
    typingTimeout: null,
    
    init() {
        this.setupEventListeners();
        this.loadUserData();
    },
    
    setupEventListeners() {
        // Send message
        document.getElementById('send-message-btn')?.addEventListener('click', () => {
            this.sendMessage();
        });
        
        // Message input
        document.getElementById('message-input')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        document.getElementById('message-input')?.addEventListener('input', () => {
            this.handleTyping();
            this.toggleSendButton();
        });
        
        // File upload
        document.getElementById('file-upload')?.addEventListener('change', (e) => {
            this.handleFileSelect(e.target.files[0]);
        });
        
        // Back button
        document.getElementById('back-button')?.addEventListener('click', () => {
            this.showChatList();
        });
        
        // Search
        document.getElementById('search-contacts')?.addEventListener('input', (e) => {
            this.filterContacts(e.target.value);
        });
        
        // Tabs
        document.querySelectorAll('.chat-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                this.switchTab(tab.dataset.tab);
            });
        });
        
        // New chat button
        document.getElementById('new-chat-btn')?.addEventListener('click', () => {
            this.openAddContact();
        });
        
        // Menu button
        document.getElementById('menu-btn')?.addEventListener('click', () => {
            document.getElementById('menu-modal')?.classList.add('active');
        });
        
        // Chat menu
        document.getElementById('chat-menu-btn')?.addEventListener('click', () => {
            this.showChatMenu();
        });
        
        // User profile
        document.getElementById('user-profile-btn')?.addEventListener('click', () => {
            ProfileFeature.openModal();
        });
        
        // Socket events
        if (window.SocketManager) {
            SocketManager.on('new-message', (data) => this.handleNewMessage(data));
            SocketManager.on('message-status', (data) => this.handleMessageStatus(data));
            SocketManager.on('typing-started', (data) => this.handleTypingStarted(data));
            SocketManager.on('typing-stopped', (data) => this.handleTypingStopped(data));
            SocketManager.on('user-online', (data) => this.handleUserOnline(data));
            SocketManager.on('user-offline', (data) => this.handleUserOffline(data));
            SocketManager.on('messages-read', (data) => this.handleMessagesRead(data));
            SocketManager.on('message-deleted', (data) => this.handleMessageDeleted(data));
        }
    },
    
    async loadUserData() {
        const user = Storage.getUser();
        if (!user) return;
        
        try {
            // Load contacts
            const contacts = await API.get(`/contacts/${user.email}`);
            this.contacts = contacts;
            this.renderContacts();
            
            // Update profile UI
            this.updateProfileUI(user);
            
            // Set online status
            await API.post('/users/status', {
                email: user.email,
                online: true
            });
            
            // Connect socket
            if (window.SocketManager) {
                SocketManager.login(user.email);
            }
        } catch (error) {
            console.error('Error loading user data:', error);
            Toast.error('Failed to load contacts');
        }
    },
    
    renderContacts() {
        const container = document.getElementById('chat-list');
        if (!container) return;
        
        if (this.contacts.length === 0) {
            container.innerHTML = `
                <div class="no-contacts">
                    <i class="fas fa-users"></i>
                    <p>No contacts yet</p>
                    <button class="nexus-btn nexus-btn-primary" onclick="ChatScreen.openAddContact()">
                        Add Contact
                    </button>
                </div>
            `;
            return;
        }
        
        // Sort contacts (online first, then by last message)
        const sorted = ContactComponent.sortContacts(this.contacts);
        
        container.innerHTML = '';
        sorted.forEach(contact => {
            const contactEl = ContactComponent.createContactElement(contact);
            contactEl.addEventListener('click', () => {
                this.openChat(contact);
            });
            container.appendChild(contactEl);
        });
    },
    
    openChat(contact) {
        this.currentChat = contact;
        
        // Update header
        document.getElementById('current-chat-avatar').src = 
            contact.avatar || '/assets/images/default-avatar.svg';
        document.getElementById('current-chat-name').textContent = contact.name;
        
        const statusEl = document.getElementById('current-chat-status');
        if (contact.online) {
            statusEl.innerHTML = '<span class="status-dot"></span> Online';
        } else {
            statusEl.textContent = Formatters.lastSeen(contact.lastSeen);
        }
        
        // Show chat area
        if (window.innerWidth <= 768) {
            document.getElementById('sidebar').classList.add('hidden');
            document.getElementById('chat-area').style.display = 'flex';
            document.getElementById('empty-chat').style.display = 'none';
        } else {
            document.getElementById('empty-chat').style.display = 'none';
        }
        
        // Highlight active chat
        document.querySelectorAll('.chat-item').forEach(item => {
            item.classList.remove('active');
            if (item.dataset.email === contact.email) {
                item.classList.add('active');
            }
        });
        
        // Load messages
        this.loadMessages(contact.email);
        
        // Focus input
        document.getElementById('message-input').focus();
        
        // Mark messages as read
        this.markMessagesAsRead(contact.email);
    },
    
    async loadMessages(contactEmail) {
        const user = Storage.getUser();
        if (!user) return;
        
        try {
            const response = await API.post('/chats/get', {
                user1: user.email,
                user2: contactEmail
            });
            
            this.chats[contactEmail] = response.messages || [];
            this.renderMessages();
            
            // Update last message in contact list
            if (response.messages?.length > 0) {
                const lastMsg = response.messages[response.messages.length - 1];
                const contact = this.contacts.find(c => c.email === contactEmail);
                if (contact) {
                    contact.last_message = MessageComponent.getMessagePreview(lastMsg);
                    contact.last_time = lastMsg.timestamp;
                }
            }
        } catch (error) {
            console.error('Error loading messages:', error);
            Toast.error('Failed to load messages');
        }
    },
    
    renderMessages() {
        const container = document.getElementById('messages-container');
        if (!container || !this.currentChat) return;
        
        const messages = this.chats[this.currentChat.email] || [];
        const user = Storage.getUser();
        
        container.innerHTML = '';
        
        if (messages.length === 0) {
            container.innerHTML = `
                <div class="empty-messages">
                    <p>No messages yet</p>
                    <p class="small">Send a message to start the conversation</p>
                </div>
            `;
            return;
        }
        
        let lastDate = null;
        
        messages.forEach(message => {
            const messageDate = new Date(message.timestamp * 1000).toDateString();
            
            // Add date separator if date changed
            if (messageDate !== lastDate) {
                container.appendChild(this.createDateSeparator(message.timestamp));
                lastDate = messageDate;
            }
            
            const isOutgoing = message.from === user.email;
            const messageEl = MessageComponent.createMessageElement(
                message, 
                isOutgoing, 
                this.currentChat
            );
            container.appendChild(messageEl);
        });
        
        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    },
    
    createDateSeparator(timestamp) {
        const date = new Date(timestamp * 1000);
        const today = new Date().toDateString();
        const yesterday = new Date(Date.now() - 86400000).toDateString();
        
        let dateText;
        if (date.toDateString() === today) {
            dateText = 'Today';
        } else if (date.toDateString() === yesterday) {
            dateText = 'Yesterday';
        } else {
            dateText = date.toLocaleDateString(undefined, {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }
        
        const separator = document.createElement('div');
        separator.className = 'message-date-separator';
        separator.innerHTML = `<span>${dateText}</span>`;
        return separator;
    },
    
    async sendMessage() {
        const input = document.getElementById('message-input');
        const message = input.value.trim();
        
        if (!message || !this.currentChat) return;
        
        const user = Storage.getUser();
        
        // Clear input
        input.value = '';
        this.toggleSendButton();
        
        // Stop typing
        this.stopTyping();
        
        try {
            const response = await API.post('/chats/send', {
                from_email: user.email,
                to_email: this.currentChat.email,
                message,
                type: 'text'
            });
            
            if (response.status === 'ok') {
                // Add to local messages
                if (!this.chats[this.currentChat.email]) {
                    this.chats[this.currentChat.email] = [];
                }
                this.chats[this.currentChat.email].push(response.message);
                
                // Render new message
                this.renderMessages();
                
                // Update last message in contact list
                const contact = this.contacts.find(c => c.email === this.currentChat.email);
                if (contact) {
                    contact.last_message = message;
                    contact.last_time = response.message.timestamp;
                    this.renderContacts();
                }
                
                // Play sound
                this.playSound('sent');
                
                // Send via socket
                if (window.SocketManager) {
                    SocketManager.sendMessage(this.currentChat.email, message);
                }
            }
        } catch (error) {
            console.error('Error sending message:', error);
            Toast.error('Failed to send message');
            
            // Restore input
            input.value = message;
            this.toggleSendButton();
        }
    },
    
    handleNewMessage(data) {
        const message = data.message;
        
        // Check if this is for current chat
        const isCurrentChat = this.currentChat && 
            (message.from === this.currentChat.email || message.to === this.currentChat.email);
        
        // Add to messages
        const chatEmail = message.from === Storage.getUser().email ? message.to : message.from;
        
        if (!this.chats[chatEmail]) {
            this.chats[chatEmail] = [];
        }
        this.chats[chatEmail].push(message);
        
        // Update contact last message
        const contact = this.contacts.find(c => c.email === chatEmail);
        if (contact) {
            contact.last_message = MessageComponent.getMessagePreview(message);
            contact.last_time = message.timestamp;
            
            // Update unread count
            if (!isCurrentChat) {
                contact.unread_count = (contact.unread_count || 0) + 1;
            }
            
            this.renderContacts();
        }
        
        // If current chat, render message
        if (isCurrentChat) {
            this.renderMessages();
            
            // Mark as read
            this.markMessagesAsRead(chatEmail);
            
            // Play sound
            if (message.from !== Storage.getUser().email) {
                this.playSound('received');
            }
        }
        
        // Update message status to delivered
        if (message.from !== Storage.getUser().email) {
            setTimeout(() => {
                this.updateMessageStatus(message.id, 'delivered');
            }, 1000);
        }
    },
    
    handleTyping() {
        if (!this.currentChat || !window.SocketManager) return;
        
        SocketManager.startTyping(this.currentChat.email);
        
        if (this.typingTimeout) {
            clearTimeout(this.typingTimeout);
        }
        
        this.typingTimeout = setTimeout(() => {
            this.stopTyping();
        }, 1000);
    },
    
    stopTyping() {
        if (this.currentChat && window.SocketManager) {
            SocketManager.stopTyping(this.currentChat.email);
        }
    },
    
    handleTypingStarted(data) {
        if (this.currentChat && data.from === this.currentChat.email) {
            document.getElementById('typing-indicator').style.display = 'flex';
            document.getElementById('typing-text').textContent = 
                `${this.currentChat.name} is typing...`;
        }
    },
    
    handleTypingStopped(data) {
        if (this.currentChat && data.from === this.currentChat.email) {
            document.getElementById('typing-indicator').style.display = 'none';
        }
    },
    
    handleMessageStatus(data) {
        // Update message status in UI
        const messageEl = document.querySelector(`.message[data-message-id="${data.messageId}"]`);
        if (messageEl) {
            const statusIcon = messageEl.querySelector('.message-status');
            if (statusIcon) {
                statusIcon.className = `message-status ${data.status}`;
            }
        }
        
        // Update in data
        for (const chatEmail in this.chats) {
            const message = this.chats[chatEmail].find(m => m.id === data.messageId);
            if (message) {
                message.status = data.status;
                break;
            }
        }
    },
    
    handleMessageDeleted(data) {
        // Remove message from UI
        const messageEl = document.querySelector(`.message[data-message-id="${data.messageId}"]`);
        if (messageEl) {
            messageEl.remove();
        }
        
        // Remove from data
        for (const chatEmail in this.chats) {
            this.chats[chatEmail] = this.chats[chatEmail].filter(
                m => m.id !== data.messageId
            );
        }
        
        Toast.info('Message was deleted');
    },
    
    handleUserOnline(data) {
        this.updateUserStatus(data.email, true);
    },
    
    handleUserOffline(data) {
        this.updateUserStatus(data.email, false, data.lastSeen);
    },
    
    handleMessagesRead(data) {
        if (this.currentChat && data.by === this.currentChat.email) {
            // Update message statuses
            document.querySelectorAll('.message-outgoing .message-status').forEach(el => {
                el.className = 'message-status seen';
            });
        }
    },
    
    updateUserStatus(email, online, lastSeen) {
        // Update in contacts
        const contact = this.contacts.find(c => c.email === email);
        if (contact) {
            contact.online = online;
            if (!online) contact.lastSeen = lastSeen;
        }
        
        // Update contact list UI
        const contactEl = document.querySelector(`.chat-item[data-email="${email}"]`);
        if (contactEl) {
            ContactComponent.updateContactStatus(contactEl, online, lastSeen);
        }
        
        // Update current chat header
        if (this.currentChat && this.currentChat.email === email) {
            const statusEl = document.getElementById('current-chat-status');
            if (online) {
                statusEl.innerHTML = '<span class="status-dot"></span> Online';
            } else {
                statusEl.textContent = Formatters.lastSeen(lastSeen);
            }
        }
        
        // Re-render contacts to update order
        this.renderContacts();
    },
    
    async markMessagesAsRead(contactEmail) {
        const user = Storage.getUser();
        if (!user) return;
        
        try {
            await API.post('/chats/mark-seen', {
                user_email: user.email,
                contact_email: contactEmail
            });
            
            // Update local unread count
            const contact = this.contacts.find(c => c.email === contactEmail);
            if (contact) {
                contact.unread_count = 0;
                this.renderContacts();
            }
            
            // Notify via socket
            if (window.SocketManager) {
                SocketManager.markAsRead(contactEmail);
            }
        } catch (error) {
            console.error('Error marking messages as read:', error);
        }
    },
    
    async updateMessageStatus(messageId, status) {
        try {
            await API.post('/chats/update-status', {
                message_id: messageId,
                status
            });
        } catch (error) {
            console.error('Error updating message status:', error);
        }
    },
    
    handleFileSelect(file) {
        if (!file) return;
        
        // Determine file type
        let type = 'document';
        if (file.type.startsWith('image/')) type = 'image';
        else if (file.type.startsWith('video/')) type = 'video';
        else if (file.type.startsWith('audio/')) type = 'audio';
        
        // Validate
        const validation = Validators.file(file, type);
        if (!validation.valid) {
            Toast.error(validation.message);
            return;
        }
        
        // Show preview
        this.showMediaPreview(file, type);
    },
    
    showMediaPreview(file, type) {
        const reader = new FileReader();
        
        reader.onload = (e) => {
            const preview = document.createElement('div');
            preview.className = 'media-preview';
            preview.innerHTML = `
                <div class="media-preview-header">
                    <h4>Send ${type}</h4>
                    <button class="close-preview"><i class="fas fa-times"></i></button>
                </div>
                <div class="media-preview-content">
                    ${type === 'image' ? `<img src="${e.target.result}">` : ''}
                    ${type === 'video' ? `<video src="${e.target.result}" controls></video>` : ''}
                    ${type === 'audio' ? `<audio src="${e.target.result}" controls></audio>` : ''}
                    ${type === 'document' ? `
                        <div class="document-preview">
                            <i class="fas fa-file"></i>
                            <span>${file.name}</span>
                        </div>
                    ` : ''}
                </div>
                <div class="media-preview-info">
                    <span class="media-preview-name">${file.name}</span>
                    <span class="media-preview-size">${Formatters.fileSize(file.size)}</span>
                </div>
                <div class="media-preview-actions">
                    <button class="media-cancel-btn">Cancel</button>
                    <button class="media-send-btn">Send</button>
                </div>
            `;
            
            document.body.appendChild(preview);
            
            preview.querySelector('.close-preview').addEventListener('click', () => {
                preview.remove();
            });
            
            preview.querySelector('.media-cancel-btn').addEventListener('click', () => {
                preview.remove();
            });
            
            preview.querySelector('.media-send-btn').addEventListener('click', async () => {
                await this.uploadAndSendMedia(file, type);
                preview.remove();
            });
        };
        
        if (type === 'image' || type === 'video' || type === 'audio') {
            reader.readAsDataURL(file);
        } else {
            reader.readAsText(file, 'utf-8');
        }
    },
    
    async uploadAndSendMedia(file, type) {
        const user = Storage.getUser();
        if (!user || !this.currentChat) return;
        
        const formData = new FormData();
        formData.append('file', file);
        formData.append('type', type);
        
        const closeToast = Toast.loading('Uploading...');
        
        try {
            const uploadRes = await API.upload('/media/upload', formData);
            
            if (uploadRes.status === 'ok') {
                const messageRes = await API.post('/chats/send', {
                    from_email: user.email,
                    to_email: this.currentChat.email,
                    message: uploadRes.url,
                    type
                });
                
                if (messageRes.status === 'ok') {
                    // Add to messages
                    if (!this.chats[this.currentChat.email]) {
                        this.chats[this.currentChat.email] = [];
                    }
                    this.chats[this.currentChat.email].push(messageRes.message);
                    
                    // Render
                    this.renderMessages();
                    
                    // Update last message
                    const contact = this.contacts.find(c => c.email === this.currentChat.email);
                    if (contact) {
                        contact.last_message = type === 'image' ? '📷 Photo' :
                                              type === 'video' ? '🎥 Video' :
                                              type === 'audio' ? '🎵 Voice message' :
                                              '📄 File';
                        contact.last_time = messageRes.message.timestamp;
                        this.renderContacts();
                    }
                    
                    Toast.success(`${type} sent`);
                }
            }
        } catch (error) {
            console.error('Error uploading media:', error);
            Toast.error('Failed to send media');
        } finally {
            closeToast();
        }
    },
    
    toggleSendButton() {
        const input = document.getElementById('message-input');
        const sendBtn = document.getElementById('send-message-btn');
        
        if (input.value.trim()) {
            sendBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
            sendBtn.classList.add('active');
        } else {
            sendBtn.innerHTML = '<i class="fas fa-microphone"></i>';
            sendBtn.classList.remove('active');
        }
    },
    
    playSound(type) {
        if (!this.messageSoundEnabled) return;
        
        const audio = document.getElementById(
            type === 'sent' ? 'message-sent-sound' : 'message-received-sound'
        );
        if (audio) {
            audio.currentTime = 0;
            audio.play().catch(e => console.log('Audio play failed:', e));
        }
    },
    
    filterContacts(query) {
        const filtered = ContactComponent.filterContacts(this.contacts, query);
        
        document.querySelectorAll('.chat-item').forEach(item => {
            const email = item.dataset.email;
            item.style.display = filtered.some(c => c.email === email) ? 'flex' : 'none';
        });
    },
    
    switchTab(tab) {
        document.querySelectorAll('.chat-tab').forEach(t => t.classList.remove('active'));
        document.querySelector(`.chat-tab[data-tab="${tab}"]`).classList.add('active');
        
        if (tab === 'chats') {
            document.getElementById('chat-list').style.display = 'block';
            document.getElementById('groups-list').style.display = 'none';
        } else {
            document.getElementById('chat-list').style.display = 'none';
            document.getElementById('groups-list').style.display = 'block';
            if (window.GroupsScreen) {
                GroupsScreen.loadGroups();
            }
        }
    },
    
    showChatList() {
        document.getElementById('sidebar').classList.remove('hidden');
        document.getElementById('chat-area').style.display = 'none';
        
        if (window.innerWidth > 768) {
            document.getElementById('empty-chat').style.display = 'flex';
        }
        
        this.currentChat = null;
    },
    
    showChatMenu() {
        const modal = document.getElementById('chat-menu-modal');
        if (modal && this.currentChat) {
            modal.classList.add('active');
        }
    },
    
    openAddContact() {
        ModalComponent.showModal({
            title: 'Add Contact',
            content: `
                <div class="add-contact">
                    <input type="email" id="contact-email" class="nexus-input" 
                           placeholder="Enter email address">
                    <div id="contact-search-results" class="contact-search-results"></div>
                    <button class="nexus-btn nexus-btn-primary" id="add-contact-btn" disabled>
                        Add Contact
                    </button>
                </div>
            `
        }).then(modal => {
            const emailInput = modal.querySelector('#contact-email');
            const addBtn = modal.querySelector('#add-contact-btn');
            const resultsDiv = modal.querySelector('#contact-search-results');
            
            let searchTimeout;
            
            emailInput.addEventListener('input', () => {
                clearTimeout(searchTimeout);
                const email = emailInput.value.trim();
                
                addBtn.disabled = !Validators.email(email);
                
                searchTimeout = setTimeout(async () => {
                    if (email.length > 2) {
                        try {
                            const users = await API.get('/users/all');
                            const filtered = users.filter(u => 
                                u.email.toLowerCase().includes(email.toLowerCase()) &&
                                u.email !== Storage.getUser().email
                            );
                            
                            resultsDiv.innerHTML = '';
                            filtered.forEach(user => {
                                const result = ContactComponent.createSearchResult(
                                    user,
                                    (selected) => {
                                        emailInput.value = selected.email;
                                        resultsDiv.innerHTML = '';
                                        addBtn.disabled = false;
                                    }
                                );
                                resultsDiv.appendChild(result);
                            });
                        } catch (error) {
                            console.error('Error searching users:', error);
                        }
                    }
                }, 500);
            });
            
            addBtn.addEventListener('click', async () => {
                const email = emailInput.value.trim();
                
                if (!Validators.email(email)) {
                    Toast.error('Invalid email');
                    return;
                }
                
                try {
                    const response = await API.post('/contacts/add', {
                        user_email: Storage.getUser().email,
                        contact_email: email
                    });
                    
                    if (response.status === 'ok') {
                        Toast.success('Contact added');
                        ModalComponent.closeModal(modal);
                        this.loadUserData();
                    } else {
                        Toast.error(response.message || 'Failed to add contact');
                    }
                } catch (error) {
                    console.error('Error adding contact:', error);
                    Toast.error('Failed to add contact');
                }
            });
        });
    },
    
    updateProfileUI(user) {
        document.getElementById('user-avatar').src = 
            user.profile?.avatar || '/assets/images/default-avatar.svg';
        document.getElementById('user-status').style.display = 'block';
    }
};

// Initialize on load
document.addEventListener('DOMContentLoaded', () => ChatScreen.init());

// Make globally available
window.ChatScreen = ChatScreen;
window.openChatWithEmail = (email) => {
    const contact = ChatScreen.contacts.find(c => c.email === email);
    if (contact) {
        ChatScreen.openChat(contact);
    }
};