// Settings Screen
const SettingsScreen = {
    settings: {},
    
    init() {
        this.loadSettings();
        this.setupEventListeners();
    },
    
    loadSettings() {
        this.settings = Storage.getSettings();
    },
    
    setupEventListeners() {
        // Theme selector
        const themeOptions = document.querySelectorAll('.theme-option');
        themeOptions.forEach(option => {
            option.addEventListener('click', () => {
                const theme = option.dataset.theme;
                this.changeTheme(theme);
            });
        });
        
        // Notification toggles
        const notificationsToggle = document.getElementById('notifications-toggle');
        if (notificationsToggle) {
            notificationsToggle.addEventListener('change', (e) => {
                this.updateSettings({ notifications: e.target.checked });
            });
        }
        
        const soundToggle = document.getElementById('sound-toggle');
        if (soundToggle) {
            soundToggle.addEventListener('change', (e) => {
                this.updateSettings({ sound: e.target.checked });
            });
        }
        
        const vibrationToggle = document.getElementById('vibration-toggle');
        if (vibrationToggle) {
            vibrationToggle.addEventListener('change', (e) => {
                this.updateSettings({ vibration: e.target.checked });
            });
        }
    },
    
    changeTheme(theme) {
        Storage.setTheme(theme);
        this.settings.theme = theme;
        Storage.setSettings(this.settings);
        
        document.body.className = theme + '-theme';
        Toast.success(`Theme changed to ${theme}`);
        
        // Save to server
        this.saveSettingsToServer({ theme });
    },
    
    updateSettings(updates) {
        this.settings = { ...this.settings, ...updates };
        Storage.setSettings(this.settings);
        this.saveSettingsToServer(updates);
    },
    
    async saveSettingsToServer(updates) {
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            await API.post('/users/settings/update', {
                email: user.email,
                ...updates
            });
        } catch (error) {
            console.error('Error saving settings to server:', error);
        }
    },
    
    openSettingsModal() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'settings-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Settings</h2>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="settings-section">
                        <h3>Theme</h3>
                        <div class="theme-options">
                            <div class="theme-option ${this.settings.theme === 'cosmic' ? 'active' : ''}" data-theme="cosmic">
                                <div class="theme-preview cosmic-theme"></div>
                                <span>Cosmic</span>
                            </div>
                            <div class="theme-option ${this.settings.theme === 'dark' ? 'active' : ''}" data-theme="dark">
                                <div class="theme-preview dark-theme"></div>
                                <span>Dark</span>
                            </div>
                            <div class="theme-option ${this.settings.theme === 'light' ? 'active' : ''}" data-theme="light">
                                <div class="theme-preview light-theme"></div>
                                <span>Light</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="settings-section">
                        <h3>Notifications</h3>
                        <div class="settings-item">
                            <span>Enable Notifications</span>
                            <label class="switch">
                                <input type="checkbox" id="settings-notifications" ${this.settings.notifications ? 'checked' : ''}>
                                <span class="slider"></span>
                            </label>
                        </div>
                        <div class="settings-item">
                            <span>Message Sound</span>
                            <label class="switch">
                                <input type="checkbox" id="settings-sound" ${this.settings.sound ? 'checked' : ''}>
                                <span class="slider"></span>
                            </label>
                        </div>
                        <div class="settings-item">
                            <span>Vibration</span>
                            <label class="switch">
                                <input type="checkbox" id="settings-vibration" ${this.settings.vibration ? 'checked' : ''}>
                                <span class="slider"></span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="settings-section">
                        <h3>Privacy</h3>
                        <button class="nexus-btn nexus-btn-secondary" onclick="PrivacyFeature.openModal()">
                            Privacy Settings
                        </button>
                    </div>
                    
                    <div class="settings-section">
                        <h3>Security</h3>
                        <button class="nexus-btn nexus-btn-secondary" onclick="SecurityFeature.openModal()">
                            Security Settings
                        </button>
                    </div>
                    
                    <div class="settings-section">
                        <h3>Support</h3>
                        <button class="nexus-btn nexus-btn-secondary" onclick="SupportFeature.openModal()">
                            Help & Support
                        </button>
                    </div>
                    
                    <div class="settings-section">
                        <h3>Account</h3>
                        <button class="nexus-btn nexus-btn-secondary" onclick="ProfileFeature.openModal()">
                            Edit Profile
                        </button>
                        <button class="nexus-btn nexus-btn-danger" onclick="SettingsScreen.logout()">
                            Logout
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        setTimeout(() => modal.classList.add('active'), 10);
        
        // Add event listeners
        modal.querySelectorAll('.theme-option').forEach(option => {
            option.addEventListener('click', () => {
                const theme = option.dataset.theme;
                this.changeTheme(theme);
                
                // Update active state
                modal.querySelectorAll('.theme-option').