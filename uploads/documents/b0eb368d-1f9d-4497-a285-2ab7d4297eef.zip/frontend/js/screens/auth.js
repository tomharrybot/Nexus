// Auth Screen
const AuthScreen = {
    currentUser: null,
    
    init() {
        this.checkSavedSession();
        this.setupEventListeners();
    },
    
    checkSavedSession() {
        const savedUser = Storage.getUser();
        if (savedUser) {
            this.currentUser = savedUser;
            this.showMainScreen();
        }
    },
    
    setupEventListeners() {
        // Send OTP button
        document.getElementById('send-otp-btn')?.addEventListener('click', () => {
            this.sendOTP();
        });
        
        // Verify OTP button
        document.getElementById('verify-otp-btn')?.addEventListener('click', () => {
            this.verifyOTP();
        });
        
        // Email input blur
        document.getElementById('email-input')?.addEventListener('blur', () => {
            this.checkEmail();
        });
        
        // OTP inputs
        document.querySelectorAll('.otp-digit').forEach((input, index) => {
            input.addEventListener('input', (e) => this.handleOTPInput(e, index));
            input.addEventListener('keydown', (e) => this.handleOTPKeydown(e, index));
        });
        
        // Terms checkbox
        document.getElementById('terms-checkbox')?.addEventListener('change', (e) => {
            document.getElementById('agree-continue-btn').disabled = !e.target.checked;
        });
    },
    
    async sendOTP() {
        const email = document.getElementById('email-input').value.trim();
        
        if (!Validators.email(email)) {
            Toast.error('Please enter a valid email');
            return;
        }
        
        const sendBtn = document.getElementById('send-otp-btn');
        const sendText = document.getElementById('send-otp-text');
        const sendSpinner = document.getElementById('send-otp-spinner');
        
        // Show loading
        sendText.style.display = 'none';
        sendSpinner.style.display = 'block';
        sendBtn.disabled = true;
        
        try {
            const response = await API.post('/auth/send-otp', { email });
            
            if (response.status === 'ok') {
                Toast.success('OTP sent to your email');
                document.getElementById('otp-container').style.display = 'block';
                document.getElementById('verify-otp-btn').style.display = 'block';
                sendBtn.style.display = 'none';
                
                // Focus first OTP input
                document.querySelector('.otp-digit').focus();
                
                // Start timer
                this.startOTPTimer();
            } else {
                Toast.error(response.message || 'Failed to send OTP');
            }
        } catch (error) {
            console.error('Send OTP error:', error);
            Toast.error('Failed to send OTP');
        } finally {
            sendText.style.display = 'block';
            sendSpinner.style.display = 'none';
            sendBtn.disabled = false;
        }
    },
    
    async verifyOTP() {
        const email = document.getElementById('email-input').value.trim();
        const username = document.getElementById('username-input').value.trim();
        const otp = this.getOTP();
        
        if (!Validators.email(email)) {
            Toast.error('Please enter a valid email');
            return;
        }
        
        if (!Validators.otp(otp)) {
            Toast.error('Please enter a valid 6-digit OTP');
            return;
        }
        
        const verifyBtn = document.getElementById('verify-otp-btn');
        const verifyText = document.getElementById('verify-otp-text');
        const verifySpinner = document.getElementById('verify-otp-spinner');
        const loadingSteps = document.getElementById('loading-steps');
        
        // Show loading
        verifyText.style.display = 'none';
        verifySpinner.style.display = 'block';
        verifyBtn.disabled = true;
        loadingSteps.style.display = 'block';
        
        try {
            const response = await API.post('/auth/verify-otp', {
                email,
                code: otp,
                username: username || undefined
            });
            
            if (response.status === 'ok') {
                this.currentUser = response.user;
                Storage.setUser(response.user);
                
                // Update loading steps
                this.updateLoadingStep(0, 'completed');
                
                setTimeout(() => {
                    this.updateLoadingStep(1, 'loading');
                }, 500);
                
                setTimeout(() => {
                    this.updateLoadingStep(1, 'completed');
                    this.updateLoadingStep(2, 'loading');
                }, 1000);
                
                setTimeout(() => {
                    this.showMainScreen();
                    Toast.success('Welcome to Nexus Chat!');
                }, 1500);
                
                // Connect socket
                if (window.SocketManager) {
                    SocketManager.login(email);
                }
            } else {
                Toast.error(response.message || 'Verification failed');
                loadingSteps.style.display = 'none';
            }
        } catch (error) {
            console.error('Verify OTP error:', error);
            Toast.error('Verification failed');
            loadingSteps.style.display = 'none';
        } finally {
            verifyText.style.display = 'block';
            verifySpinner.style.display = 'none';
            verifyBtn.disabled = false;
        }
    },
    
    getOTP() {
        let otp = '';
        document.querySelectorAll('.otp-digit').forEach(input => {
            otp += input.value;
        });
        return otp;
    },
    
    handleOTPInput(e, index) {
        const input = e.target;
        const value = input.value;
        
        // Allow only numbers
        input.value = value.replace(/[^0-9]/g, '');
        
        if (input.value && index < 5) {
            document.querySelectorAll('.otp-digit')[index + 1].focus();
        }
    },
    
    handleOTPKeydown(e, index) {
        if (e.key === 'Backspace' && !e.target.value && index > 0) {
            document.querySelectorAll('.otp-digit')[index - 1].focus();
        }
    },
    
    startOTPTimer() {
        let timeLeft = 60;
        const timerEl = document.createElement('div');
        timerEl.className = 'otp-timer';
        timerEl.innerHTML = `<span>Resend code in </span><span id="countdown">60</span>s`;
        
        const otpContainer = document.getElementById('otp-container');
        otpContainer.appendChild(timerEl);
        
        const interval = setInterval(() => {
            timeLeft--;
            const countdown = document.getElementById('countdown');
            if (countdown) countdown.textContent = timeLeft;
            
            if (timeLeft <= 0) {
                clearInterval(interval);
                timerEl.remove();
                
                // Show resend link
                const resendLink = document.createElement('a');
                resendLink.href = '#';
                resendLink.className = 'resend-link';
                resendLink.textContent = 'Resend OTP';
                resendLink.onclick = (e) => {
                    e.preventDefault();
                    this.sendOTP();
                };
                otpContainer.appendChild(resendLink);
            }
        }, 1000);
    },
    
    updateLoadingStep(index, state) {
        const steps = document.querySelectorAll('.loading-step');
        if (steps[index]) {
            const icon = steps[index].querySelector('i');
            icon.className = state === 'completed' ? 'fas fa-check-circle step-completed' :
                            state === 'loading' ? 'fas fa-spinner fa-spin step-loading' :
                            'fas fa-circle step-pending';
        }
    },
    
    checkEmail() {
        const email = document.getElementById('email-input').value.trim();
        if (Validators.email(email)) {
            document.getElementById('terms-container').style.display = 'block';
            document.getElementById('agree-continue-btn').style.display = 'block';
        }
    },
    
    showMainScreen() {
        document.getElementById('auth-screen').classList.remove('active');
        document.getElementById('main-screen').classList.add('active');
        
        // Load user data
        if (window.ChatScreen) {
            ChatScreen.loadUserData();
        }
    },
    
    logout() {
        if (this.currentUser) {
            API.post('/users/status', {
                email: this.currentUser.email,
                online: false
            }).catch(console.error);
        }
        
        Storage.clear();
        this.currentUser = null;
        
        document.getElementById('main-screen').classList.remove('active');
        document.getElementById('auth-screen').classList.add('active');
        
        // Reset form
        document.getElementById('email-input').value = '';
        document.getElementById('username-input').value = '';
        document.querySelectorAll('.otp-digit').forEach(input => input.value = '');
        document.getElementById('otp-container').style.display = 'none';
        document.getElementById('verify-otp-btn').style.display = 'none';
        document.getElementById('send-otp-btn').style.display = 'block';
        document.getElementById('terms-container').style.display = 'none';
        document.getElementById('agree-continue-btn').style.display = 'none';
        
        Toast.success('Logged out successfully');
    }
};

// Initialize on load
document.addEventListener('DOMContentLoaded', () => AuthScreen.init());

// Make globally available
window.AuthScreen = AuthScreen;
window.logout = () => AuthScreen.logout();