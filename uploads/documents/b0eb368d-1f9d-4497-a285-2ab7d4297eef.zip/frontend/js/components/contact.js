// Contact Component
const ContactComponent = {
    // Create contact element for list
    createContactElement(contact, isSelected = false) {
        const contactEl = document.createElement('div');
        contactEl.className = `chat-item ${isSelected ? 'selected' : ''}`;
        contactEl.dataset.email = contact.email;
        
        const lastMessage = contact.last_message || 'No messages yet';
        const lastTime = Formatters.time(contact.last_time);
        const unreadBadge = contact.unread_count ? 
            `<div class="chat-unread">${contact.unread_count}</div>` : '';
        
        contactEl.innerHTML = `
            <div class="chat-avatar-container">
                <img src="${contact.avatar || '/assets/images/default-avatar.svg'}" 
                     class="chat-avatar" alt="${contact.name}">
                <span class="status-indicator ${contact.online ? '' : 'offline'}"></span>
            </div>
            <div class="chat-info">
                <div class="chat-name">
                    ${contact.name}
                    ${unreadBadge}
                </div>
                <div class="chat-last-msg">${lastMessage}</div>
            </div>
            <div class="chat-meta">
                <div class="chat-time">${lastTime}</div>
            </div>
        `;
        
        return contactEl;
    },
    
    // Create contact for forward modal
    createForwardContact(contact, onSelect) {
        const contactEl = document.createElement('div');
        contactEl.className = 'forward-contact';
        contactEl.dataset.email = contact.email;
        
        contactEl.innerHTML = `
            <img src="${contact.avatar || '/assets/images/default-avatar.svg'}" 
                 class="forward-contact-avatar" alt="${contact.name}">
            <div class="forward-contact-info">
                <div class="forward-contact-name">${contact.name}</div>
                <div class="forward-contact-email">${contact.email}</div>
            </div>
            <input type="checkbox" class="forward-contact-checkbox">
        `;
        
        const checkbox = contactEl.querySelector('.forward-contact-checkbox');
        checkbox.addEventListener('change', (e) => {
            if (onSelect) {
                onSelect(contact, e.target.checked);
            }
            contactEl.classList.toggle('selected', e.target.checked);
        });
        
        return contactEl;
    },
    
    // Create contact for group member selection
    createMemberContact(contact, onToggle) {
        const contactEl = document.createElement('div');
        contactEl.className = 'member-item';
        contactEl.dataset.email = contact.email;
        
        contactEl.innerHTML = `
            <img src="${contact.avatar || '/assets/images/default-avatar.svg'}" 
                 class="member-avatar" alt="${contact.name}">
            <span class="member-name">${contact.name}</span>
            <input type="checkbox" class="member-checkbox">
        `;
        
        const checkbox = contactEl.querySelector('.member-checkbox');
        checkbox.addEventListener('change', (e) => {
            if (onToggle) {
                onToggle(contact, e.target.checked);
            }
        });
        
        return contactEl;
    },
    
    // Create selected member badge
    createSelectedMember(contact, onRemove) {
        const badge = document.createElement('div');
        badge.className = 'selected-member';
        badge.dataset.email = contact.email;
        
        badge.innerHTML = `
            <img src="${contact.avatar || '/assets/images/default-avatar.svg'}" 
                 class="selected-member-avatar" alt="${contact.name}">
            <span>${contact.name}</span>
            <button class="remove-member">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        badge.querySelector('.remove-member').addEventListener('click', () => {
            if (onRemove) {
                onRemove(contact.email);
            }
            badge.remove();
        });
        
        return badge;
    },
    
    // Create contact search result
    createSearchResult(user, onSelect) {
        const resultEl = document.createElement('div');
        resultEl.className = 'contact-result';
        resultEl.dataset.email = user.email;
        
        resultEl.innerHTML = `
            <img src="${user.avatar || '/assets/images/default-avatar.svg'}" 
                 class="contact-result-avatar" alt="${user.name || user.email}">
            <div class="contact-result-info">
                <div class="contact-result-name">${user.name || user.email}</div>
                <div class="contact-result-email">${user.email}</div>
            </div>
            ${user.online ? '<span class="status-indicator"></span>' : ''}
        `;
        
        resultEl.addEventListener('click', () => {
            if (onSelect) {
                onSelect(user);
            }
        });
        
        return resultEl;
    },
    
    // Create blocked user item
    createBlockedUser(email, onUnblock) {
        const item = document.createElement('div');
        item.className = 'blocked-user-item';
        item.dataset.email = email;
        
        item.innerHTML = `
            <span>${email}</span>
            <button class="unblock-btn">
                <i class="fas fa-user-check"></i> Unblock
            </button>
        `;
        
        item.querySelector('.unblock-btn').addEventListener('click', () => {
            if (onUnblock) {
                onUnblock(email);
            }
        });
        
        return item;
    },
    
    // Update contact status
    updateContactStatus(contactEl, online, lastSeen) {
        const statusDot = contactEl.querySelector('.status-indicator');
        if (statusDot) {
            statusDot.className = `status-indicator ${online ? '' : 'offline'}`;
        }
        
        const statusText = contactEl.querySelector('.contact-status');
        if (statusText) {
            statusText.textContent = online ? 'Online' : Formatters.lastSeen(lastSeen);
        }
    },
    
    // Update last message
    updateLastMessage(contactEl, message, timestamp) {
        const lastMsgEl = contactEl.querySelector('.chat-last-msg');
        const timeEl = contactEl.querySelector('.chat-time');
        
        if (lastMsgEl) {
            lastMsgEl.textContent = message;
        }
        if (timeEl) {
            timeEl.textContent = Formatters.time(timestamp);
        }
    },
    
    // Update unread count
    updateUnreadCount(contactEl, count) {
        const nameEl = contactEl.querySelector('.chat-name');
        const existingBadge = contactEl.querySelector('.chat-unread');
        
        if (existingBadge) {
            if (count > 0) {
                existingBadge.textContent = count;
            } else {
                existingBadge.remove();
            }
        } else if (count > 0) {
            const badge = document.createElement('div');
            badge.className = 'chat-unread';
            badge.textContent = count;
            nameEl.appendChild(badge);
        }
    },
    
    // Filter contacts by search query
    filterContacts(contacts, query) {
        if (!query) return contacts;
        
        query = query.toLowerCase();
        return contacts.filter(contact => 
            contact.name.toLowerCase().includes(query) ||
            contact.email.toLowerCase().includes(query)
        );
    },
    
    // Sort contacts (online first, then by last message time)
    sortContacts(contacts) {
        return [...contacts].sort((a, b) => {
            // Online first
            if (a.online && !b.online) return -1;
            if (!a.online && b.online) return 1;
            
            // Then by last message time
            const timeA = a.last_time || 0;
            const timeB = b.last_time || 0;
            return timeB - timeA;
        });
    }
};

// Make globally available
window.ContactComponent = ContactComponent;