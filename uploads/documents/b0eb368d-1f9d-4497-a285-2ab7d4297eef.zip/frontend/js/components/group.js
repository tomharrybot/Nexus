// Group Component
const GroupComponent = {
    // Create group element for list
    createGroupElement(group) {
        const groupEl = document.createElement('div');
        groupEl.className = 'chat-item';
        groupEl.dataset.groupId = group.id;
        
        const lastMessage = group.last_message || 'No messages yet';
        const lastTime = Formatters.time(group.last_message_time);
        const memberCount = group.members?.length || 0;
        
        groupEl.innerHTML = `
            <img src="${group.avatar || '/assets/images/group-avatar.svg'}" 
                 class="chat-avatar" alt="${group.name}">
            <div class="chat-info">
                <div class="chat-name">${group.name}</div>
                <div class="chat-last-msg">${lastMessage}</div>
            </div>
            <div class="chat-meta">
                <div class="chat-time">${lastTime}</div>
                <div class="chat-members">${memberCount} members</div>
            </div>
        `;
        
        return groupEl;
    },
    
    // Create member item for group details
    createMemberItem(member, isAdmin = false, currentUser = null, onAction) {
        const item = document.createElement('div');
        item.className = 'group-member-item';
        item.dataset.email = member.email;
        
        const isCurrentUser = currentUser && member.email === currentUser.email;
        const canRemove = !isCurrentUser && (isAdmin || currentUser?.isAdmin);
        
        item.innerHTML = `
            <img src="${member.avatar || '/assets/images/default-avatar.svg'}" 
                 class="member-avatar" alt="${member.name}">
            <div class="member-info">
                <div class="member-name">
                    ${member.name}
                    ${isAdmin ? '<span class="admin-badge">Admin</span>' : ''}
                    ${isCurrentUser ? '<span class="you-badge">You</span>' : ''}
                </div>
                <div class="member-status ${member.online ? 'online' : 'offline'}">
                    ${member.online ? 'Online' : Formatters.lastSeen(member.lastSeen)}
                </div>
            </div>
            ${canRemove ? `
                <button class="remove-member-btn" title="Remove from group">
                    <i class="fas fa-times"></i>
                </button>
            ` : ''}
        `;
        
        if (canRemove) {
            item.querySelector('.remove-member-btn').addEventListener('click', () => {
                if (onAction) {
                    onAction('remove', member);
                }
            });
        }
        
        return item;
    },
    
    // Create group settings form
    createSettingsForm(group, onSave) {
        const form = document.createElement('div');
        form.className = 'group-settings-form';
        
        form.innerHTML = `
            <div class="group-avatar-section">
                <img src="${group.avatar || '/assets/images/group-avatar.svg'}" 
                     class="group-avatar-large" id="group-settings-avatar">
                <button class="change-avatar-btn" id="change-group-avatar">
                    <i class="fas fa-camera"></i> Change Photo
                </button>
                <input type="file" id="group-avatar-upload" accept="image/*" style="display: none;">
            </div>
            
            <div class="form-group">
                <label>Group Name</label>
                <input type="text" id="group-name-input" class="nexus-input" 
                       value="${group.name}" placeholder="Enter group name">
            </div>
            
            <div class="form-group">
                <label>Group Description</label>
                <textarea id="group-description" class="nexus-textarea" 
                          placeholder="Enter group description">${group.description || ''}</textarea>
            </div>
            
            <div class="form-group">
                <label>Settings</label>
                <div class="settings-toggle">
                    <span>Allow messages from</span>
                    <select id="group-message-setting" class="nexus-select">
                        <option value="everyone" ${group.settings?.allow_messages_from === 'everyone' ? 'selected' : ''}>Everyone</option>
                        <option value="admins_only" ${group.settings?.allow_messages_from === 'admins_only' ? 'selected' : ''}>Admins Only</option>
                    </select>
                </div>
                
                <div class="settings-toggle">
                    <span>Approve new members</span>
                    <label class="switch">
                        <input type="checkbox" id="group-approval-setting" 
                               ${group.settings?.approve_new_members ? 'checked' : ''}>
                        <span class="slider"></span>
                    </label>
                </div>
            </div>
            
            <div class="form-actions">
                <button class="nexus-btn nexus-btn-primary" id="save-group-settings">Save Changes</button>
                <button class="nexus-btn nexus-btn-secondary" id="cancel-group-settings">Cancel</button>
            </div>
        `;
        
        // Add event listeners
        form.querySelector('#change-group-avatar').addEventListener('click', () => {
            form.querySelector('#group-avatar-upload').click();
        });
        
        form.querySelector('#group-avatar-upload').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    form.querySelector('#group-settings-avatar').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
        
        form.querySelector('#save-group-settings').addEventListener('click', () => {
            const updatedGroup = {
                ...group,
                name: form.querySelector('#group-name-input').value,
                description: form.querySelector('#group-description').value,
                avatar: form.querySelector('#group-settings-avatar').src,
                settings: {
                    allow_messages_from: form.querySelector('#group-message-setting').value,
                    approve_new_members: form.querySelector('#group-approval-setting').checked
                }
            };
            
            if (onSave) {
                onSave(updatedGroup);
            }
        });
        
        form.querySelector('#cancel-group-settings').addEventListener('click', () => {
            form.remove();
        });
        
        return form;
    },
    
    // Create group invite link
    createInviteLink(groupId) {
        const inviteLink = `${window.location.origin}/join/${groupId}`;
        
        const container = document.createElement('div');
        container.className = 'invite-link-container';
        
        container.innerHTML = `
            <div class="invite-link-header">
                <h4>Invite Link</h4>
                <button class="close-btn" onclick="this.closest('.invite-link-container').remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="invite-link-content">
                <input type="text" class="nexus-input" value="${inviteLink}" readonly id="invite-link-input">
                <button class="nexus-btn nexus-btn-primary" id="copy-invite-link">
                    <i class="fas fa-copy"></i> Copy
                </button>
            </div>
            <p class="invite-link-note">Anyone with this link can join the group</p>
        `;
        
        container.querySelector('#copy-invite-link').addEventListener('click', () => {
            const input = container.querySelector('#invite-link-input');
            input.select();
            document.execCommand('copy');
            Toast.success('Link copied to clipboard');
        });
        
        return container;
    },
    
    // Format member count
    formatMemberCount(count) {
        if (count === 1) return '1 member';
        return `${count} members`;
    },
    
    // Check if user is admin
    isAdmin(group, email) {
        return group.admins?.includes(email) || false;
    },
    
    // Check if user can send message
    canSendMessage(group, email) {
        if (!group) return false;
        
        const settings = group.settings || {};
        const isMember = group.members?.includes(email);
        const isAdmin = this.isAdmin(group, email);
        
        if (!isMember) return false;
        
        if (settings.allow_messages_from === 'admins_only') {
            return isAdmin;
        }
        
        return true;
    }
};

// Make globally available
window.GroupComponent = GroupComponent;