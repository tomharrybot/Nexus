// Message Component
const MessageComponent = {
    createMessageElement(message, isOutgoing, currentChat) {
        const messageEl = document.createElement('div');
        messageEl.className = `message ${isOutgoing ? 'message-outgoing' : 'message-incoming'}`;
        messageEl.dataset.messageId = message.id;
        messageEl.dataset.messageType = message.type;
        
        // Check if deleted
        if (message.deleted) {
            messageEl.classList.add('deleted');
        }
        
        // Build message HTML
        let contentHtml = '';
        
        // Reply preview if this is a reply
        if (message.reply_to) {
            contentHtml += this.renderReplyPreview(message.original_message);
        }
        
        // Forwarded badge
        if (message.forwarded) {
            contentHtml += this.renderForwardedBadge(message);
        }
        
        // Message content based on type
        contentHtml += this.renderMessageContent(message);
        
        // Reactions
        if (message.reactions && Object.keys(message.reactions).length > 0) {
            contentHtml += this.renderReactions(message.reactions);
        }
        
        // Message meta
        contentHtml += this.renderMessageMeta(message, isOutgoing);
        
        // Message actions
        if (!message.deleted) {
            contentHtml += this.renderMessageActions(message, isOutgoing);
        }
        
        messageEl.innerHTML = contentHtml;
        
        // Add event listeners
        this.addMessageEventListeners(messageEl, message);
        
        return messageEl;
    },
    
    renderReplyPreview(originalMessage) {
        if (!originalMessage) return '';
        
        return `
            <div class="message-reply-preview">
                <div class="reply-preview-sender">${originalMessage.from || 'Unknown'}</div>
                <div class="reply-preview-text">${originalMessage.message || ''}</div>
            </div>
        `;
    },
    
    renderForwardedBadge(message) {
        return `
            <div class="forwarded-badge">
                <i class="fas fa-share"></i>
                <span>Forwarded from ${message.original_from || 'Unknown'}</span>
            </div>
        `;
    },
    
    renderMessageContent(message) {
        switch (message.type) {
            case 'image':
                return `
                    <div class="message-image" onclick="MessageComponent.viewImage('${message.file?.url || message.message}')">
                        <img src="${message.file?.url || message.message}" alt="Image">
                        <div class="message-image-overlay">
                            <i class="fas fa-search-plus"></i>
                        </div>
                    </div>
                `;
                
            case 'video':
                return `
                    <div class="message-video">
                        <video controls>
                            <source src="${message.file?.url || message.message}" type="video/mp4">
                        </video>
                    </div>
                `;
                
            case 'audio':
                return `
                    <div class="message-audio">
                        <div class="audio-player">
                            <div class="audio-play-btn" onclick="MessageComponent.playAudio(this, '${message.file?.url || message.message}')">
                                <i class="fas fa-play"></i>
                            </div>
                            <div class="audio-waveform">
                                <div class="audio-waveform-progress"></div>
                                <div class="audio-waveform-bars">
                                    <span></span><span></span><span></span><span></span>
                                    <span></span><span></span><span></span><span></span>
                                </div>
                            </div>
                            <div class="audio-time">0:00</div>
                        </div>
                    </div>
                `;
                
            case 'file':
                return `
                    <div class="message-file" onclick="MessageComponent.downloadFile('${message.file?.url || message.message}')">
                        <div class="file-icon">
                            <i class="fas ${this.getFileIcon(message.file?.extension || '')}"></i>
                        </div>
                        <div class="file-info">
                            <div class="file-name">${message.file?.name || 'File'}</div>
                            <div class="file-size">${Formatters.fileSize(message.file?.size || 0)}</div>
                        </div>
                        <div class="file-download">
                            <i class="fas fa-download"></i>
                        </div>
                    </div>
                `;
                
            default:
                return `
                    <div class="message-text">${this.linkify(message.message)}</div>
                `;
        }
    },
    
    renderReactions(reactions) {
        let html = '<div class="message-reactions">';
        
        for (const [emoji, users] of Object.entries(reactions)) {
            html += `
                <div class="reaction" onclick="MessageComponent.toggleReaction('${emoji}')">
                    <span>${emoji}</span>
                    <span class="reaction-count">${users.length}</span>
                </div>
            `;
        }
        
        html += '</div>';
        return html;
    },
    
    renderMessageMeta(message, isOutgoing) {
        const time = Formatters.time(message.timestamp);
        let statusIcon = '';
        
        if (isOutgoing) {
            if (message.status === 'sent') {
                statusIcon = '<i class="fas fa-check message-status sent"></i>';
            } else if (message.status === 'delivered') {
                statusIcon = '<i class="fas fa-check-double message-status delivered"></i>';
            } else if (message.status === 'seen') {
                statusIcon = '<i class="fas fa-check-double message-status seen"></i>';
            }
        }
        
        return `
            <div class="message-meta">
                <span class="message-time">${time}</span>
                ${statusIcon}
            </div>
        `;
    },
    
    renderMessageActions(message, isOutgoing) {
        return `
            <div class="message-actions">
                <div class="message-action reply-action" onclick="ReplyFeature.setReplyMessage(${JSON.stringify(message).replace(/"/g, '&quot;')})">
                    <i class="fas fa-reply"></i>
                </div>
                <div class="message-action copy-action" onclick="CopyFeature.copyText('${message.message.replace(/'/g, "\\'")}')">
                    <i class="fas fa-copy"></i>
                </div>
                <div class="message-action forward-action" onclick="ForwardFeature.openForwardModal(${JSON.stringify(message).replace(/"/g, '&quot;')})">
                    <i class="fas fa-share"></i>
                </div>
                ${isOutgoing ? `
                    <div class="message-action delete-action" onclick="DeleteFeature.openDeleteModal('${message.id}')">
                        <i class="fas fa-trash"></i>
                    </div>
                ` : ''}
            </div>
        `;
    },
    
    addMessageEventListeners(messageEl, message) {
        // Long press for context menu (mobile)
        let longPressTimer;
        
        messageEl.addEventListener('touchstart', (e) => {
            longPressTimer = setTimeout(() => {
                this.showContextMenu(e, message);
            }, 500);
        });
        
        messageEl.addEventListener('touchend', () => {
            clearTimeout(longPressTimer);
        });
        
        messageEl.addEventListener('touchmove', () => {
            clearTimeout(longPressTimer);
        });
        
        // Right click for context menu
        messageEl.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.showContextMenu(e, message);
        });
    },
    
    showContextMenu(event, message) {
        const menu = document.createElement('div');
        menu.className = 'message-context-menu';
        menu.style.left = event.pageX + 'px';
        menu.style.top = event.pageY + 'px';
        
        menu.innerHTML = `
            <div class="context-menu-item copy-item" onclick="CopyFeature.copyText('${message.message.replace(/'/g, "\\'")}'); this.closest('.message-context-menu').remove()">
                <i class="fas fa-copy"></i>
                <span>Copy</span>
            </div>
            <div class="context-menu-item reply-item" onclick="ReplyFeature.setReplyMessage(${JSON.stringify(message).replace(/"/g, '&quot;')}); this.closest('.message-context-menu').remove()">
                <i class="fas fa-reply"></i>
                <span>Reply</span>
            </div>
            <div class="context-menu-item forward-item" onclick="ForwardFeature.openForwardModal(${JSON.stringify(message).replace(/"/g, '&quot;')}); this.closest('.message-context-menu').remove()">
                <i class="fas fa-share"></i>
                <span>Forward</span>
            </div>
            ${message.from === Storage.getUser()?.email ? `
                <div class="context-menu-item delete-item" onclick="DeleteFeature.openDeleteModal('${message.id}'); this.closest('.message-context-menu').remove()">
                    <i class="fas fa-trash"></i>
                    <span>Delete</span>
                </div>
            ` : ''}
        `;
        
        document.body.appendChild(menu);
        
        // Adjust position if off screen
        const menuRect = menu.getBoundingClientRect();
        if (menuRect.right > window.innerWidth) {
            menu.style.left = (window.innerWidth - menuRect.width - 10) + 'px';
        }
        if (menuRect.bottom > window.innerHeight) {
            menu.style.top = (window.innerHeight - menuRect.height - 10) + 'px';
        }
        
        // Close on click outside
        setTimeout(() => {
            document.addEventListener('click', function closeMenu() {
                menu.remove();
                document.removeEventListener('click', closeMenu);
            });
        }, 10);
    },
    
    viewImage(url) {
        const viewer = document.createElement('div');
        viewer.className = 'image-viewer';
        viewer.innerHTML = `
            <div class="image-viewer-overlay"></div>
            <div class="image-viewer-content">
                <img src="${url}" alt="Full size">
                <button class="image-viewer-close" onclick="this.closest('.image-viewer').remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(viewer);
        setTimeout(() => viewer.classList.add('active'), 10);
    },
    
    playAudio(btn, url) {
        const audio = new Audio(url);
        const player = btn.closest('.audio-player');
        const progressFill = player.querySelector('.audio-waveform-progress');
        const timeDisplay = player.querySelector('.audio-time');
        
        audio.addEventListener('timeupdate', () => {
            const progress = (audio.currentTime / audio.duration) * 100;
            progressFill.style.width = progress + '%';
            timeDisplay.textContent = Formatters.duration(audio.currentTime);
        });
        
        if (btn.classList.contains('playing')) {
            audio.pause();
            btn.classList.remove('playing');
            btn.innerHTML = '<i class="fas fa-play"></i>';
        } else {
            audio.play();
            btn.classList.add('playing');
            btn.innerHTML = '<i class="fas fa-pause"></i>';
        }
        
        audio.addEventListener('ended', () => {
            btn.classList.remove('playing');
            btn.innerHTML = '<i class="fas fa-play"></i>';
            progressFill.style.width = '0%';
            timeDisplay.textContent = '0:00';
        });
    },
    
    downloadFile(url) {
        const a = document.createElement('a');
        a.href = url;
        a.download = url.split('/').pop();
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    },
    
    toggleReaction(emoji) {
        // Implementation in chat.js
        console.log('Toggle reaction:', emoji);
    },
    
    getFileIcon(extension) {
        const icons = {
            'pdf': 'fa-file-pdf',
            'doc': 'fa-file-word',
            'docx': 'fa-file-word',
            'xls': 'fa-file-excel',
            'xlsx': 'fa-file-excel',
            'ppt': 'fa-file-powerpoint',
            'pptx': 'fa-file-powerpoint',
            'txt': 'fa-file-alt',
            'jpg': 'fa-file-image',
            'jpeg': 'fa-file-image',
            'png': 'fa-file-image',
            'gif': 'fa-file-image',
            'mp4': 'fa-file-video',
            'mp3': 'fa-file-audio'
        };
        
        return icons[extension] || 'fa-file';
    },
    
    linkify(text) {
        const urlRegex = /(https?:\/\/[^\s]+)/g;
        return text.replace(urlRegex, '<a href="$1" target="_blank" class="message-link">$1</a>');
    }
};

window.MessageComponent = MessageComponent;