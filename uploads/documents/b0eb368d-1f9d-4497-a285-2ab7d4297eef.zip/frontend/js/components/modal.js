// Modal Component
const ModalComponent = {
    // Current active modal
    currentModal: null,
    
    // Create modal container
    createModal(options = {}) {
        const {
            title = '',
            content = '',
            size = 'medium',
            showClose = true,
            closeOnClickOutside = true,
            onClose = null
        } = options;
        
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = `modal-${Date.now()}`;
        
        const sizeClass = {
            small: 'modal-small',
            medium: 'modal-medium',
            large: 'modal-large',
            full: 'modal-full'
        }[size] || 'modal-medium';
        
        modal.innerHTML = `
            <div class="modal-content ${sizeClass}">
                <div class="modal-header">
                    <h2>${title}</h2>
                    ${showClose ? '<span class="close">&times;</span>' : ''}
                </div>
                <div class="modal-body">
                    ${content}
                </div>
            </div>
        `;
        
        // Add close button handler
        if (showClose) {
            const closeBtn = modal.querySelector('.close');
            closeBtn.addEventListener('click', () => {
                this.closeModal(modal, onClose);
            });
        }
        
        // Click outside to close
        if (closeOnClickOutside) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal(modal, onClose);
                }
            });
        }
        
        // ESC key to close
        const escHandler = (e) => {
            if (e.key === 'Escape') {
                this.closeModal(modal, onClose);
                document.removeEventListener('keydown', escHandler);
            }
        };
        document.addEventListener('keydown', escHandler);
        
        return modal;
    },
    
    // Show modal
    showModal(options = {}) {
        const modal = this.createModal(options);
        document.body.appendChild(modal);
        
        // Trigger reflow for animation
        setTimeout(() => {
            modal.classList.add('active');
        }, 10);
        
        this.currentModal = modal;
        return modal;
    },
    
    // Close modal
    closeModal(modal, onClose) {
        if (!modal) return;
        
        modal.classList.remove('active');
        
        setTimeout(() => {
            if (modal.parentNode) {
                modal.parentNode.removeChild(modal);
            }
            if (onClose) onClose();
        }, 300);
        
        if (this.currentModal === modal) {
            this.currentModal = null;
        }
    },
    
    // Close current modal
    closeCurrentModal() {
        if (this.currentModal) {
            this.closeModal(this.currentModal);
        }
    },
    
    // Alert modal
    alert(message, title = 'Alert') {
        return this.showModal({
            title,
            content: `
                <div class="alert-content">
                    <p>${message}</p>
                    <button class="nexus-btn nexus-btn-primary alert-ok">OK</button>
                </div>
            `,
            showClose: false,
            onClose: (modal) => {
                modal.querySelector('.alert-ok')?.removeEventListener('click', handler);
            }
        }).then(modal => {
            const handler = () => this.closeModal(modal);
            modal.querySelector('.alert-ok').addEventListener('click', handler);
            return modal;
        });
    },
    
    // Confirm modal
    confirm(message, title = 'Confirm', onConfirm, onCancel) {
        const modal = this.showModal({
            title,
            content: `
                <div class="confirm-content">
                    <p>${message}</p>
                    <div class="confirm-actions">
                        <button class="nexus-btn nexus-btn-secondary confirm-cancel">Cancel</button>
                        <button class="nexus-btn nexus-btn-primary confirm-ok">OK</button>
                    </div>
                </div>
            `,
            showClose: false
        });
        
        modal.querySelector('.confirm-ok').addEventListener('click', () => {
            this.closeModal(modal);
            if (onConfirm) onConfirm();
        });
        
        modal.querySelector('.confirm-cancel').addEventListener('click', () => {
            this.closeModal(modal);
            if (onCancel) onCancel();
        });
        
        return modal;
    },
    
    // Prompt modal
    prompt(message, title = 'Input', defaultValue = '', onConfirm, onCancel) {
        const modal = this.showModal({
            title,
            content: `
                <div class="prompt-content">
                    <p>${message}</p>
                    <input type="text" class="nexus-input prompt-input" value="${defaultValue}">
                    <div class="prompt-actions">
                        <button class="nexus-btn nexus-btn-secondary prompt-cancel">Cancel</button>
                        <button class="nexus-btn nexus-btn-primary prompt-ok">OK</button>
                    </div>
                </div>
            `,
            showClose: false
        });
        
        const input = modal.querySelector('.prompt-input');
        input.focus();
        
        modal.querySelector('.prompt-ok').addEventListener('click', () => {
            this.closeModal(modal);
            if (onConfirm) onConfirm(input.value);
        });
        
        modal.querySelector('.prompt-cancel').addEventListener('click', () => {
            this.closeModal(modal);
            if (onCancel) onCancel();
        });
        
        // Enter key to submit
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.closeModal(modal);
                if (onConfirm) onConfirm(input.value);
            }
        });
        
        return modal;
    },
    
    // Loading modal
    loading(message = 'Loading...') {
        return this.showModal({
            title: '',
            content: `
                <div class="loading-content">
                    <div class="loading-spinner"></div>
                    <p>${message}</p>
                </div>
            `,
            showClose: false,
            closeOnClickOutside: false
        });
    },
    
    // Profile view modal
    showProfile(user) {
        return this.showModal({
            title: 'Profile',
            content: `
                <div class="profile-view">
                    <div class="profile-avatar-container">
                        <img src="${user.avatar || '/assets/images/default-avatar.svg'}" 
                             class="profile-avatar-large">
                        <span class="status-indicator-large ${user.online ? '' : 'offline'}"></span>
                    </div>
                    <h3>${user.name}</h3>
                    <p class="profile-about">${user.about || 'No bio available'}</p>
                    <p class="profile-email">${user.email}</p>
                    <p class="profile-userid">${user.userId || 'NX-0000-0000-0000'}</p>
                    <p class="profile-lastseen">${user.online ? 'Online' : Formatters.lastSeen(user.lastSeen)}</p>
                    <div class="profile-actions">
                        <button class="nexus-btn nexus-btn-primary message-user">
                            <i class="fas fa-comment"></i> Message
                        </button>
                    </div>
                </div>
            `
        }).then(modal => {
            modal.querySelector('.message-user').addEventListener('click', () => {
                this.closeModal(modal);
                if (window.openChatWithEmail) {
                    window.openChatWithEmail(user.email);
                }
            });
            return modal;
        });
    },
    
    // Media preview modal
    showMedia(url, type = 'image') {
        const content = type === 'video' 
            ? `<video src="${url}" controls autoplay class="media-preview"></video>`
            : `<img src="${url}" class="media-preview" alt="Preview">`;
        
        return this.showModal({
            title: '',
            content: `<div class="media-preview-container">${content}</div>`,
            size: 'large'
        });
    },
    
    // Create group modal
    showCreateGroup(contacts, onCreate) {
        let selectedMembers = [];
        
        const content = `
            <div class="create-group">
                <div class="group-avatar-section">
                    <img src="/assets/images/group-avatar.svg" class="group-avatar-large" id="group-avatar-preview">
                    <button class="change-avatar-btn" id="change-group-avatar">
                        <i class="fas fa-camera"></i>
                    </button>
                    <input type="file" id="group-avatar-upload" accept="image/*" style="display: none;">
                </div>
                
                <div class="form-group">
                    <label>Group Name</label>
                    <input type="text" id="group-name" class="nexus-input" placeholder="Enter group name">
                </div>
                
                <div class="form-group">
                    <label>Select Members</label>
                    <input type="text" id="member-search" class="nexus-input" placeholder="Search contacts...">
                </div>
                
                <div class="members-list" id="members-list"></div>
                <div class="selected-members" id="selected-members"></div>
                
                <div class="form-actions">
                    <button class="nexus-btn nexus-btn-primary" id="create-group-btn" disabled>Create Group</button>
                </div>
            </div>
        `;
        
        const modal = this.showModal({
            title: 'Create New Group',
            content,
            size: 'medium'
        });
        
        // Initialize component
        this.initCreateGroup(modal, contacts, (groupData) => {
            this.closeModal(modal);
            if (onCreate) onCreate(groupData);
        }, selectedMembers);
        
        return modal;
    },
    
    // Initialize create group modal
    initCreateGroup(modal, contacts, onCreate, selectedMembers) {
        const avatarPreview = modal.querySelector('#group-avatar-preview');
        const avatarUpload = modal.querySelector('#group-avatar-upload');
        const groupName = modal.querySelector('#group-name');
        const memberSearch = modal.querySelector('#member-search');
        const membersList = modal.querySelector('#members-list');
        const selectedContainer = modal.querySelector('#selected-members');
        const createBtn = modal.querySelector('#create-group-btn');
        
        // Avatar upload
        modal.querySelector('#change-group-avatar').addEventListener('click', () => {
            avatarUpload.click();
        });
        
        avatarUpload.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    avatarPreview.src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
        
        // Render members
        const renderMembers = (filter = '') => {
            const filtered = contacts.filter(c => 
                c.name.toLowerCase().includes(filter.toLowerCase()) ||
                c.email.toLowerCase().includes(filter.toLowerCase())
            );
            
            membersList.innerHTML = '';
            filtered.forEach(contact => {
                const memberEl = ContactComponent.createMemberContact(
                    contact,
                    (contact, checked) => {
                        if (checked) {
                            selectedMembers.push(contact);
                            this.addSelectedMember(selectedContainer, contact, (email) => {
                                selectedMembers = selectedMembers.filter(m => m.email !== email);
                                this.updateCreateGroupButton(createBtn, groupName, selectedMembers);
                            });
                        } else {
                            selectedMembers = selectedMembers.filter(m => m.email !== contact.email);
                            this.removeSelectedMember(selectedContainer, contact.email);
                        }
                        this.updateCreateGroupButton(createBtn, groupName, selectedMembers);
                    }
                );
                membersList.appendChild(memberEl);
            });
        };
        
        renderMembers();
        
        memberSearch.addEventListener('input', (e) => {
            renderMembers(e.target.value);
        });
        
        groupName.addEventListener('input', () => {
            this.updateCreateGroupButton(createBtn, groupName, selectedMembers);
        });
        
        createBtn.addEventListener('click', () => {
            onCreate({
                name: groupName.value,
                avatar: avatarPreview.src,
                members: selectedMembers.map(m => m.email)
            });
        });
    },
    
    addSelectedMember(container, contact, onRemove) {
        const badge = ContactComponent.createSelectedMember(contact, (email) => {
            if (onRemove) onRemove(email);
        });
        container.appendChild(badge);
    },
    
    removeSelectedMember(container, email) {
        const badge = container.querySelector(`[data-email="${email}"]`);
        if (badge) badge.remove();
    },
    
    updateCreateGroupButton(btn, nameInput, selectedMembers) {
        btn.disabled = !nameInput.value || selectedMembers.length === 0;
    }
};

// Make globally available
window.ModalComponent = ModalComponent;