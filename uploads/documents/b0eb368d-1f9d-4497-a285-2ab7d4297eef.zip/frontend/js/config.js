// Frontend Configuration
const CONFIG = {
    // Server URL
    SERVER_URL: window.location.origin,
    SOCKET_URL: window.location.origin,
    
    // API Endpoints
    API: {
        AUTH: {
            SEND_OTP: '/auth/send-otp',
            VERIFY_OTP: '/auth/verify-otp'
        },
        USERS: {
            GET: '/users',
            PROFILE: '/users/profile',
            SETTINGS: '/users/settings',
            STATUS: '/users/status'
        },
        CHATS: {
            GET: '/chats/get',
            SEND: '/chats/send',
            DELETE: '/chats/delete',
            FORWARD: '/chats/forward'
        },
        CONTACTS: {
            GET: '/contacts',
            ADD: '/contacts/add',
            DELETE: '/contacts/delete'
        },
        GROUPS: {
            CREATE: '/groups/create',
            SEND: '/groups/send',
            GET: '/groups/user'
        },
        MEDIA: {
            UPLOAD: '/media/upload'
        },
        PRIVACY: {
            GET: '/privacy/settings',
            UPDATE: '/privacy/settings/update',
            BLOCK: '/privacy/block',
            UNBLOCK: '/privacy/unblock',
            BLOCKED: '/privacy/blocked'
        },
        SECURITY: {
            GET: '/security/settings',
            UPDATE: '/security/settings/update',
            SESSIONS: '/security/sessions',
            PASSWORD: '/security/password'
        },
        SUPPORT: {
            TICKETS: '/support/tickets',
            FAQ: '/support/faq',
            CONTACT: '/support/contact'
        }
    },
    
    // File Upload Limits
    UPLOAD_LIMITS: {
        image: 10 * 1024 * 1024,  // 10MB
        video: 50 * 1024 * 1024,   // 50MB
        audio: 20 * 1024 * 1024,   // 20MB
        document: 25 * 1024 * 1024 // 25MB
    },
    
    // Allowed file types
    ALLOWED_TYPES: {
        image: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
        video: ['video/mp4', 'video/webm', 'video/ogg'],
        audio: ['audio/mpeg', 'audio/wav', 'audio/ogg'],
        document: ['application/pdf', 'application/msword', 
                   'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                   'text/plain']
    },
    
    // Pagination
    PAGINATION: {
        messagesPerPage: 50,
        contactsPerPage: 50,
        notificationsPerPage: 30
    },
    
    // Timeouts
    TIMEOUTS: {
        typing: 1000,        // Stop typing after 1 second
        statusCheck: 30000,  // Check status every 30 seconds
        reconnection: 5000    // Reconnect after 5 seconds
    },
    
    // Feature flags
    FEATURES: {
        voiceMessages: true,
        videoCalls: false,    // Coming soon
        screenSharing: false, // Coming soon
        endToEndEncryption: true
    },
    
    // Default settings
    DEFAULTS: {
        theme: 'cosmic',
        notifications: true,
        sound: true,
        vibration: true,
        privacy: {
            last_seen: 'everyone',
            profile_photo: 'everyone',
            about: 'everyone',
            groups: 'everyone',
            read_receipts: true,
            typing_indicator: true
        }
    },
    
    // Debug mode
    DEBUG: true
};

// Log in development
if (CONFIG.DEBUG) {
    console.log('Nexus Chat Config Loaded', CONFIG);
}

// Freeze config to prevent modifications
Object.freeze(CONFIG);