// Voice Message Feature
const VoiceFeature = (function() {
    let mediaRecorder = null;
    let audioChunks = [];
    let recordingTimer = null;
    let recordingStartTime = 0;
    let isRecording = false;
    
    // DOM elements
    let recordingContainer = null;
    let timerElement = null;
    
    // Initialize voice feature
    function init() {
        createRecordingUI();
        setupMicButton();
    }
    
    // Create recording UI
    function createRecordingUI() {
        if (document.getElementById('voice-recording')) return;
        
        recordingContainer = document.createElement('div');
        recordingContainer.id = 'voice-recording';
        recordingContainer.className = 'voice-recording-container';
        recordingContainer.style.display = 'none';
        recordingContainer.innerHTML = `
            <div class="voice-timer" id="voice-timer">0:00</div>
            <div class="voice-wave">
                <div class="voice-wave-bar"></div>
                <div class="voice-wave-bar"></div>
                <div class="voice-wave-bar"></div>
                <div class="voice-wave-bar"></div>
                <div class="voice-wave-bar"></div>
                <div class="voice-wave-bar"></div>
                <div class="voice-wave-bar"></div>
            </div>
            <div class="voice-actions">
                <div class="voice-action-btn cancel" onclick="VoiceFeature.cancelRecording()">
                    <i class="fas fa-times"></i>
                </div>
                <div class="voice-action-btn send" onclick="VoiceFeature.sendRecording()">
                    <i class="fas fa-check"></i>
                </div>
            </div>
        `;
        
        document.body.appendChild(recordingContainer);
        timerElement = document.getElementById('voice-timer');
    }
    
    // Setup microphone button
    function setupMicButton() {
        const micBtn = document.querySelector('.send-button');
        if (micBtn) {
            // Replace with mic when input empty
            const messageInput = document.getElementById('message-input');
            messageInput.addEventListener('input', () => {
                if (messageInput.value.trim()) {
                    micBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
                } else {
                    micBtn.innerHTML = '<i class="fas fa-microphone"></i>';
                }
            });
            
            // Handle mic click
            micBtn.addEventListener('click', () => {
                if (!messageInput.value.trim()) {
                    startRecording();
                }
            });
        }
    }
    
    // Start recording
    async function startRecording() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            mediaRecorder = new MediaRecorder(stream);
            audioChunks = [];
            
            mediaRecorder.ondataavailable = (event) => {
                audioChunks.push(event.data);
            };
            
            mediaRecorder.onstop = () => {
                const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                // Handle the recorded audio
                handleRecordedAudio(audioBlob);
                
                // Stop all tracks
                stream.getTracks().forEach(track => track.stop());
            };
            
            mediaRecorder.start();
            isRecording = true;
            recordingStartTime = Date.now();
            
            // Show recording UI
            if (recordingContainer) {
                recordingContainer.style.display = 'flex';
            }
            
            // Start timer
            startTimer();
            
        } catch (error) {
            console.error('Error accessing microphone:', error);
            window.showToast?.('Microphone access denied', 'error');
        }
    }
    
    // Start timer
    function startTimer() {
        if (recordingTimer) clearInterval(recordingTimer);
        
        recordingTimer = setInterval(() => {
            const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;
            
            if (timerElement) {
                timerElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
            }
            
            // Auto-stop after 5 minutes
            if (elapsed >= 300) {
                stopRecording();
            }
        }, 1000);
    }
    
    // Stop recording
    function stopRecording() {
        if (mediaRecorder && isRecording) {
            mediaRecorder.stop();
            isRecording = false;
            
            if (recordingTimer) {
                clearInterval(recordingTimer);
                recordingTimer = null;
            }
            
            if (recordingContainer) {
                recordingContainer.style.display = 'none';
            }
            
            if (timerElement) {
                timerElement.textContent = '0:00';
            }
        }
    }
    
    // Cancel recording
    function cancelRecording() {
        stopRecording();
        audioChunks = [];
        window.showToast?.('Recording cancelled', 'info');
    }
    
    // Send recording
    function sendRecording() {
        stopRecording();
        // The audio will be handled in onstop
    }
    
    // Handle recorded audio
    async function handleRecordedAudio(audioBlob) {
        if (audioBlob.size === 0) return;
        
        try {
            // Create form data
            const formData = new FormData();
            formData.append('file', audioBlob, 'voice-message.webm');
            formData.append('type', 'audio');
            
            // Upload audio
            const uploadResponse = await fetch('/media/upload', {
                method: 'POST',
                body: formData
            });
            
            const uploadData = await uploadResponse.json();
            
            if (uploadData.status === 'ok') {
                // Send as message
                const messageInput = document.getElementById('message-input');
                const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
                
                const messageResponse = await fetch('/chats/send', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        from_email: currentUser.email,
                        to_email: window.currentChat?.email,
                        message: uploadData.url,
                        type: 'audio'
                    })
                });
                
                const messageData = await messageResponse.json();
                
                if (messageData.status === 'ok') {
                    window.showToast?.('Voice message sent', 'success');
                }
            }
            
        } catch (error) {
            console.error('Error sending voice message:', error);
            window.showToast?.('Failed to send voice message', 'error');
        }
    }
    
    // Public API
    return {
        init,
        startRecording,
        stopRecording,
        cancelRecording,
        sendRecording
    };
})();

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    VoiceFeature.init();
});

// Make globally available
window.VoiceFeature = VoiceFeature;