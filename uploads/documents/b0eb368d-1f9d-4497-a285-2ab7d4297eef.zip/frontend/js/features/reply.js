// Reply Feature Module
const ReplyFeature = (function() {
    let currentReplyMessage = null;
    let swipeTimeout = null;
    let swipeStartX = 0;
    
    // Initialize reply feature
    function init() {
        setupSwipeToReply();
        setupReplyUI();
    }
    
    // Setup swipe to reply
    function setupSwipeToReply() {
        const messagesContainer = document.getElementById('messages-container');
        
        messagesContainer.addEventListener('touchstart', (e) => {
            const messageEl = e.target.closest('.message');
            if (!messageEl) return;
            
            swipeStartX = e.touches[0].clientX;
            messageEl.classList.add('swipeable-message');
        });
        
        messagesContainer.addEventListener('touchmove', (e) => {
            if (swipeStartX === 0) return;
            
            const messageEl = e.target.closest('.message');
            if (!messageEl) return;
            
            const currentX = e.touches[0].clientX;
            const diff = currentX - swipeStartX;
            
            if (diff > 30) { // Swipe right
                e.preventDefault();
                messageEl.classList.add('swiping');
                
                // Clear previous timeout
                if (swipeTimeout) clearTimeout(swipeTimeout);
                
                // Set timeout to trigger reply
                swipeTimeout = setTimeout(() => {
                    const messageId = messageEl.dataset.messageId;
                    const messageData = getMessageById(messageId);
                    if (messageData) {
                        setReplyMessage(messageData);
                        messageEl.classList.remove('swiping');
                    }
                }, 300);
            }
        });
        
        messagesContainer.addEventListener('touchend', () => {
            const messageEl = document.querySelector('.message.swiping');
            if (messageEl) {
                messageEl.classList.remove('swiping');
            }
            swipeStartX = 0;
            if (swipeTimeout) clearTimeout(swipeTimeout);
        });
    }
    
    // Setup reply UI
    function setupReplyUI() {
        // Create reply indicator if not exists
        if (!document.getElementById('reply-indicator')) {
            const replyIndicator = document.createElement('div');
            replyIndicator.id = 'reply-indicator';
            replyIndicator.className = 'reply-indicator';
            replyIndicator.innerHTML = `
                <i class="fas fa-reply"></i>
                <span id="reply-text">Replying to message...</span>
                <i class="fas fa-times close-reply" onclick="ReplyFeature.clearReply()"></i>
            `;
            replyIndicator.style.display = 'none';
            
            const messageInput = document.querySelector('.message-input-container');
            if (messageInput) {
                messageInput.parentNode.insertBefore(replyIndicator, messageInput);
            }
        }
    }
    
    // Set reply message
    function setReplyMessage(message) {
        currentReplyMessage = message;
        
        const replyIndicator = document.getElementById('reply-indicator');
        const replyText = document.getElementById('reply-text');
        
        if (replyIndicator && replyText) {
            let previewText = message.message;
            if (message.type === 'image') previewText = '📷 Photo';
            else if (message.type === 'video') previewText = '🎥 Video';
            else if (message.type === 'audio') previewText = '🎵 Voice message';
            else if (message.type === 'file') previewText = '📄 File';
            
            replyText.textContent = `Replying to: ${previewText.substring(0, 30)}${previewText.length > 30 ? '...' : ''}`;
            replyIndicator.style.display = 'flex';
        }
        
        // Focus on input
        const messageInput = document.getElementById('message-input');
        if (messageInput) messageInput.focus();
    }
    
    // Clear reply
    function clearReply() {
        currentReplyMessage = null;
        
        const replyIndicator = document.getElementById('reply-indicator');
        if (replyIndicator) {
            replyIndicator.style.display = 'none';
        }
    }
    
    // Get current reply
    function getCurrentReply() {
        return currentReplyMessage;
    }
    
    // Get message by ID (helper)
    function getMessageById(messageId) {
        // This would need access to messages data
        // For now, return null and let implementation handle
        return null;
    }
    
    // Public API
    return {
        init,
        setReplyMessage,
        clearReply,
        getCurrentReply
    };
})();

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    ReplyFeature.init();
});

// Make globally available
window.ReplyFeature = ReplyFeature;