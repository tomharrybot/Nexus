// Support/Help Feature
const SupportFeature = (function() {
    let supportModal = null;
    let currentTicket = null;
    
    function init() {
        createSupportModal();
        loadFAQ();
    }
    
    function createSupportModal() {
        if (document.getElementById('support-modal')) return;
        
        supportModal = document.createElement('div');
        supportModal.id = 'support-modal';
        supportModal.className = 'modal';
        supportModal.innerHTML = `
            <div class="modal-content support-modal">
                <div class="modal-header">
                    <h2>Help & Support</h2>
                    <span class="close" onclick="SupportFeature.closeModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="support-tabs">
                        <button class="support-tab active" onclick="SupportFeature.switchTab('faq')">FAQ</button>
                        <button class="support-tab" onclick="SupportFeature.switchTab('tickets')">My Tickets</button>
                        <button class="support-tab" onclick="SupportFeature.switchTab('new')">New Ticket</button>
                    </div>
                    
                    <div id="support-faq" class="support-tab-content active">
                        <div class="faq-list" id="faq-list">
                            <!-- FAQ items will be loaded here -->
                        </div>
                    </div>
                    
                    <div id="support-tickets" class="support-tab-content">
                        <div class="tickets-list" id="tickets-list">
                            <!-- Tickets will be loaded here -->
                        </div>
                    </div>
                    
                    <div id="support-new" class="support-tab-content">
                        <form id="ticket-form">
                            <select id="ticket-category" class="nexus-input">
                                <option value="">Select Category</option>
                                <option value="bug">Bug Report</option>
                                <option value="feature">Feature Request</option>
                                <option value="question">Question</option>
                                <option value="other">Other</option>
                            </select>
                            
                            <input type="text" id="ticket-subject" class="nexus-input" placeholder="Subject">
                            
                            <textarea id="ticket-message" class="nexus-input" placeholder="Describe your issue..." rows="5"></textarea>
                            
                            <div class="ticket-attachments">
                                <label for="ticket-attachment" class="attachment-label">
                                    <i class="fas fa-paperclip"></i> Add Attachment
                                </label>
                                <input type="file" id="ticket-attachment" style="display: none;" multiple>
                            </div>
                            
                            <button type="button" class="nexus-button" onclick="SupportFeature.submitTicket()">
                                Submit Ticket
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(supportModal);
    }
    
    function switchTab(tab) {
        // Update tabs
        document.querySelectorAll('.support-tab').forEach(t => t.classList.remove('active'));
        document.querySelector(`.support-tab[onclick*="${tab}"]`)?.classList.add('active');
        
        // Update content
        document.querySelectorAll('.support-tab-content').forEach(c => c.classList.remove('active'));
        document.getElementById(`support-${tab}`)?.classList.add('active');
        
        // Load data if needed
        if (tab === 'faq') loadFAQ();
        if (tab === 'tickets') loadUserTickets();
    }
    
    async function loadFAQ() {
        const container = document.getElementById('faq-list');
        if (!container) return;
        
        try {
            const response = await fetch('/support/faq');
            const faq = await response.json();
            
            container.innerHTML = '';
            
            faq.forEach(item => {
                const faqItem = document.createElement('div');
                faqItem.className = 'faq-item';
                faqItem.innerHTML = `
                    <div class="faq-question" onclick="this.nextElementSibling.classList.toggle('active')">
                        <span>${item.question}</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        ${item.answer}
                    </div>
                `;
                container.appendChild(faqItem);
            });
        } catch (error) {
            console.error('Error loading FAQ:', error);
            container.innerHTML = '<div class="error">Failed to load FAQ</div>';
        }
    }
    
    async function loadUserTickets() {
        const container = document.getElementById('tickets-list');
        if (!container) return;
        
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await fetch(`/support/tickets/${user.email}`);
            const tickets = await response.json();
            
            if (tickets.length === 0) {
                container.innerHTML = '<div class="no-tickets">No support tickets found</div>';
                return;
            }
            
            container.innerHTML = '';
            
            tickets.sort((a, b) => b.created_at - a.created_at).forEach(ticket => {
                const ticketEl = document.createElement('div');
                ticketEl.className = 'ticket-item';
                ticketEl.innerHTML = `
                    <div class="ticket-header">
                        <span class="ticket-id">#${ticket.id}</span>
                        <span class="ticket-status ${ticket.status}">${ticket.status}</span>
                    </div>
                    <div class="ticket-subject">${ticket.subject}</div>
                    <div class="ticket-category">${ticket.category}</div>
                    <div class="ticket-date">${new Date(ticket.created_at * 1000).toLocaleDateString()}</div>
                    <button class="view-ticket" onclick="SupportFeature.viewTicket('${ticket.id}')">
                        View Details
                    </button>
                `;
                container.appendChild(ticketEl);
            });
        } catch (error) {
            console.error('Error loading tickets:', error);
            container.innerHTML = '<div class="error">Failed to load tickets</div>';
        }
    }
    
    async function submitTicket() {
        const category = document.getElementById('ticket-category')?.value;
        const subject = document.getElementById('ticket-subject')?.value;
        const message = document.getElementById('ticket-message')?.value;
        
        if (!category || !subject || !message) {
            Toast.show('Please fill all fields', 'error');
            return;
        }
        
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await fetch('/support/ticket/create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: user.email,
                    category,
                    subject,
                    message
                })
            });
            
            const data = await response.json();
            
            if (data.status === 'ok') {
                Toast.show('Ticket created successfully', 'success');
                
                // Reset form
                document.getElementById('ticket-category').value = '';
                document.getElementById('ticket-subject').value = '';
                document.getElementById('ticket-message').value = '';
                
                // Switch to tickets tab
                switchTab('tickets');
            } else {
                Toast.show(data.message, 'error');
            }
        } catch (error) {
            console.error('Error creating ticket:', error);
            Toast.show('Failed to create ticket', 'error');
        }
    }
    
    async function viewTicket(ticketId) {
        try {
            const response = await fetch(`/support/ticket/${ticketId}`);
            const ticket = await response.json();
            
            currentTicket = ticket;
            
            // Create ticket detail modal
            const detailModal = document.createElement('div');
            detailModal.className = 'modal';
            detailModal.id = 'ticket-detail-modal';
            detailModal.innerHTML = `
                <div class="modal-content ticket-detail-modal">
                    <div class="modal-header">
                        <h3>Ticket #${ticket.id}</h3>
                        <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="ticket-info">
                            <div class="ticket-status ${ticket.status}">${ticket.status}</div>
                            <div class="ticket-category">${ticket.category}</div>
                            <div class="ticket-subject">${ticket.subject}</div>
                            <div class="ticket-message">${ticket.message}</div>
                            <div class="ticket-date">Created: ${new Date(ticket.created_at * 1000).toLocaleString()}</div>
                        </div>
                        
                        <div class="ticket-responses">
                            <h4>Responses</h4>
                            ${ticket.responses?.map(r => `
                                <div class="ticket-response">
                                    <div class="response-message">${r.message}</div>
                                    <div class="response-meta">
                                        ${r.user_email} • ${new Date(r.timestamp * 1000).toLocaleString()}
                                    </div>
                                </div>
                            `).join('') || '<p>No responses yet</p>'}
                        </div>
                        
                        <div class="ticket-reply">
                            <textarea id="ticket-reply-message" class="nexus-input" placeholder="Type your reply..." rows="3"></textarea>
                            <button class="nexus-button" onclick="SupportFeature.replyToTicket()">
                                Send Reply
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(detailModal);
            setTimeout(() => detailModal.classList.add('active'), 10);
        } catch (error) {
            console.error('Error loading ticket:', error);
            Toast.show('Failed to load ticket', 'error');
        }
    }
    
    async function replyToTicket() {
        if (!currentTicket) return;
        
        const message = document.getElementById('ticket-reply-message')?.value;
        if (!message) {
            Toast.show('Please enter a message', 'error');
            return;
        }
        
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await fetch('/support/ticket/respond', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ticket_id: currentTicket.id,
                    user_email: user.email,
                    message
                })
            });
            
            const data = await response.json();
            
            if (data.status === 'ok') {
                Toast.show('Reply sent', 'success');
                document.getElementById('ticket-detail-modal')?.remove();
            } else {
                Toast.show(data.message, 'error');
            }
        } catch (error) {
            console.error('Error replying to ticket:', error);
            Toast.show('Failed to send reply', 'error');
        }
    }
    
    function openModal() {
        if (supportModal) {
            supportModal.classList.add('active');
            switchTab('faq');
        }
    }
    
    function closeModal() {
        if (supportModal) {
            supportModal.classList.remove('active');
        }
    }
    
    return {
        init,
        openModal,
        closeModal,
        switchTab,
        submitTicket,
        viewTicket,
        replyToTicket
    };
})();

// Initialize
document.addEventListener('DOMContentLoaded', () => SupportFeature.init());
window.SupportFeature = SupportFeature;