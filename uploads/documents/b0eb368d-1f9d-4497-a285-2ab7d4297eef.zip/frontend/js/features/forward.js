// Forward Feature Module
const ForwardFeature = (function() {
    let currentForwardMessage = null;
    let forwardModal = null;
    let selectedContacts = [];
    
    // Initialize forward feature
    function init() {
        createForwardModal();
        setupEventListeners();
    }
    
    // Create forward modal
    function createForwardModal() {
        if (document.getElementById('forward-modal')) return;
        
        forwardModal = document.createElement('div');
        forwardModal.id = 'forward-modal';
        forwardModal.className = 'modal';
        forwardModal.innerHTML = `
            <div class="modal-content forward-modal">
                <div class="forward-header">
                    <h3>Forward Message</h3>
                    <p>Select contacts to forward to</p>
                </div>
                <div class="forward-contacts" id="forward-contacts-list">
                    <!-- Contacts will be loaded here -->
                </div>
                <div class="forward-actions">
                    <button class="forward-btn" id="forward-submit-btn" disabled>Forward (0)</button>
                    <button class="cancel-btn" onclick="ForwardFeature.closeModal()">Cancel</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(forwardModal);
        
        // Add click outside to close
        forwardModal.addEventListener('click', (e) => {
            if (e.target === forwardModal) {
                closeModal();
            }
        });
    }
    
    // Setup event listeners
    function setupEventListeners() {
        // Forward submit button
        const submitBtn = document.getElementById('forward-submit-btn');
        if (submitBtn) {
            submitBtn.addEventListener('click', () => {
                forwardToSelected();
            });
        }
    }
    
    // Open forward modal
    function openForwardModal(message) {
        currentForwardMessage = message;
        selectedContacts = [];
        
        // Load contacts
        loadContactsForForward();
        
        // Show modal
        if (forwardModal) {
            forwardModal.classList.add('active');
        }
        
        // Update button
        updateForwardButton();
    }
    
    // Close modal
    function closeModal() {
        if (forwardModal) {
            forwardModal.classList.remove('active');
        }
        currentForwardMessage = null;
        selectedContacts = [];
    }
    
    // Load contacts for forwarding
    async function loadContactsForForward() {
        const contactsList = document.getElementById('forward-contacts-list');
        if (!contactsList) return;
        
        contactsList.innerHTML = '<div class="loading">Loading contacts...</div>';
        
        try {
            // Get current user
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            if (!currentUser.email) return;
            
            // Fetch contacts
            const response = await fetch(`/contacts/${currentUser.email}`);
            const contacts = await response.json();
            
            if (contacts.length === 0) {
                contactsList.innerHTML = '<div class="no-contacts">No contacts to forward to</div>';
                return;
            }
            
            contactsList.innerHTML = '';
            
            contacts.forEach(contact => {
                const contactEl = document.createElement('div');
                contactEl.className = 'forward-contact';
                contactEl.dataset.email = contact.email;
                
                contactEl.innerHTML = `
                    <img src="${contact.avatar || 'data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27%23ffffff%27%3E%3Cpath d=%27M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-6.627 0-12 5.373-12 12h24c0-6.627-5.373-12-12-12z%27/%3E%3C/svg%3E'}" class="forward-contact-avatar">
                    <div class="forward-contact-info">
                        <div class="forward-contact-name">${contact.name}</div>
                        <div class="forward-contact-email">${contact.email}</div>
                    </div>
                    <input type="checkbox" class="forward-contact-checkbox">
                `;
                
                const checkbox = contactEl.querySelector('.forward-contact-checkbox');
                checkbox.addEventListener('change', (e) => {
                    if (e.target.checked) {
                        selectedContacts.push(contact.email);
                    } else {
                        selectedContacts = selectedContacts.filter(email => email !== contact.email);
                    }
                    updateForwardButton();
                });
                
                contactsList.appendChild(contactEl);
            });
            
        } catch (error) {
            console.error('Error loading contacts:', error);
            contactsList.innerHTML = '<div class="error">Failed to load contacts</div>';
        }
    }
    
    // Update forward button
    function updateForwardButton() {
        const submitBtn = document.getElementById('forward-submit-btn');
        if (submitBtn) {
            submitBtn.disabled = selectedContacts.length === 0;
            submitBtn.textContent = `Forward (${selectedContacts.length})`;
        }
    }
    
    // Forward to selected contacts
    async function forwardToSelected() {
        if (!currentForwardMessage || selectedContacts.length === 0) return;
        
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
        if (!currentUser.email) return;
        
        // Show loading
        const submitBtn = document.getElementById('forward-submit-btn');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Forwarding...';
        }
        
        try {
            // Forward to each selected contact
            for (const contactEmail of selectedContacts) {
                await fetch('/chats/forward', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        from_email: currentUser.email,
                        to_email: contactEmail,
                        original_message: currentForwardMessage
                    })
                });
            }
            
            // Show success
            window.showToast?.(`Message forwarded to ${selectedContacts.length} contact(s)`, 'success');
            
            // Close modal
            closeModal();
            
        } catch (error) {
            console.error('Error forwarding message:', error);
            window.showToast?.('Failed to forward message', 'error');
            
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = `Forward (${selectedContacts.length})`;
            }
        }
    }
    
    // Public API
    return {
        init,
        openForwardModal,
        closeModal
    };
})();

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    ForwardFeature.init();
});

// Make globally available
window.ForwardFeature = ForwardFeature;