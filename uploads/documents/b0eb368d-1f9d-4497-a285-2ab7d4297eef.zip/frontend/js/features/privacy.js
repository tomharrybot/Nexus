// Privacy Settings Feature
const PrivacyFeature = (function() {
    let privacyModal = null;
    let currentSettings = null;
    
    function init() {
        createPrivacyModal();
        loadPrivacySettings();
    }
    
    function createPrivacyModal() {
        if (document.getElementById('privacy-modal')) return;
        
        privacyModal = document.createElement('div');
        privacyModal.id = 'privacy-modal';
        privacyModal.className = 'modal';
        privacyModal.innerHTML = `
            <div class="modal-content privacy-modal">
                <div class="modal-header">
                    <h2>Privacy Settings</h2>
                    <span class="close" onclick="PrivacyFeature.closeModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="privacy-section">
                        <h3>Who can see my</h3>
                        
                        <div class="privacy-option">
                            <label>Last Seen</label>
                            <select id="privacy-last-seen" class="privacy-select">
                                <option value="everyone">Everyone</option>
                                <option value="contacts">My Contacts</option>
                                <option value="nobody">Nobody</option>
                            </select>
                        </div>
                        
                        <div class="privacy-option">
                            <label>Profile Photo</label>
                            <select id="privacy-photo" class="privacy-select">
                                <option value="everyone">Everyone</option>
                                <option value="contacts">My Contacts</option>
                                <option value="nobody">Nobody</option>
                            </select>
                        </div>
                        
                        <div class="privacy-option">
                            <label>About</label>
                            <select id="privacy-about" class="privacy-select">
                                <option value="everyone">Everyone</option>
                                <option value="contacts">My Contacts</option>
                                <option value="nobody">Nobody</option>
                            </select>
                        </div>
                        
                        <div class="privacy-option">
                            <label>Groups</label>
                            <select id="privacy-groups" class="privacy-select">
                                <option value="everyone">Everyone</option>
                                <option value="contacts">My Contacts</option>
                                <option value="nobody">Nobody</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="privacy-section">
                        <h3>Advanced Privacy</h3>
                        
                        <div class="privacy-toggle">
                            <label>Read Receipts</label>
                            <label class="switch">
                                <input type="checkbox" id="privacy-read-receipts">
                                <span class="slider"></span>
                            </label>
                        </div>
                        
                        <div class="privacy-toggle">
                            <label>Typing Indicator</label>
                            <label class="switch">
                                <input type="checkbox" id="privacy-typing">
                                <span class="slider"></span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="privacy-section">
                        <h3>Blocked Users</h3>
                        <div class="blocked-users-list" id="blocked-users-list">
                            <!-- Blocked users will appear here -->
                        </div>
                        <button class="nexus-button" onclick="PrivacyFeature.openBlockUserModal()">
                            <i class="fas fa-ban"></i> Block New User
                        </button>
                    </div>
                    
                    <button class="nexus-button save-btn" onclick="PrivacyFeature.saveSettings()">
                        Save Privacy Settings
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(privacyModal);
    }
    
    async function loadPrivacySettings() {
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await fetch(`/privacy/settings/${user.email}`);
            const settings = await response.json();
            
            currentSettings = settings;
            
            // Update UI if modal is open
            if (privacyModal?.classList.contains('active')) {
                updatePrivacyUI();
            }
        } catch (error) {
            console.error('Error loading privacy settings:', error);
        }
    }
    
    function updatePrivacyUI() {
        if (!currentSettings) return;
        
        const lastSeen = document.getElementById('privacy-last-seen');
        const photo = document.getElementById('privacy-photo');
        const about = document.getElementById('privacy-about');
        const groups = document.getElementById('privacy-groups');
        const readReceipts = document.getElementById('privacy-read-receipts');
        const typing = document.getElementById('privacy-typing');
        
        if (lastSeen) lastSeen.value = currentSettings.last_seen || 'everyone';
        if (photo) photo.value = currentSettings.profile_photo || 'everyone';
        if (about) about.value = currentSettings.about || 'everyone';
        if (groups) groups.value = currentSettings.groups || 'everyone';
        if (readReceipts) readReceipts.checked = currentSettings.read_receipts !== false;
        if (typing) typing.checked = currentSettings.typing_indicator !== false;
    }
    
    function openModal() {
        if (privacyModal) {
            privacyModal.classList.add('active');
            loadPrivacySettings();
            loadBlockedUsers();
        }
    }
    
    function closeModal() {
        if (privacyModal) {
            privacyModal.classList.remove('active');
        }
    }
    
    async function saveSettings() {
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const settings = {
                last_seen: document.getElementById('privacy-last-seen')?.value,
                profile_photo: document.getElementById('privacy-photo')?.value,
                about: document.getElementById('privacy-about')?.value,
                groups: document.getElementById('privacy-groups')?.value,
                read_receipts: document.getElementById('privacy-read-receipts')?.checked,
                typing_indicator: document.getElementById('privacy-typing')?.checked
            };
            
            const response = await fetch('/privacy/settings/update', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email: user.email, settings })
            });
            
            const data = await response.json();
            
            if (data.status === 'ok') {
                Toast.show('Privacy settings saved', 'success');
                closeModal();
            } else {
                Toast.show(data.message, 'error');
            }
        } catch (error) {
            console.error('Error saving privacy settings:', error);
            Toast.show('Failed to save settings', 'error');
        }
    }
    
    async function loadBlockedUsers() {
        const container = document.getElementById('blocked-users-list');
        if (!container) return;
        
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await fetch(`/privacy/blocked/${user.email}`);
            const blocked = await response.json();
            
            if (blocked.length === 0) {
                container.innerHTML = '<div class="no-blocked">No blocked users</div>';
                return;
            }
            
            container.innerHTML = '';
            blocked.forEach(email => {
                const item = document.createElement('div');
                item.className = 'blocked-user-item';
                item.innerHTML = `
                    <span>${email}</span>
                    <button class="unblock-btn" onclick="PrivacyFeature.unblockUser('${email}')">
                        <i class="fas fa-user-check"></i> Unblock
                    </button>
                `;
                container.appendChild(item);
            });
        } catch (error) {
            console.error('Error loading blocked users:', error);
        }
    }
    
    async function unblockUser(email) {
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await fetch('/privacy/unblock', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user_email: user.email, unblock_email: email })
            });
            
            const data = await response.json();
            
            if (data.status === 'ok') {
                Toast.show('User unblocked', 'success');
                loadBlockedUsers();
            }
        } catch (error) {
            console.error('Error unblocking user:', error);
            Toast.show('Failed to unblock user', 'error');
        }
    }
    
    function openBlockUserModal() {
        // Create block modal
        const blockModal = document.createElement('div');
        blockModal.className = 'modal';
        blockModal.id = 'temp-block-modal';
        blockModal.innerHTML = `
            <div class="modal-content block-modal">
                <div class="modal-header">
                    <h3>Block User</h3>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <input type="email" id="block-email-input" class="nexus-input" placeholder="Enter email to block">
                    <button class="nexus-button" onclick="PrivacyFeature.blockUser()">Block User</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(blockModal);
        setTimeout(() => blockModal.classList.add('active'), 10);
    }
    
    async function blockUser() {
        const emailInput = document.getElementById('block-email-input');
        const email = emailInput?.value.trim();
        
        if (!email) {
            Toast.show('Please enter an email', 'error');
            return;
        }
        
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await fetch('/privacy/block', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user_email: user.email, block_email: email })
            });
            
            const data = await response.json();
            
            if (data.status === 'ok') {
                Toast.show('User blocked', 'success');
                document.getElementById('temp-block-modal')?.remove();
                loadBlockedUsers();
            } else {
                Toast.show(data.message, 'error');
            }
        } catch (error) {
            console.error('Error blocking user:', error);
            Toast.show('Failed to block user', 'error');
        }
    }
    
    return {
        init,
        openModal,
        closeModal,
        saveSettings,
        unblockUser,
        blockUser,
        openBlockUserModal
    };
})();

// Initialize
document.addEventListener('DOMContentLoaded', () => PrivacyFeature.init());
window.PrivacyFeature = PrivacyFeature;