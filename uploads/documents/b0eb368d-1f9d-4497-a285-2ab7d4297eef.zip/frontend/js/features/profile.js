// Profile Feature
const ProfileFeature = (function() {
    let profileModal = null;
    let viewProfileModal = null;
    
    function init() {
        createProfileModal();
        createViewProfileModal();
    }
    
    function createProfileModal() {
        if (document.getElementById('profile-modal')) return;
        
        profileModal = document.createElement('div');
        profileModal.id = 'profile-modal';
        profileModal.className = 'modal';
        profileModal.innerHTML = `
            <div class="modal-content profile-modal">
                <div class="modal-header">
                    <h2>Your Profile</h2>
                    <span class="close" onclick="ProfileFeature.closeModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="profile-avatar-section">
                        <div class="profile-avatar-container">
                            <img id="profile-avatar-preview" src="" class="profile-avatar-large">
                            <div class="profile-avatar-overlay" onclick="document.getElementById('profile-avatar-upload').click()">
                                <i class="fas fa-camera"></i>
                            </div>
                        </div>
                        <input type="file" id="profile-avatar-upload" accept="image/*" style="display: none;">
                    </div>
                    
                    <div class="profile-info-section">
                        <div class="profile-field">
                            <label>Your Name</label>
                            <input type="text" id="profile-name" class="nexus-input" placeholder="Enter your name">
                        </div>
                        
                        <div class="profile-field">
                            <label>About</label>
                            <textarea id="profile-about" class="nexus-input" placeholder="Tell something about yourself..." rows="3"></textarea>
                        </div>
                        
                        <div class="profile-field">
                            <label>Your User ID</label>
                            <div class="user-id-display" id="user-id-display"></div>
                            <button class="copy-userid-btn" onclick="ProfileFeature.copyUserID()">
                                <i class="fas fa-copy"></i> Copy ID
                            </button>
                        </div>
                        
                        <div class="profile-field">
                            <label>Email</label>
                            <div class="profile-email" id="profile-email"></div>
                        </div>
                        
                        <div class="profile-field">
                            <label>Member Since</label>
                            <div class="profile-joined" id="profile-joined"></div>
                        </div>
                    </div>
                    
                    <button class="nexus-button save-btn" onclick="ProfileFeature.saveProfile()">
                        Save Profile
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(profileModal);
        
        // Avatar upload handler
        const avatarUpload = document.getElementById('profile-avatar-upload');
        if (avatarUpload) {
            avatarUpload.addEventListener('change', handleAvatarUpload);
        }
    }
    
    function createViewProfileModal() {
        if (document.getElementById('view-profile-modal')) return;
        
        viewProfileModal = document.createElement('div');
        viewProfileModal.id = 'view-profile-modal';
        viewProfileModal.className = 'modal';
        viewProfileModal.innerHTML = `
            <div class="modal-content view-profile-modal">
                <div class="modal-header">
                    <h2>Profile</h2>
                    <span class="close" onclick="ProfileFeature.closeViewModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="view-profile-avatar">
                        <img id="view-profile-avatar" src="" class="profile-avatar-large">
                        <span id="view-profile-status" class="status-indicator-large"></span>
                    </div>
                    
                    <div class="view-profile-info">
                        <h3 id="view-profile-name"></h3>
                        <p id="view-profile-about" class="profile-about"></p>
                        <p id="view-profile-email" class="profile-email"></p>
                        <p id="view-profile-userid" class="profile-userid"></p>
                        <p id="view-profile-lastseen" class="profile-lastseen"></p>
                    </div>
                    
                    <div class="view-profile-actions">
                        <button class="nexus-button" onclick="window.openChatWithEmail(document.getElementById('view-profile-email').textContent)">
                            <i class="fas fa-comment"></i> Message
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(viewProfileModal);
    }
    
    function handleAvatarUpload(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        if (!file.type.match('image.*')) {
            Toast.show('Please select an image file', 'error');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(event) {
            const preview = document.getElementById('profile-avatar-preview');
            if (preview) {
                preview.src = event.target.result;
            }
        };
        reader.readAsDataURL(file);
    }
    
    function openModal() {
        loadUserData();
        if (profileModal) {
            profileModal.classList.add('active');
        }
    }
    
    function closeModal() {
        if (profileModal) {
            profileModal.classList.remove('active');
        }
    }
    
    function closeViewModal() {
        if (viewProfileModal) {
            viewProfileModal.classList.remove('active');
        }
    }
    
    function loadUserData() {
        const user = Storage.getUser();
        if (!user) return;
        
        const avatar = document.getElementById('profile-avatar-preview');
        const name = document.getElementById('profile-name');
        const about = document.getElementById('profile-about');
        const email = document.getElementById('profile-email');
        const joined = document.getElementById('profile-joined');
        const userId = document.getElementById('user-id-display');
        
        if (avatar) avatar.src = user.profile?.avatar || 'data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27%23ffffff%27%3E%3Cpath d=%27M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-6.627 0-12 5.373-12 12h24c0-6.627-5.373-12-12-12z%27/%3E%3C/svg%3E';
        if (name) name.value = user.profile?.name || user.username || '';
        if (about) about.value = user.profile?.about || '';
        if (email) email.textContent = user.email;
        if (joined) joined.textContent = user.created_at ? new Date(user.created_at * 1000).toLocaleDateString() : 'Unknown';
        if (userId) userId.textContent = user.id || 'NX-0000-0000-0000';
    }
    
    async function saveProfile() {
        const name = document.getElementById('profile-name')?.value;
        const about = document.getElementById('profile-about')?.value;
        const avatar = document.getElementById('profile-avatar-preview')?.src;
        
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await fetch('/users/profile/update', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: user.email,
                    name,
                    about,
                    avatar
                })
            });
            
            const data = await response.json();
            
            if (data.status === 'ok') {
                // Update stored user
                const updatedUser = { ...user, profile: data.user.profile };
                Storage.setUser(updatedUser);
                
                Toast.show('Profile saved successfully', 'success');
                closeModal();
                
                // Update UI
                updateProfileUI(updatedUser);
            } else {
                Toast.show(data.message, 'error');
            }
        } catch (error) {
            console.error('Error saving profile:', error);
            Toast.show('Failed to save profile', 'error');
        }
    }
    
    function updateProfileUI(user) {
        const userAvatar = document.getElementById('user-avatar');
        if (userAvatar) {
            userAvatar.src = user.profile?.avatar || 'data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27%23ffffff%27%3E%3Cpath d=%27M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-6.627 0-12 5.373-12 12h24c0-6.627-5.373-12-12-12z%27/%3E%3C/svg%3E';
        }
    }
    
    function copyUserID() {
        const userIdEl = document.getElementById('user-id-display');
        if (userIdEl) {
            navigator.clipboard.writeText(userIdEl.textContent);
            Toast.show('User ID copied to clipboard', 'success');
        }
    }
    
    function viewProfile(userData) {
        const modal = document.getElementById('view-profile-modal');
        if (!modal) return;
        
        const avatar = document.getElementById('view-profile-avatar');
        const name = document.getElementById('view-profile-name');
        const about = document.getElementById('view-profile-about');
        const email = document.getElementById('view-profile-email');
        const userId = document.getElementById('view-profile-userid');
        const lastSeen = document.getElementById('view-profile-lastseen');
        const status = document.getElementById('view-profile-status');
        
        if (avatar) avatar.src = userData.avatar || 'data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27%23ffffff%27%3E%3Cpath d=%27M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-6.627 0-12 5.373-12 12h24c0-6.627-5.373-12-12-12z%27/%3E%3C/svg%3E';
        if (name) name.textContent = userData.name || userData.email;
        if (about) about.textContent = userData.about || 'No bio available';
        if (email) email.textContent = userData.email;
        if (userId) userId.textContent = userData.userId || 'Not available';
        
        if (lastSeen) {
            if (userData.online) {
                lastSeen.textContent = 'Online';
                if (status) status.classList.remove('offline');
            } else {
                lastSeen.textContent = userData.lastSeen ? `Last seen: ${formatLastSeen(userData.lastSeen)}` : 'Offline';
                if (status) status.classList.add('offline');
            }
        }
        
        modal.classList.add('active');
    }
    
    function formatLastSeen(timestamp) {
        if (!timestamp) return 'Unknown';
        
        const date = new Date(timestamp * 1000);
        const now = new Date();
        const diff = Math.floor((now - date) / 1000);
        
        if (diff < 60) return 'just now';
        if (diff < 3600) return `${Math.floor(diff / 60)} minutes ago`;
        if (diff < 86400) return `${Math.floor(diff / 3600)} hours ago`;
        return date.toLocaleDateString();
    }
    
    return {
        init,
        openModal,
        closeModal,
        closeViewModal,
        saveProfile,
        copyUserID,
        viewProfile
    };
})();

// Initialize
document.addEventListener('DOMContentLoaded', () => ProfileFeature.init());
window.ProfileFeature = ProfileFeature;