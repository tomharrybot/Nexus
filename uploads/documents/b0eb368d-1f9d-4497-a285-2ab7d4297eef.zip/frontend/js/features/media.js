// Media Feature
const MediaFeature = {
    async upload(file, type = 'document') {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('type', type);
        
        const closeToast = Toast.loading('Uploading...');
        
        try {
            const response = await API.upload('/media/upload', formData);
            
            if (response.status === 'ok') {
                Toast.success('Upload complete');
                return response;
            } else {
                throw new Error(response.message || 'Upload failed');
            }
        } catch (error) {
            console.error('Upload error:', error);
            Toast.error('Upload failed');
            throw error;
        } finally {
            closeToast();
        }
    },
    
    async uploadMultiple(files, type = 'document') {
        const results = [];
        const total = files.length;
        let completed = 0;
        
        const toast = Toast.loading(`Uploading 0/${total}`);
        
        for (const file of files) {
            try {
                const result = await this.upload(file, type);
                results.push(result);
                completed++;
                toast.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Uploading ${completed}/${total}`;
            } catch (error) {
                console.error('Error uploading file:', error);
            }
        }
        
        toast.remove();
        Toast.success(`Uploaded ${completed}/${total} files`);
        
        return results;
    },
    
    getFileIcon(extension) {
        const icons = {
            'pdf': 'fa-file-pdf',
            'doc': 'fa-file-word',
            'docx': 'fa-file-word',
            'xls': 'fa-file-excel',
            'xlsx': 'fa-file-excel',
            'ppt': 'fa-file-powerpoint',
            'pptx': 'fa-file-powerpoint',
            'txt': 'fa-file-alt',
            'jpg': 'fa-file-image',
            'jpeg': 'fa-file-image',
            'png': 'fa-file-image',
            'gif': 'fa-file-image',
            'mp4': 'fa-file-video',
            'mp3': 'fa-file-audio',
            'wav': 'fa-file-audio',
            'zip': 'fa-file-archive',
            'rar': 'fa-file-archive'
        };
        
        return icons[extension?.toLowerCase()] || 'fa-file';
    },
    
    formatFileSize(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / 1048576).toFixed(1) + ' MB';
    },
    
    isImage(type) {
        return type?.startsWith('image/');
    },
    
    isVideo(type) {
        return type?.startsWith('video/');
    },
    
    isAudio(type) {
        return type?.startsWith('audio/');
    },
    
    getMediaType(file) {
        if (this.isImage(file.type)) return 'image';
        if (this.isVideo(file.type)) return 'video';
        if (this.isAudio(file.type)) return 'audio';
        return 'document';
    },
    
    createMediaElement(file, url) {
        const type = this.getMediaType(file);
        
        switch (type) {
            case 'image':
                return `<img src="${url}" alt="${file.name}" class="media-image">`;
                
            case 'video':
                return `<video src="${url}" controls class="media-video"></video>`;
                
            case 'audio':
                return `<audio src="${url}" controls class="media-audio"></audio>`;
                
            default:
                return `
                    <div class="media-file">
                        <i class="fas ${this.getFileIcon(file.name.split('.').pop())}"></i>
                        <div class="media-file-info">
                            <div class="media-file-name">${file.name}</div>
                            <div class="media-file-size">${this.formatFileSize(file.size)}</div>
                        </div>
                    </div>
                `;
        }
    },
    
    validateFile(file, type = null) {
        const fileType = type || this.getMediaType(file);
        
        const limits = {
            image: 10 * 1024 * 1024,
            video: 50 * 1024 * 1024,
            audio: 20 * 1024 * 1024,
            document: 25 * 1024 * 1024
        };
        
        const allowedTypes = {
            image: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
            video: ['video/mp4', 'video/webm', 'video/ogg'],
            audio: ['audio/mpeg', 'audio/wav', 'audio/ogg'],
            document: [
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'text/plain',
                'application/zip',
                'application/x-rar-compressed'
            ]
        };
        
        if (file.size > limits[fileType]) {
            const limitMB = Math.floor(limits[fileType] / (1024 * 1024));
            return {
                valid: false,
                message: `File too large. Maximum size: ${limitMB}MB`
            };
        }
        
        if (!allowedTypes[fileType].includes(file.type)) {
            return {
                valid: false,
                message: 'File type not allowed'
            };
        }
        
        return { valid: true };
    },
    
    async compressImage(file, maxWidth = 1920, maxHeight = 1080, quality = 0.8) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            
            reader.onload = (e) => {
                const img = new Image();
                img.src = e.target.result;
                
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    let width = img.width;
                    let height = img.height;
                    
                    if (width > height) {
                        if (width > maxWidth) {
                            height *= maxWidth / width;
                            width = maxWidth;
                        }
                    } else {
                        if (height > maxHeight) {
                            width *= maxHeight / height;
                            height = maxHeight;
                        }
                    }
                    
                    canvas.width = width;
                    canvas.height = height;
                    
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);
                    
                    canvas.toBlob((blob) => {
                        resolve(new File([blob], file.name, {
                            type: 'image/jpeg',
                            lastModified: Date.now()
                        }));
                    }, 'image/jpeg', quality);
                };
                
                img.onerror = reject;
            };
            
            reader.onerror = reject;
        });
    }
};

window.MediaFeature = MediaFeature;