// Copy Feature Module
const CopyFeature = (function() {
    let copyToast = null;
    let copyTimeout = null;
    
    // Initialize copy feature
    function init() {
        createCopyToast();
        setupContextMenu();
    }
    
    // Create copy toast
    function createCopyToast() {
        if (document.getElementById('copy-toast')) return;
        
        copyToast = document.createElement('div');
        copyToast.id = 'copy-toast';
        copyToast.className = 'copy-toast';
        copyToast.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>Message copied to clipboard!</span>
            <i class="fas fa-times close-copy" onclick="CopyFeature.hideToast()"></i>
        `;
        
        document.body.appendChild(copyToast);
    }
    
    // Setup context menu for copy
    function setupContextMenu() {
        const messagesContainer = document.getElementById('messages-container');
        
        messagesContainer.addEventListener('contextmenu', (e) => {
            const messageEl = e.target.closest('.message');
            if (!messageEl) return;
            
            e.preventDefault();
            
            const messageId = messageEl.dataset.messageId;
            const messageText = messageEl.querySelector('.message-text')?.textContent;
            
            if (messageText) {
                showContextMenu(e.clientX, e.clientY, messageId, messageText);
            }
        });
        
        // Close context menu on click outside
        document.addEventListener('click', () => {
            const contextMenu = document.querySelector('.message-context-menu');
            if (contextMenu) {
                contextMenu.remove();
            }
        });
    }
    
    // Show context menu
    function showContextMenu(x, y, messageId, messageText) {
        // Remove existing menu
        const existingMenu = document.querySelector('.message-context-menu');
        if (existingMenu) existingMenu.remove();
        
        // Create menu
        const menu = document.createElement('div');
        menu.className = 'message-context-menu';
        menu.style.left = x + 'px';
        menu.style.top = y + 'px';
        
        menu.innerHTML = `
            <div class="context-menu-item copy-item" onclick="CopyFeature.copyText('${messageText.replace(/'/g, "\\'")}')">
                <i class="fas fa-copy"></i>
                <span>Copy</span>
            </div>
            <div class="context-menu-item reply-item" onclick="ReplyFeature.setReplyMessage({message: '${messageText.replace(/'/g, "\\'")}'})">
                <i class="fas fa-reply"></i>
                <span>Reply</span>
            </div>
            <div class="context-menu-item forward-item" onclick="ForwardFeature.openForwardModal({message: '${messageText.replace(/'/g, "\\'")}'})">
                <i class="fas fa-share"></i>
                <span>Forward</span>
            </div>
            <div class="context-menu-item delete-item" onclick="DeleteFeature.openDeleteModal('${messageId}')">
                <i class="fas fa-trash"></i>
                <span>Delete</span>
            </div>
        `;
        
        document.body.appendChild(menu);
        
        // Adjust position if off screen
        const menuRect = menu.getBoundingClientRect();
        if (menuRect.right > window.innerWidth) {
            menu.style.left = (window.innerWidth - menuRect.width - 10) + 'px';
        }
        if (menuRect.bottom > window.innerHeight) {
            menu.style.top = (window.innerHeight - menuRect.height - 10) + 'px';
        }
    }
    
    // Copy text to clipboard
    async function copyText(text) {
        try {
            await navigator.clipboard.writeText(text);
            showToast();
            
            // Add animation to message
            const messageEl = document.querySelector('.message.selected');
            if (messageEl) {
                messageEl.classList.add('copying');
                setTimeout(() => {
                    messageEl.classList.remove('copying');
                }, 300);
            }
        } catch (err) {
            console.error('Failed to copy:', err);
            window.showToast?.('Failed to copy message', 'error');
        }
    }
    
    // Show copy toast
    function showToast() {
        if (!copyToast) return;
        
        // Clear existing timeout
        if (copyTimeout) clearTimeout(copyTimeout);
        
        // Show toast
        copyToast.classList.add('show');
        
        // Auto hide after 2 seconds
        copyTimeout = setTimeout(() => {
            hideToast();
        }, 2000);
    }
    
    // Hide toast
    function hideToast() {
        if (copyToast) {
            copyToast.classList.remove('show');
        }
        if (copyTimeout) {
            clearTimeout(copyTimeout);
            copyTimeout = null;
        }
    }
    
    // Public API
    return {
        init,
        copyText,
        showToast,
        hideToast
    };
})();

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    CopyFeature.init();
});

// Make globally available
window.CopyFeature = CopyFeature;