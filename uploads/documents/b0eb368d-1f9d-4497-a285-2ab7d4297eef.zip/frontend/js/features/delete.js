// Delete Feature Module
const DeleteFeature = (function() {
    let currentDeleteMessageId = null;
    let deleteModal = null;
    
    // Initialize delete feature
    function init() {
        createDeleteModal();
    }
    
    // Create delete modal
    function createDeleteModal() {
        if (document.getElementById('delete-modal')) return;
        
        deleteModal = document.createElement('div');
        deleteModal.id = 'delete-modal';
        deleteModal.className = 'modal';
        deleteModal.innerHTML = `
            <div class="modal-content delete-modal">
                <div class="delete-icon">
                    <i class="fas fa-trash-alt"></i>
                </div>
                <h3>Delete Message?</h3>
                <p>Choose what happens to this message</p>
                <div class="delete-options">
                    <button class="delete-option for-me" onclick="DeleteFeature.deleteForMe()">Delete for me</button>
                    <button class="delete-option for-everyone" onclick="DeleteFeature.deleteForEveryone()">Delete for everyone</button>
                </div>
                <div class="delete-cancel" onclick="DeleteFeature.closeModal()">Cancel</div>
            </div>
        `;
        
        document.body.appendChild(deleteModal);
        
        // Click outside to close
        deleteModal.addEventListener('click', (e) => {
            if (e.target === deleteModal) {
                closeModal();
            }
        });
    }
    
    // Open delete modal
    function openDeleteModal(messageId) {
        currentDeleteMessageId = messageId;
        
        if (deleteModal) {
            deleteModal.classList.add('active');
        }
    }
    
    // Close modal
    function closeModal() {
        if (deleteModal) {
            deleteModal.classList.remove('active');
        }
        currentDeleteMessageId = null;
    }
    
    // Delete for me only
    async function deleteForMe() {
        if (!currentDeleteMessageId) return;
        
        try {
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            
            // In a real app, you might want to mark as deleted locally only
            // For now, we'll hide it from UI
            const messageEl = document.querySelector(`.message[data-message-id="${currentDeleteMessageId}"]`);
            if (messageEl) {
                messageEl.remove();
            }
            
            window.showToast?.('Message deleted', 'success');
            closeModal();
            
        } catch (error) {
            console.error('Error deleting message:', error);
            window.showToast?.('Failed to delete message', 'error');
        }
    }
    
    // Delete for everyone
    async function deleteForEveryone() {
        if (!currentDeleteMessageId) return;
        
        try {
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            
            // Call API to delete message
            const response = await fetch('/chats/delete-message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    message_id: currentDeleteMessageId,
                    chat_id: window.currentChat?.email, // You'd need the chat ID
                    user_email: currentUser.email
                })
            });
            
            if (response.ok) {
                // Update UI
                const messageEl = document.querySelector(`.message[data-message-id="${currentDeleteMessageId}"]`);
                if (messageEl) {
                    messageEl.classList.add('deleted');
                    const messageText = messageEl.querySelector('.message-text');
                    if (messageText) {
                        messageText.innerHTML = '<i class="fas fa-trash"></i> This message was deleted';
                    }
                }
                
                window.showToast?.('Message deleted for everyone', 'success');
            } else {
                throw new Error('Failed to delete');
            }
            
            closeModal();
            
        } catch (error) {
            console.error('Error deleting message:', error);
            window.showToast?.('Failed to delete message', 'error');
        }
    }
    
    // Public API
    return {
        init,
        openDeleteModal,
        closeModal,
        deleteForMe,
        deleteForEveryone
    };
})();

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    DeleteFeature.init();
});

// Make globally available
window.DeleteFeature = DeleteFeature;