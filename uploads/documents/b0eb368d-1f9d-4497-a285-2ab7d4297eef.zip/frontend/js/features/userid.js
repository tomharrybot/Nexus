// UserID Feature
const UserIDFeature = {
    formatUserID(id) {
        if (!id) return 'NX-0000-0000-0000';
        
        // Ensure format NX-XXXX-XXXX-XXXX
        if (id.startsWith('NX-')) {
            return id;
        }
        
        // Generate from email or random
        return this.generateFromString(id);
    },
    
    generateFromString(str) {
        const hash = this.hashString(str);
        const part1 = hash.substring(0, 4).toUpperCase();
        const part2 = hash.substring(4, 8).toUpperCase();
        const part3 = hash.substring(8, 12).toUpperCase();
        
        return `NX-${part1}-${part2}-${part3}`;
    },
    
    hashString(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return Math.abs(hash).toString(16).padStart(12, '0');
    },
    
    generateRandom() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        const randomPart = (len) => {
            let result = '';
            for (let i = 0; i < len; i++) {
                result += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            return result;
        };
        
        return `NX-${randomPart(4)}-${randomPart(4)}-${randomPart(4)}`;
    },
    
    createUserIDElement(userId, onCopy) {
        const container = document.createElement('div');
        container.className = 'userid-container';
        
        container.innerHTML = `
            <span class="userid-prefix">NX</span>
            <span class="userid-value">${userId.substring(3)}</span>
            <button class="userid-copy-btn" title="Copy User ID">
                <i class="fas fa-copy"></i>
            </button>
        `;
        
        const copyBtn = container.querySelector('.userid-copy-btn');
        copyBtn.addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText(userId);
                copyBtn.classList.add('copied');
                copyBtn.innerHTML = '<i class="fas fa-check"></i>';
                
                setTimeout(() => {
                    copyBtn.classList.remove('copied');
                    copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
                }, 2000);
                
                if (onCopy) onCopy(userId);
                Toast.success('User ID copied');
            } catch (err) {
                console.error('Failed to copy:', err);
                Toast.error('Failed to copy');
            }
        });
        
        return container;
    },
    
    createUserIDCard(userId, createdAt) {
        const card = document.createElement('div');
        card.className = 'userid-card';
        
        const date = createdAt ? new Date(createdAt * 1000).toLocaleDateString() : 'Unknown';
        
        card.innerHTML = `
            <div class="userid-card-title">YOUR UNIQUE IDENTIFIER</div>
            <div class="userid-card-value">${userId}</div>
            <div class="userid-card-date">Member since: ${date}</div>
        `;
        
        return card;
    },
    
    createUserIDBadge(userId, size = 'small') {
        const badge = document.createElement('span');
        badge.className = `userid-badge ${size}`;
        badge.innerHTML = `<i class="fas fa-id-card"></i> ${userId}`;
        return badge;
    },
    
    createUserIDSearch() {
        const container = document.createElement('div');
        container.className = 'userid-search';
        
        container.innerHTML = `
            <i class="fas fa-id-card"></i>
            <input type="text" class="nexus-input" placeholder="Search by User ID (NX-XXXX-XXXX-XXXX)">
        `;
        
        return container;
    },
    
    isValidUserID(userId) {
        return /^NX-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(userId);
    },
    
    extractFromUserID(userId) {
        if (!this.isValidUserID(userId)) return null;
        
        const parts = userId.split('-');
        return {
            prefix: parts[0],
            part1: parts[1],
            part2: parts[2],
            part3: parts[3],
            full: userId
        };
    },
    
    async findUserByID(userId) {
        if (!this.isValidUserID(userId)) {
            Toast.error('Invalid User ID format');
            return null;
        }
        
        try {
            const users = await API.get('/users/all');
            const user = users.find(u => u.id === userId);
            
            if (user) {
                return user;
            } else {
                Toast.error('User not found');
                return null;
            }
        } catch (error) {
            console.error('Error finding user:', error);
            Toast.error('Failed to search user');
            return null;
        }
    },
    
    async addContactByUserID(userId) {
        const user = await this.findUserByID(userId);
        if (!user) return false;
        
        try {
            const currentUser = Storage.getUser();
            const response = await API.post('/contacts/add', {
                user_email: currentUser.email,
                contact_email: user.email
            });
            
            if (response.status === 'ok') {
                Toast.success(`Added ${user.profile?.name || user.email}`);
                return true;
            } else {
                Toast.error(response.message || 'Failed to add contact');
                return false;
            }
        } catch (error) {
            console.error('Error adding contact:', error);
            Toast.error('Failed to add contact');
            return false;
        }
    },
    
    generateQRCode(userId) {
        const qrContainer = document.createElement('div');
        qrContainer.className = 'userid-qr';
        
        // Simple QR code placeholder
        qrContainer.innerHTML = `
            <svg viewBox="0 0 100 100">
                <rect width="100" height="100" fill="white"/>
                <rect x="10" y="10" width="80" height="80" fill="black"/>
                <rect x="20" y="20" width="60" height="60" fill="white"/>
                <rect x="30" y="30" width="40" height="40" fill="black"/>
                <text x="50" y="55" font-family="monospace" font-size="8" text-anchor="middle" fill="white">NX</text>
            </svg>
            <p>Scan to add contact</p>
        `;
        
        return qrContainer;
    }
};

window.UserIDFeature = UserIDFeature;