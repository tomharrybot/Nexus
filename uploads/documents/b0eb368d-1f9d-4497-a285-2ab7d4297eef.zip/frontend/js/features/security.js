// Security Settings Feature
const SecurityFeature = (function() {
    let securityModal = null;
    let currentSettings = null;
    
    function init() {
        createSecurityModal();
        loadSecuritySettings();
    }
    
    function createSecurityModal() {
        if (document.getElementById('security-modal')) return;
        
        securityModal = document.createElement('div');
        securityModal.id = 'security-modal';
        securityModal.className = 'modal';
        securityModal.innerHTML = `
            <div class="modal-content security-modal">
                <div class="modal-header">
                    <h2>Security Settings</h2>
                    <span class="close" onclick="SecurityFeature.closeModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="security-section">
                        <h3>Two-Factor Authentication</h3>
                        <div class="security-toggle">
                            <label>Enable 2FA</label>
                            <label class="switch">
                                <input type="checkbox" id="security-2fa">
                                <span class="slider"></span>
                            </label>
                        </div>
                        <p class="security-note">Secure your account with an extra layer of security</p>
                    </div>
                    
                    <div class="security-section">
                        <h3>Login Alerts</h3>
                        <div class="security-toggle">
                            <label>Get notified on new logins</label>
                            <label class="switch">
                                <input type="checkbox" id="security-alerts" checked>
                                <span class="slider"></span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="security-section">
                        <h3>Active Sessions</h3>
                        <div class="sessions-list" id="sessions-list">
                            <!-- Active sessions will appear here -->
                        </div>
                    </div>
                    
                    <div class="security-section">
                        <h3>Change Password</h3>
                        <button class="nexus-button" onclick="SecurityFeature.openChangePasswordModal()">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                    </div>
                    
                    <div class="security-section">
                        <h3>Encryption</h3>
                        <p class="encryption-status">
                            <i class="fas fa-lock"></i> End-to-end encrypted
                        </p>
                    </div>
                    
                    <button class="nexus-button save-btn" onclick="SecurityFeature.saveSettings()">
                        Save Security Settings
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(securityModal);
    }
    
    async function loadSecuritySettings() {
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await fetch(`/security/settings/${user.email}`);
            const settings = await response.json();
            
            currentSettings = settings;
            
            if (securityModal?.classList.contains('active')) {
                updateSecurityUI();
                loadActiveSessions();
            }
        } catch (error) {
            console.error('Error loading security settings:', error);
        }
    }
    
    function updateSecurityUI() {
        if (!currentSettings) return;
        
        const twoFA = document.getElementById('security-2fa');
        const alerts = document.getElementById('security-alerts');
        
        if (twoFA) twoFA.checked = currentSettings.two_factor_auth || false;
        if (alerts) alerts.checked = currentSettings.login_alerts !== false;
    }
    
    async function loadActiveSessions() {
        const container = document.getElementById('sessions-list');
        if (!container) return;
        
        try {
            const user = Storage.getUser();
            if (!user || !currentSettings?.active_sessions) {
                container.innerHTML = '<div class="no-sessions">No active sessions</div>';
                return;
            }
            
            const sessions = currentSettings.active_sessions;
            
            if (sessions.length === 0) {
                container.innerHTML = '<div class="no-sessions">No active sessions</div>';
                return;
            }
            
            container.innerHTML = '';
            sessions.forEach((session, index) => {
                const item = document.createElement('div');
                item.className = 'session-item';
                item.innerHTML = `
                    <div class="session-info">
                        <i class="fas fa-${session.device === 'mobile' ? 'mobile-alt' : 'laptop'}"></i>
                        <div>
                            <div class="session-device">${session.device || 'Unknown device'}</div>
                            <div class="session-location">${session.location || 'Unknown location'}</div>
                            <div class="session-time">Last active: ${formatTime(session.lastActive)}</div>
                        </div>
                    </div>
                    <button class="revoke-session" onclick="SecurityFeature.revokeSession('${session.id}')">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                container.appendChild(item);
            });
        } catch (error) {
            console.error('Error loading sessions:', error);
        }
    }
    
    function formatTime(timestamp) {
        if (!timestamp) return 'Unknown';
        const date = new Date(timestamp * 1000);
        return date.toLocaleString();
    }
    
    function openModal() {
        if (securityModal) {
            securityModal.classList.add('active');
            loadSecuritySettings();
        }
    }
    
    function closeModal() {
        if (securityModal) {
            securityModal.classList.remove('active');
        }
    }
    
    async function saveSettings() {
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const settings = {
                two_factor_auth: document.getElementById('security-2fa')?.checked || false,
                login_alerts: document.getElementById('security-alerts')?.checked !== false,
                active_sessions: currentSettings?.active_sessions || [],
                device_management: true,
                encryption: 'end-to-end'
            };
            
            const response = await fetch('/security/settings/update', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email: user.email, settings })
            });
            
            const data = await response.json();
            
            if (data.status === 'ok') {
                Toast.show('Security settings saved', 'success');
                closeModal();
            } else {
                Toast.show(data.message, 'error');
            }
        } catch (error) {
            console.error('Error saving security settings:', error);
            Toast.show('Failed to save settings', 'error');
        }
    }
    
    async function revokeSession(sessionId) {
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await fetch('/security/sessions/revoke', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email: user.email, session_id: sessionId })
            });
            
            const data = await response.json();
            
            if (data.status === 'ok') {
                Toast.show('Session revoked', 'success');
                loadSecuritySettings(); // Reload to get updated sessions
            }
        } catch (error) {
            console.error('Error revoking session:', error);
            Toast.show('Failed to revoke session', 'error');
        }
    }
    
    function openChangePasswordModal() {
        const passwordModal = document.createElement('div');
        passwordModal.className = 'modal';
        passwordModal.id = 'temp-password-modal';
        passwordModal.innerHTML = `
            <div class="modal-content password-modal">
                <div class="modal-header">
                    <h3>Change Password</h3>
                    <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                </div>
                <div class="modal-body">
                    <input type="password" id="current-password" class="nexus-input" placeholder="Current password">
                    <input type="password" id="new-password" class="nexus-input" placeholder="New password">
                    <input type="password" id="confirm-password" class="nexus-input" placeholder="Confirm new password">
                    <button class="nexus-button" onclick="SecurityFeature.changePassword()">Update Password</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(passwordModal);
        setTimeout(() => passwordModal.classList.add('active'), 10);
    }
    
    async function changePassword() {
        const current = document.getElementById('current-password')?.value;
        const newPass = document.getElementById('new-password')?.value;
        const confirm = document.getElementById('confirm-password')?.value;
        
        if (!newPass || !confirm) {
            Toast.show('Please fill all fields', 'error');
            return;
        }
        
        if (newPass !== confirm) {
            Toast.show('Passwords do not match', 'error');
            return;
        }
        
        if (newPass.length < 6) {
            Toast.show('Password must be at least 6 characters', 'error');
            return;
        }
        
        try {
            const user = Storage.getUser();
            if (!user) return;
            
            const response = await fetch('/security/password/change', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    email: user.email, 
                    current_password: current,
                    new_password: newPass 
                })
            });
            
            const data = await response.json();
            
            if (data.status === 'ok') {
                Toast.show('Password changed successfully', 'success');
                document.getElementById('temp-password-modal')?.remove();
            } else {
                Toast.show(data.message, 'error');
            }
        } catch (error) {
            console.error('Error changing password:', error);
            Toast.show('Failed to change password', 'error');
        }
    }
    
    return {
        init,
        openModal,
        closeModal,
        saveSettings,
        revokeSession,
        openChangePasswordModal,
        changePassword
    };
})();

// Initialize
document.addEventListener('DOMContentLoaded', () => SecurityFeature.init());
window.SecurityFeature = SecurityFeature;